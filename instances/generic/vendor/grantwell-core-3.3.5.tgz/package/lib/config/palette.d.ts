/**
 * Brand palette for grantwell-check: missing shades derived from the primary, and the WCAG contrast
 * rules every palette must clear. Mirrors packages/ui/src/common/palette.ts, which applies them in
 * the browser; both copies are pinned by test/fixtures/palette.json.
 */
export interface BrandColors {
    primary: string;
    primaryHover?: string;
    primaryActive?: string;
    primaryLight?: string;
    accent?: string;
    accentHover?: string;
}
export type BrandColor = keyof BrandColors;
/** tokens.css's hand-tuned palette; a palette on this primary keeps it instead of derived shades. */
export declare const DEFAULT_COLORS: Required<BrandColors>;
/** `weight` of `b` mixed into `a`, in sRGB. */
export declare const mix: (a: string, b: string, weight: number) => string;
/** Every brand color, with the ones the palette leaves out derived from its primary. */
export declare function resolvePalette(colors: BrandColors): Required<BrandColors>;
/** tokens.css's primary tint for tinted-panel borders, derived for a non-default primary; undefined keeps tokens.css's own. */
export declare function derivedTints(primary: string): Record<string, string> | undefined;
export declare const contrastRatio: (a: string, b: string) => number;
/**
 * Every brand-colour pair the UI actually paints, with the WCAG threshold it must clear (4.5:1 for
 * text, 3:1 for borders and focus rings).
 */
export declare const CONTRAST_RULES: {
    fg: BrandColor | "white";
    bg: BrandColor | "white";
    min: number;
    usage: string;
}[];
export interface ContrastFailure {
    usage: string;
    fg: string;
    bg: string;
    ratio: number;
    required: number;
}
/** The rules a palette breaks once its missing shades are derived. */
export declare function findContrastFailures(colors: BrandColors): ContrastFailure[];
