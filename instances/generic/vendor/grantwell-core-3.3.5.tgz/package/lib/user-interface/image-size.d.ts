import type { Branding } from "../config/instance-config";
/** Pixel size of an SVG (width/height, else its viewBox) or a PNG; undefined for anything else. */
export declare function imageSize(file: string): {
    width: number;
    height: number;
} | undefined;
/**
 * Width of the email header logo at 28 px high, keeping the wordmark's proportions. `publicDirs` are
 * searched in order for the site-root path; the default width stands when the file can't be measured.
 */
/** Where the UI build writes the email wordmark as a PNG (packages/ui/vite/email-logo.ts). */
export declare const EMAIL_LOGO_PNG_PATH = "/images/email/logo.png";
export declare function emailLogoWidth(branding: Branding, publicDirs: (string | undefined)[]): number;
