import type { InstanceConfig } from "../config/instance-config";
export interface Finding {
    level: "fail" | "warn";
    message: string;
}
export declare function chromeApiVersion(uiAppDir: string): number;
export declare function checkChromeVersion(chromeDir: string, uiAppDir: string): Finding[];
/** Every `--gw-*` name the GrantWell UI uses or defines: the only ones a chrome may set or read. */
export declare function knownTokens(uiAppDir: string): Set<string>;
/**
 * Retired token names (old name → what to use), from tokens.css's "Retired" alias blocks. Components no
 * longer read them, so a theme that sets one changes nothing until it moves to the new name.
 */
export declare function retiredTokens(uiAppDir: string): Map<string, string>;
export declare function checkChromeTokens(chromeDir: string, uiAppDir: string): Finding[];
/** Every distinct palette must clear the UI's contrast rules once its missing shades are derived. */
export declare function checkBrandContrast(instances: InstanceConfig[]): Finding[];
/** Class names in a stylesheet's selectors, not in its values or at-rule conditions. */
export declare function selectorClasses(css: string): Set<string>;
/** CHROME_CLASSES (kept for instances to target) and CHROME_CLASSES_RETIRED (old name → what to use) from the UI's chrome-api.ts. */
export declare function chromeClassContract(uiAppDir: string): {
    kept: Set<string>;
    retired: Map<string, string>;
};
/**
 * Class names the GrantWell UI uses: `styled` from its CSS selectors and className values, and
 * `mentioned`, a looser superset (any quoted word) for classes a dependency renders, like Bootstrap's.
 */
export declare function coreClasses(uiAppDir: string): {
    styled: Set<string>;
    mentioned: Set<string>;
};
/**
 * Warns when chrome CSS styles a GrantWell class outside CHROME_CLASSES (it can change without notice)
 * or one GrantWell has retired or stopped rendering (the rule no longer applies). Classes the
 * chrome renders itself are its own business.
 */
export declare function checkChromeClasses(chromeDir: string, uiAppDir: string): Finding[];
export interface CompileOptions {
    /** Link this node_modules instead of running `npm ci` (tests, local runs). */
    nodeModulesDir?: string;
}
/** Type-checks chrome/ inside a copy of the shipped UI app, as the deploy's UI build does. */
export declare function checkChromeCompiles(chromeDir: string, uiAppDir: string, options?: CompileOptions): Finding[];
/** Deploy workflows read ModelCanaryFunctionName from `cdk deploy --outputs-file` to run check-models.sh. */
export declare function checkCanaryOutput(templatesDir: string, instances: InstanceConfig[]): Finding[];
export declare function checkScripts(instanceDir: string, shippedDir: string, version: string): Finding[];
/** Replaces scripts/ files with the release's copies. Writes then renames, so a running upgrade.sh keeps reading its old file. */
export declare function syncScripts(instanceDir: string, shippedDir: string): string[];
export declare function checkDeployWorkflow(instanceDir: string): Finding[];
/** Upgrade only: fails when a stateful resource in `before` is gone from, or would be replaced in, `after`. */
export declare function checkStateful(beforeDir: string, afterDir: string): Finding[];
/** The template's example values, which would deploy something that isn't yours. */
export declare function checkPlaceholders(instances: InstanceConfig[], level?: Finding["level"]): Finding[];
