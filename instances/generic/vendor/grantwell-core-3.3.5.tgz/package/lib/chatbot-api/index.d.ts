/**
 * This file defines the main construct for the ChatBot API using AWS CDK.
 * It sets up the WebSocket and REST APIs, integrates various Lambda functions,
 * and configures DynamoDB tables and S3 buckets for storing chat history and NOFO data.
 */
import { AuthorizationStack } from "../authorization";
import { WebsocketBackendAPI } from "./gateway/websocket-api";
import { RestBackendAPI } from "./gateway/rest-api";
import { LambdaFunctionStack } from "./functions/functions";
import { Construct } from "constructs";
import * as logs from "aws-cdk-lib/aws-logs";
import { InstanceConfig } from "../config/instance-config";
export interface ChatbotAPIProps {
    readonly config: InstanceConfig;
    readonly authentication: AuthorizationStack;
    readonly grantsGovApiKey: string;
    /** Email header logo width at 28 px high. */
    readonly digestLogoWidth: number;
}
export declare class ChatBotApi extends Construct {
    readonly httpAPI: RestBackendAPI;
    readonly wsAPI: WebsocketBackendAPI;
    readonly lambdaFunctions: LambdaFunctionStack;
    readonly draftGeneratorAPILogGroup: logs.LogGroup;
    constructor(scope: Construct, id: string, props: ChatbotAPIProps);
}
