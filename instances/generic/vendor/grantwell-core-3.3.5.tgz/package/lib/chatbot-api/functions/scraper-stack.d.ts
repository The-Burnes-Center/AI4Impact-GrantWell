/**
 * Nested stack holding the Grants.gov scraper fan-out Lambdas and the NOFO lifecycle
 * Lambdas (expiry auto-archive) plus the EventBridge rules that drive
 * them. Split out of the main app stack to stay under the 500-resource
 * CloudFormation limit.
 *
 * The SQS download queue, the NOFO bucket, the metadata table and the Bedrock
 * inference profile stay in the parent: they are shared with functions outside this
 * stack or their physical identity must survive this refactor.
 */
import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as s3 from "aws-cdk-lib/aws-s3";
import { Table } from "aws-cdk-lib/aws-dynamodb";
export interface ScraperStackProps extends cdk.NestedStackProps {
    readonly ffioNofosBucket: s3.Bucket;
    readonly grantArtifactsBucket: s3.Bucket;
    readonly nofoMetadataTable: Table;
    /** Shared with functions outside this stack, so it stays in the parent. */
    readonly jsSharedLayer: lambda.ILayerVersion;
    readonly grantsGovApiKey: string;
    /** Runs the coordinator daily at 9 AM UTC. */
    readonly dailySchedule: boolean;
    /** Bedrock application inference profile owned by the parent. */
    readonly haikuScraperProfileArn: string;
    /**
     * ARN/URL of the download queue, which stays in the parent (its DLQ and retention are
     * parent-owned state). Imported rather than passed as the Queue object: SqsEventSource
     * binds against a concrete Queue in another stack and a nested stack may not depend on
     * its parent.
     */
    readonly scraperDownloadQueueArn: string;
    readonly scraperDownloadQueueUrl: string;
    /** The coordinator's manual run checks the caller's role and state. */
    readonly supportedStatesEnv: string;
    readonly legacyStatelessAdminIsPlatform: string;
    readonly singleStateEnv: Record<string, string>;
}
export declare class ScraperStack extends cdk.NestedStack {
    readonly scraperCoordinatorFunction: lambda.Function;
    readonly opportunityProcessorFunction: lambda.Function;
    readonly autoArchiveExpiredNofosFunction: lambda.Function;
    constructor(scope: Construct, id: string, props: ScraperStackProps);
}
