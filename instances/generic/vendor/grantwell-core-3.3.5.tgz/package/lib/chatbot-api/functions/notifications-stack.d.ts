/**
 * Nested stack holding the NOFO notification digest Lambda functions and the EventBridge
 * Scheduler entries that drive them. Split out of the main app stack to stay under the
 * 500-resource CloudFormation limit.
 *
 * The SES identity/configuration set, the bounce/complaint SNS topic and the unsubscribe
 * HMAC secret stay in the parent: they are account-scoped or shared state whose physical
 * identity must survive this refactor.
 */
import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as ses from "aws-cdk-lib/aws-ses";
import * as secretsmanager from "aws-cdk-lib/aws-secretsmanager";
import { Table } from "aws-cdk-lib/aws-dynamodb";
import { Branding } from "../../config/instance-config";
export interface NotificationsStackProps extends cdk.NestedStackProps {
    readonly userNotificationPrefsTable: Table;
    readonly nofoMetadataTable: Table;
    readonly digestSendLogTable: Table;
    readonly digestSuppressionTable: Table;
    readonly userPool: cdk.aws_cognito.UserPool;
    /** Shared with functions outside this stack, so it stays in the parent. */
    readonly jsSharedLayer: lambda.ILayerVersion;
    /** Account+region scoped, and its event destination is wired in the parent. */
    readonly sesConfigurationSet: ses.IConfigurationSet;
    /**
     * ARN of the bounce/complaint topic, which stays in the parent. Imported rather than passed
     * as the Topic object: LambdaSubscription.bind() adds a stack dependency for a concrete
     * sns.Topic in another stack, and a nested stack may not depend on its parent.
     */
    readonly sesFeedbackTopicArn: string;
    /** Recreating it would invalidate every unsubscribe link already mailed out. */
    readonly unsubscribeSecret: secretsmanager.ISecret;
    /** Undefined when the deployment has no SES: the digest then neither sends nor runs on a schedule. */
    readonly notificationSender?: string;
    readonly supportedStatesEnv: string;
    readonly siteUrl: string;
    readonly branding: Branding;
    /** Email header logo width at 28 px high. */
    readonly digestLogoWidth: number;
    readonly nofoProcessingReviewTable: Table;
    /** Set only when the deployment has the processing-queue email on (it needs notificationSender). */
    readonly processingQueueEmail?: {
        recipientsParameter: string;
        deploymentId: string;
    };
}
export declare class NotificationsStack extends cdk.NestedStack {
    readonly notificationDigestFunction: lambda.Function;
    readonly notificationDigestPreviewFunction: lambda.Function;
    readonly notificationDigestBroadcastFunction: lambda.Function;
    readonly notificationUnsubscribeFunction: lambda.Function;
    readonly notificationSesFeedbackFunction: lambda.Function;
    readonly processingQueueEmailFunction?: lambda.Function;
    constructor(scope: Construct, id: string, props: NotificationsStackProps);
    private addProcessingQueueEmail;
}
