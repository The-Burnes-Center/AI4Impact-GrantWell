/**
 * This file defines an AWS CDK stack that creates and configures S3 buckets.
 * These buckets are used for storing various types of data.
 * The common properties include versioning, automatic deletion, and CORS configuration.
 */
import * as cdk from 'aws-cdk-lib';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from "constructs";
export declare class S3BucketStack extends cdk.Stack {
    readonly ffioNofosBucket: s3.Bucket;
    readonly userDocumentsBucket: s3.Bucket;
    readonly grantArtifactsBucket: s3.Bucket;
    constructor(scope: Construct, id: string, props: cdk.StackProps & {
        allowedOrigins: string[];
    });
}
