import { Construct } from "constructs";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import * as lambda from "aws-cdk-lib/aws-lambda";
export interface NofoProcessingStateMachineProps {
    extractTextFunction: lambda.Function;
    extractAndAnalyzeFunction: lambda.Function;
    synthesizeFunction: lambda.Function;
    verifySummaryFunction: lambda.Function;
    validateFunction: lambda.Function;
    publishFunction: lambda.Function;
    quarantineFunction: lambda.Function;
}
export declare class NofoProcessingStateMachine extends Construct {
    readonly stateMachine: sfn.StateMachine;
    constructor(scope: Construct, id: string, props: NofoProcessingStateMachineProps);
}
