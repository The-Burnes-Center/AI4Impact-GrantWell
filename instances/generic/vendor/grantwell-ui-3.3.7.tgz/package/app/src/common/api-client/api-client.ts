import { AppConfig } from "../types/app";
import { SessionsClient } from "./sessions-client";
import { UserDocumentsClient } from "./user-documents-client";
import { KBSyncClient } from "./kb-sync-client";
import { LandingPageClient } from "./landing-page-clients";
import { UserManagementClient } from "./user-management-client";
import { DraftsClient } from "./drafts-client";
import { NotificationsClient } from "./notifications-client";
import { AnalyticsClient } from "./analytics-client";
import { UserProfileClient } from "./user-profile-client";
import { OutcomesClient } from "./outcomes-client";

export class ApiClient {
  private _sessionsClient: SessionsClient | undefined;
  private _userDocumentsClient: UserDocumentsClient | undefined;
  private _kbSyncClient: KBSyncClient | undefined;
  private _landingPageClient: LandingPageClient | undefined;
  private _userManagementClient: UserManagementClient | undefined;
  private _draftsClient: DraftsClient | undefined;
  private _notificationsClient: NotificationsClient | undefined;
  private _analyticsClient: AnalyticsClient | undefined;
  private _userProfileClient: UserProfileClient | undefined;
  private _outcomesClient: OutcomesClient | undefined;

  public get userDocuments() {
    if (!this._userDocumentsClient) {
      this._userDocumentsClient = new UserDocumentsClient(this._appConfig);
    }
    return this._userDocumentsClient;
  }

  public get kbSync() {
    if (!this._kbSyncClient) {
      this._kbSyncClient = new KBSyncClient(this._appConfig);
    }
    return this._kbSyncClient;
  }

  public get landingPage() {
    if (!this._landingPageClient) {
      this._landingPageClient = new LandingPageClient(this._appConfig);
    }
    return this._landingPageClient;
  }

  public get sessions() {
    if (!this._sessionsClient) {
      this._sessionsClient = new SessionsClient(this._appConfig);
    }
    return this._sessionsClient;
  }

  public get drafts() {
    if (!this._draftsClient) {
      this._draftsClient = new DraftsClient(this._appConfig);
    }
    return this._draftsClient;
  }

  public get userManagement() {
    if (!this._userManagementClient) {
      this._userManagementClient = new UserManagementClient(this._appConfig);
    }
    return this._userManagementClient;
  }

  public get notifications() {
    if (!this._notificationsClient) {
      this._notificationsClient = new NotificationsClient(this._appConfig);
    }
    return this._notificationsClient;
  }

  public get outcomes() {
    if (!this._outcomesClient) {
      this._outcomesClient = new OutcomesClient(this._appConfig);
    }
    return this._outcomesClient;
  }

  public get analytics() {
    if (!this._analyticsClient) {
      this._analyticsClient = new AnalyticsClient(this._appConfig);
    }
    return this._analyticsClient;
  }

  public get userProfile() {
    if (!this._userProfileClient) {
      this._userProfileClient = new UserProfileClient(this._appConfig);
    }
    return this._userProfileClient;
  }

  constructor(protected _appConfig: AppConfig) {}
}
