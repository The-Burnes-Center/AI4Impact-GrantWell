export type UserRolePreset = "user" | "admin" | "platformadmin" | "developer";

export {
  SUPPORTED_STATES,
  SUPPORTED_STATE_CODES,
  stateNameFromCode,
  stateCodeFromName,
  isSupportedStateCode,
} from "../states";
export type { SupportedStateCode } from "../states";

export interface ManagedUser {
  username: string;
  email: string;
  status: string;
  enabled: boolean;
  roles: string[];
  state: string;
  /** Present only when the deployment asks a Region question. */
  region?: string;
  /** With the structured profile step (PROFILE_FORM). */
  applicantType?: string;
  organization?: string;
  locations?: string[];
}

export interface ManagedUsersResponse {
  /** Every account the caller may see, sorted by email. */
  users: ManagedUser[];
  nextPaginationToken: string | null;
  pageSize: number;
  /** The server stopped scanning before the end of the user pool. */
  truncated?: boolean;
}
