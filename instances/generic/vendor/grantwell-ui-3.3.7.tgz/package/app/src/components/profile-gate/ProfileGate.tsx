import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Spinner } from "react-bootstrap";
import { signOut } from "aws-amplify/auth";
import {
  LuBuilding2,
  LuLandmark,
  LuBriefcase,
  LuMapPin,
  LuArrowRight,
  LuTriangleAlert,
} from "react-icons/lu";
import { useApiClient } from "../../hooks/use-api-client";
import { PROFILE_FIELD_MAX_LENGTH } from "../../common/api-client/user-profile-client";
import { useAdminCheck } from "../../hooks/use-admin-check";
import { useFocusTrap } from "../../hooks/use-focus-trap";
import { SINGLE_STATE, stateNameFromCode } from "../../common/states";
import { PROFILE_FORM, REGIONS } from "../../common/instance";
import { useBranding } from "../../common/branding";
import Button from "../ui/Button";
import ProfileFormFields from "../profile-form/ProfileFormFields";
import { type Answers, EMPTY_ANSWERS, FIELD_ORDER, fieldId, problems, toInput } from "../profile-form/profile-form-logic";
import "./profile-gate.css";

interface ProfileGateProps {
  children: React.ReactNode;
}

type FieldKey = "agency" | "organization" | "jobTitle";

const FIELDS: {
  key: FieldKey;
  label: string;
  placeholder: string;
  /** WCAG 1.3.5 input purpose, where the HTML list has one (it has none for a department). */
  autoComplete?: string;
  Icon: React.ComponentType<{ size?: number; "aria-hidden"?: boolean }>;
}[] = [
  {
    key: "agency",
    label: "Department",
    placeholder: "e.g. Department of Transportation",
    Icon: LuLandmark,
  },
  {
    key: "organization",
    label: "Organization",
    placeholder: "e.g. City of Springfield",
    autoComplete: "organization",
    Icon: LuBuilding2,
  },
  {
    key: "jobTitle",
    label: "Role / Title",
    placeholder: "e.g. Grants Manager",
    autoComplete: "organization-title",
    Icon: LuBriefcase,
  },
];

/**
 * Hard-block gate: an authenticated user cannot use the app until Agency, Organization, and
 * Role/Title are on file. Existing users hit this once on their next login. Fails open — if the
 * profile can't be read, we let the user through rather than trapping them behind a broken gate.
 */
export default function ProfileGate({ children }: ProfileGateProps) {
  const apiClient = useApiClient();
  const { userState } = useAdminCheck();
  const [checking, setChecking] = useState(true);
  const [needsProfile, setNeedsProfile] = useState(false);
  // The user's assigned state, read-only here (set by an admin, not self-chosen). Prefer the
  // profile row; fall back to the JWT claim (a brand-new profile row may not carry it yet).
  const [profileState, setProfileState] = useState("");

  const [values, setValues] = useState<Record<FieldKey, string>>({
    agency: "",
    organization: "",
    jobTitle: "",
  });
  // A field only shows its error once the user has left it (blurred), so we don't scold empty
  // fields before they've had a chance to type.
  const [touched, setTouched] = useState<Record<FieldKey, boolean>>({
    agency: false,
    organization: false,
    jobTitle: false,
  });
  const [region, setRegion] = useState("");
  const [regionTouched, setRegionTouched] = useState(false);
  const [answers, setAnswers] = useState<Answers>(EMPTY_ANSWERS);
  const [submitted, setSubmitted] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const gating = !checking && needsProfile;
  // No onEscape: the gate is a hard block, so Escape must not dismiss it.
  const dialogRef = useFocusTrap<HTMLDivElement>({ isOpen: gating });
  const { appName } = useBranding();

  useEffect(() => {
    if (!gating) return;
    const previous = document.title;
    document.title = `${PROFILE_FORM?.title ?? "Complete your profile"} – ${appName}`;
    return () => {
      document.title = previous;
    };
  }, [gating, appName]);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const profile = await apiClient.userProfile.getProfile();
        if (!active) return;
        setValues({
          agency: profile.agency || "",
          organization: profile.organization || "",
          jobTitle: profile.jobTitle || "",
        });
        setRegion(REGIONS.includes(profile.region) ? profile.region : "");
        // Answers from the old form don't carry over: those users start the new one empty.
        if (profile.applicantType) {
          setAnswers({
            applicantType: profile.applicantType,
            organization: profile.organization || "",
            jobTitle: profile.jobTitle || "",
            locations: profile.locations ?? [],
          });
        }
        setProfileState(profile.state || "");
        setNeedsProfile(!profile.profileComplete);
      } catch {
        // Fail open: don't trap the user behind a gate we can't evaluate.
        if (active) setNeedsProfile(false);
      } finally {
        if (active) setChecking(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [apiClient]);

  const allFilled = useMemo(
    () => FIELDS.every((f) => values[f.key].trim().length > 0) && (REGIONS.length === 0 || region !== ""),
    [values, region]
  );

  const setField = (key: FieldKey, value: string) =>
    setValues((prev) => ({ ...prev, [key]: value }));

  // The focus trap seals the page chrome off, so the gate has to carry its own way out.
  const onSignOut = useCallback(async () => {
    try {
      await signOut();
    } catch (err) {
      console.error("Error signing out:", err);
    } finally {
      window.location.assign("/");
    }
  }, []);

  const onSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      const form = PROFILE_FORM;
      if (form) {
        const found = problems(form, answers);
        const first = FIELD_ORDER.find((f) => found[f]);
        setSubmitted(true);
        if (first) {
          setError("Fix the fields marked below.");
          document.getElementById(fieldId("gate", first))?.focus();
          return;
        }
        setSaving(true);
        setError(null);
        try {
          await apiClient.userProfile.updateProfile(toInput(form, answers));
          setNeedsProfile(false);
        } catch (err) {
          setError(err instanceof Error ? err.message : "Could not save your profile.");
        } finally {
          setSaving(false);
        }
        return;
      }
      setTouched({ agency: true, organization: true, jobTitle: true });
      setRegionTouched(true);
      if (!allFilled) {
        setError(REGIONS.length ? "Please complete all four fields." : "Please complete all three fields.");
        return;
      }
      setSaving(true);
      setError(null);
      try {
        await apiClient.userProfile.updateProfile({
          agency: values.agency.trim(),
          organization: values.organization.trim(),
          jobTitle: values.jobTitle.trim(),
          ...(REGIONS.length && { region }),
        });
        setNeedsProfile(false);
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Could not save your profile."
        );
      } finally {
        setSaving(false);
      }
    },
    [apiClient, allFilled, values, region, answers]
  );

  if (!checking && !needsProfile) {
    return <>{children}</>;
  }

  const effectiveState = SINGLE_STATE?.code || profileState || userState || "";
  const stateLabel = effectiveState
    ? stateNameFromCode(effectiveState) || effectiveState
    : "";

  // One region, mounted for the whole life of the gate, so the checking -> saving
  // transitions are updates to an existing region rather than fresh insertions.
  return (
    <>
      <div role="status" aria-live="polite" className="visually-hidden">
        {checking ? "Checking your profile" : saving ? "Saving your profile" : ""}
      </div>
      {checking ? (
        <div className="profile-gate__loading">
          <Spinner animation="border" size="sm" aria-hidden="true" />
          <span aria-hidden="true">Loading</span>
        </div>
      ) : (
        <div
          className="profile-gate"
          role="dialog"
          aria-modal="true"
          aria-labelledby="profile-gate-title"
          ref={dialogRef}
        >
          <div className={`gw-modal profile-gate__panel${PROFILE_FORM ? " profile-gate__panel--wide" : ""}`}>
            <header className="gw-modal__header profile-gate__header">
              <span className="profile-gate__header-icon" aria-hidden="true">
                <LuBuilding2 size={22} />
              </span>
              <h2 className="gw-modal__title profile-gate__title" id="profile-gate-title">
                {PROFILE_FORM?.title ?? "Complete your profile"}
              </h2>
            </header>

            <div className="gw-modal__body profile-gate__body">
              <p className="profile-gate__lead">
                {PROFILE_FORM ? (
                  PROFILE_FORM.lead
                ) : (
                  <>
                    One-time setup. Tell us a little about where you work — this helps us
                    understand who&apos;s using GrantWell.
                  </>
                )}
              </p>
              {PROFILE_FORM && (
                <p className="profile-gate__lead profile-gate__lead--note">
                  Fields marked <span aria-hidden="true">*</span>
                  <span className="visually-hidden">with an asterisk</span> are required.
                </p>
              )}

              {/* The empty slot is the live region; the styled alert is inserted into it. */}
              <div role="alert">
                {error && (
                  <div className="gw-alert gw-alert--urgent profile-gate__alert">
                    <LuTriangleAlert size={16} aria-hidden="true" />
                    <span>{error}</span>
                  </div>
                )}
              </div>

              <form onSubmit={onSubmit} noValidate>
                {PROFILE_FORM && (
                  <div className="profile-gate__form-fields">
                    <ProfileFormFields
                      form={PROFILE_FORM}
                      value={answers}
                      onChange={setAnswers}
                      idPrefix="gate"
                      errors={submitted ? problems(PROFILE_FORM, answers) : {}}
                    />
                  </div>
                )}
                {!PROFILE_FORM && FIELDS.map(({ key, label, placeholder, autoComplete, Icon }) => {
                  const showError = touched[key] && values[key].trim().length === 0;
                  const inputId = `gate-${key}`;
                  return (
                    <div className="profile-gate__field" key={key}>
                      <label className="profile-gate__label" htmlFor={inputId}>
                        {label} <span className="profile-gate__req">*</span>
                      </label>
                      <div
                        className={`profile-gate__input-wrap ${
                          showError ? "profile-gate__input-wrap--error" : ""
                        }`}
                      >
                        <span className="profile-gate__field-icon" aria-hidden="true">
                          <Icon size={16} />
                        </span>
                        <input
                          id={inputId}
                          type="text"
                          value={values[key]}
                          onChange={(e) => setField(key, e.target.value)}
                          onBlur={() =>
                            setTouched((prev) => ({ ...prev, [key]: true }))
                          }
                          placeholder={placeholder}
                          autoComplete={autoComplete}
                          maxLength={PROFILE_FIELD_MAX_LENGTH}
                          required
                          aria-invalid={showError}
                          aria-describedby={showError ? `${inputId}-err` : undefined}
                        />
                      </div>
                      {showError && (
                        <p
                          className="profile-gate__field-error"
                          id={`${inputId}-err`}
                        >
                          <LuTriangleAlert size={13} aria-hidden="true" />
                          {label} is required
                        </p>
                      )}
                    </div>
                  );
                })}

                {REGIONS.length > 0 && (
                  <div className="profile-gate__field">
                    <label className="profile-gate__label" htmlFor="gate-region">
                      Region <span className="profile-gate__req">*</span>
                    </label>
                    <div
                      className={`profile-gate__input-wrap ${
                        regionTouched && !region ? "profile-gate__input-wrap--error" : ""
                      }`}
                    >
                      <span className="profile-gate__field-icon" aria-hidden="true">
                        <LuMapPin size={16} />
                      </span>
                      <select
                        id="gate-region"
                        value={region}
                        onChange={(e) => setRegion(e.target.value)}
                        onBlur={() => setRegionTouched(true)}
                        required
                        aria-invalid={regionTouched && !region}
                        aria-describedby={regionTouched && !region ? "gate-region-err" : undefined}
                      >
                        <option value="">Select a region</option>
                        {REGIONS.map((r) => (
                          <option key={r} value={r}>
                            {r}
                          </option>
                        ))}
                      </select>
                    </div>
                    {regionTouched && !region && (
                      <p className="profile-gate__field-error" id="gate-region-err">
                        <LuTriangleAlert size={13} aria-hidden="true" />
                        Region is required
                      </p>
                    )}
                  </div>
                )}

                <div className="profile-gate__field">
                  <label className="profile-gate__label" htmlFor="gate-state">
                    State
                  </label>
                  <div className="profile-gate__input-wrap profile-gate__input-wrap--readonly">
                    <span className="profile-gate__field-icon" aria-hidden="true">
                      <LuMapPin size={16} />
                    </span>
                    <select
                      id="gate-state"
                      value={effectiveState}
                      disabled
                      aria-readonly="true"
                      title={SINGLE_STATE ? undefined : "Contact your administrator to change your state."}
                    >
                      {effectiveState ? (
                        <option value={effectiveState}>{stateLabel}</option>
                      ) : (
                        <option value="">Not assigned</option>
                      )}
                    </select>
                  </div>
                  {!SINGLE_STATE && (
                    <p className="profile-gate__hint">
                      Contact your administrator to change your state.
                    </p>
                  )}
                </div>

                <Button
                  type="submit"
                  loading={saving}
                  fullWidth
                >
                  <span className="profile-gate__submit-content">
                    Save and continue
                    <LuArrowRight size={16} aria-hidden="true" />
                  </span>
                </Button>
              </form>

              <button
                type="button"
                className="profile-gate__signout"
                onClick={onSignOut}
                aria-label="Sign out instead"
              >
                Sign out instead
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
