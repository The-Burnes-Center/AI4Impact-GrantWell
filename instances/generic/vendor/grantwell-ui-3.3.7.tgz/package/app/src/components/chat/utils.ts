import { ChatBotHistoryItem, ChatBotMessageType } from "./types";

type ChatMetadata = ChatBotHistoryItem["metadata"];

const ERROR_SENTINEL = "<!ERROR!>:";

export const CHAT_ERROR_MESSAGE = "Something went wrong while answering. Try again in a moment.";

/**
 * The user-facing text of an error frame from the chat socket: whatever follows
 * the error sentinel, or a plain default when nothing does.
 */
export function chatErrorText(frame: string): string {
  const at = frame.indexOf(ERROR_SENTINEL);
  const text = at === -1 ? "" : frame.slice(at + ERROR_SENTINEL.length).trim();
  return text || CHAT_ERROR_MESSAGE;
}

export const RESET_SENTINEL = "<!RESET!>";

/**
 * API Gateway's own frames on the chat socket, such as `{"message": "Endpoint request timed out",
 * "connectionId": "…", "requestId": "…"}`. They are never part of the answer.
 */
export function isGatewayErrorFrame(frame: unknown): boolean {
  if (typeof frame !== "string" || !frame.trimStart().startsWith("{")) return false;
  try {
    const parsed: unknown = JSON.parse(frame);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return false;
    const record = parsed as Record<string, unknown>;
    return typeof record.message === "string" && ("connectionId" in record || "requestId" in record);
  } catch {
    return false;
  }
}

/**
 * Converts backend chat history format to frontend format
 * Backend format: [{ user: "message", chatbot: "response", metadata: "..." }]
 * Frontend format: [{ type: "Human", content: "...", metadata: {} }, { type: "AI", content: "...", metadata: {...} }]
 */
export function parseChatHistory(backendHistory: Array<Record<string, unknown>>): ChatBotHistoryItem[] {
  if (!backendHistory || !Array.isArray(backendHistory)) {
    return [];
  }

  const frontendHistory: ChatBotHistoryItem[] = [];

  for (const entry of backendHistory) {
    // Handle both old format (user/chatbot) and new format (type/content)
    if (entry.user !== undefined && entry.chatbot !== undefined) {
      // Backend format: { user: "...", chatbot: "...", metadata: "..." }
      // Handle case where user is empty string (initial greeting)
      const isEmptyUser = entry.user === "";
      
      let metadata: ChatMetadata = {};
      try {
        // Metadata might be a string or already an object
        if (typeof entry.metadata === 'string') {
          const parsed = JSON.parse(entry.metadata);
          // If parsed result is an array, wrap it in Sources object (for compatibility with ChatMessage component)
          if (Array.isArray(parsed)) {
            metadata = { Sources: parsed } as ChatMetadata;
          } else {
            metadata = parsed as ChatMetadata;
          }
        } else if (entry.metadata) {
          // If it's already an object but has an array at root, wrap it
          if (Array.isArray(entry.metadata)) {
            metadata = { Sources: entry.metadata } as ChatMetadata;
          } else {
            metadata = entry.metadata as ChatMetadata;
          }
        }
      } catch (e) {
        console.warn('Failed to parse metadata:', e);
        metadata = {};
      }

      // Only add user message if it's not empty (for initial greetings)
      if (!isEmptyUser) {
        frontendHistory.push({
          type: ChatBotMessageType.Human,
          content: String(entry.user),
          metadata: {},
        });
      }

      frontendHistory.push({
        type: ChatBotMessageType.AI,
        content: String(entry.chatbot),
        metadata: metadata,
      });
    } else if (entry.type && entry.content) {
      // Already in frontend format, just ensure metadata is an object
      let metadata: ChatMetadata = (entry.metadata || {}) as ChatMetadata;
      
      // Ensure Sources array is properly formatted if metadata exists
      if (metadata && typeof metadata === 'object' && !('Sources' in metadata) && Array.isArray(metadata)) {
        metadata = { Sources: metadata } as ChatMetadata;
      }
      
      frontendHistory.push({
        type: entry.type as ChatBotMessageType,
        content: String(entry.content),
        metadata: metadata,
      });
    }
  }

  return frontendHistory;
}
