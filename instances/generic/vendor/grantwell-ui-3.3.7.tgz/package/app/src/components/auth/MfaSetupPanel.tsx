import { useEffect, useRef, useState } from "react";
import { setUpTOTP, verifyTOTPSetup, updateMFAPreference } from "aws-amplify/auth";
import Button from "../ui/Button";
import OtpInput from "./OtpInput";
import TotpEnrollment from "./TotpEnrollment";
import MfaRecoveryNote from "./MfaRecoveryNote";
import { useBranding } from "../../common/branding";

interface MfaSetupPanelProps {
  email: string;
  onEnrolled: () => void;
  onCancel?: () => void;
  cancelLabel?: string;
}

/**
 * Self-service TOTP enrolment, for use outside the sign-in challenge.
 *
 * The sign-in flow receives totpSetupDetails from Cognito when MFA is REQUIRED. With MFA
 * OPTIONAL that challenge never fires, so we start the enrolment ourselves via setUpTOTP, as soon
 * as the panel opens: whatever opened it was already the "set it up" click.
 */
/** Takes focus when it opens: it replaces the button that opened it, which would leave focus on <body>. */
export default function MfaSetupPanel(props: MfaSetupPanelProps) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => root.current?.focus(), []);
  return (
    <div ref={root} tabIndex={-1} aria-label="Set up two-step verification" role="group">
      <SetupSteps {...props} />
    </div>
  );
}

function SetupSteps({
  email,
  onEnrolled,
  onCancel,
  cancelLabel = "Cancel",
}: MfaSetupPanelProps) {
  const branding = useBranding();
  const [setup, setSetup] = useState<{ uri: string; secret: string } | null>(null);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState(true);
  const started = useRef(false);

  const begin = async () => {
    setStarting(true);
    setError(null);
    try {
      const details = await setUpTOTP();
      setSetup({
        uri: details.getSetupUri(branding.appName, email).toString(),
        secret: details.sharedSecret,
      });
    } catch (err) {
      console.error("Could not start TOTP setup", err);
      setError("Could not start two-step verification setup. Try again in a moment.");
    } finally {
      setStarting(false);
    }
  };

  useEffect(() => {
    // StrictMode mounts twice in development; one setUpTOTP per panel, or the first secret is void.
    if (started.current) return;
    started.current = true;
    void begin();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const confirm = async (event: React.FormEvent) => {
    event.preventDefault();
    if (code.trim().length !== 6) {
      setError("Enter the 6-digit code from your authenticator app.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await verifyTOTPSetup({ code: code.trim() });
      // Verifying alone does not enable it on the account.
      await updateMFAPreference({ totp: "PREFERRED" });
      onEnrolled();
    } catch (err) {
      console.error("Could not verify TOTP setup", err);
      setCode("");
      setError("That code was not accepted. Check your authenticator app and try again.");
    } finally {
      setBusy(false);
    }
  };

  if (!setup) {
    return (
      <div>
        {error ? (
          <div className="gw-alert gw-alert--urgent profile-alert profile-alert--error" role="alert">
            {error}
          </div>
        ) : (
          <p className="profile-hint" role="status">
            Starting setup…
          </p>
        )}
        <div className="profile-actions">
          {error && (
            <Button type="button" onClick={begin} loading={starting}>
              Try again
            </Button>
          )}
          {onCancel && (
            <Button type="button" variant="ghost" onClick={onCancel} disabled={starting}>
              {cancelLabel}
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={confirm}>
      {error && (
        <div className="gw-alert gw-alert--urgent profile-alert profile-alert--error" role="alert">
          {error}
        </div>
      )}
      <TotpEnrollment setupUri={setup.uri} secret={setup.secret} />
      <div className="profile-section">
        <span className="profile-field-label" id="mfa-panel-code-label">
          Authentication code
        </span>
        <OtpInput
          value={code}
          onChange={setCode}
          idPrefix="mfa-panel"
          labelId="mfa-panel-code-label"
          loading={busy}
          invalid={Boolean(error)}
        />
      </div>
      <MfaRecoveryNote />
      <div className="profile-actions">
        <Button type="submit" loading={busy}>
          Turn on two-step verification
        </Button>
        {onCancel && (
          <Button type="button" variant="ghost" onClick={onCancel} disabled={busy}>
            {cancelLabel}
          </Button>
        )}
      </div>
    </form>
  );
}
