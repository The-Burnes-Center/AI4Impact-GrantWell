import React, { useState, useEffect, useMemo } from "react";
import { LuFileX, LuX, LuArrowUp, LuArrowDown, LuArrowUpDown, LuPin } from "react-icons/lu";
import type { NOFO, GrantTypeId } from "../../common/types/nofo";
import { GRANT_TYPES, grantTypeTint, nofoDisplayName } from "../../common/types/nofo";
import { Utils } from "../../common/utils";
import PaginationControls from "../../components/common/PaginationControls";
import TableScrollRegion from "../../components/ui/TableScrollRegion";
import type { AISearchResult } from "../../hooks/use-ai-grant-search";
import "../../styles/landing-page-table.css";
import FilterSelect from "../../components/ui/FilterSelect";

type SortColumn = "name" | "agency" | "category" | "type" | "deadline";
type SortDirection = "asc" | "desc";

const SORT_COLUMN_LABELS: Record<SortColumn, string> = {
  name: "Name",
  agency: "Agency",
  category: "Category",
  type: "Type",
  deadline: "Deadline",
};

const NEW_GRANT_WINDOW_DAYS = 3;

const isRecentlyAdded = (createdAt?: string | null): boolean => {
  if (!createdAt) return false;
  const created = Date.parse(createdAt);
  if (Number.isNaN(created)) return false;
  const ageDays = (Date.now() - created) / (1000 * 60 * 60 * 24);
  return ageDays >= 0 && ageDays <= NEW_GRANT_WINDOW_DAYS;
};

interface GrantsTableProps {
  nofos: NOFO[];
  loading: boolean;
  onSelectDocument: (document: { label: string; value: string }) => void;
  searchTerm?: string;
  searchResults?: AISearchResult[] | null;
  isSearching?: boolean;
  isSearchPending?: boolean;
  searchError?: string | null;
  onClearSearch?: () => void;
  preferAISearch?: boolean;
}

export const GrantsTable: React.FC<GrantsTableProps> = ({
  nofos,
  loading,
  onSelectDocument,
  searchTerm = "",
  searchResults = null,
  isSearching = false,
  isSearchPending = false,
  searchError = null,
  onClearSearch,
  preferAISearch = false,
}) => {
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "archived">("active");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [grantTypeFilter, setGrantTypeFilter] = useState<GrantTypeId | "all">("all");
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [showAllAIResults, setShowAllAIResults] = useState(false);
  const [sortColumn, setSortColumn] = useState<SortColumn | null>(null);
  const [sortDirection, setSortDirection] = useState<SortDirection>("asc");
  const [resultsAnnouncement, setResultsAnnouncement] = useState("");
  const itemsPerPage = 10;
  const AI_INITIAL_LIMIT = 10;

  const uniqueCategories = Array.from(
    new Set(nofos.map((nofo) => nofo.category).filter((category): category is string => !!category))
  ).sort((a, b) => Number(a === "Other") - Number(b === "Other") || a.localeCompare(b));

  const getCategoryCount = (category: string) => {
    return nofos.filter((nofo) => {
      return (
        nofo.category === category &&
        (statusFilter === "all" || nofo.status === statusFilter) &&
        (grantTypeFilter === "all" || nofo.grantType === grantTypeFilter)
      );
    }).length;
  };

  const getStatusCount = (status: "active" | "archived") => {
    return nofos.filter((nofo) => {
      return (
        nofo.status === status &&
        (categoryFilter === "all" || nofo.category === categoryFilter) &&
        (grantTypeFilter === "all" || nofo.grantType === grantTypeFilter)
      );
    }).length;
  };

  const getGrantTypeCount = (grantType: GrantTypeId) => {
    return nofos.filter((nofo) => {
      return (
        nofo.grantType === grantType &&
        (statusFilter === "all" || nofo.status === statusFilter) &&
        (categoryFilter === "all" || nofo.category === categoryFilter)
      );
    }).length;
  };

  const scoreMap = useMemo(() => {
    if (!searchResults) return null;
    const map = new Map<string, AISearchResult>();
    for (const r of searchResults) {
      map.set(r.name.toLowerCase().replace(/\/$/, ""), r);
    }
    return map;
  }, [searchResults]);

  const awaitingAIResults = isSearching || (isSearchPending && searchResults === null);

  const handleSort = (column: SortColumn) => {
    if (sortColumn !== column) {
      setSortColumn(column);
      setSortDirection("asc");
    } else if (sortDirection === "asc") {
      setSortDirection("desc");
    } else {
      setSortColumn(null);
      setSortDirection("asc");
    }
  };

  const resetSort = () => {
    setSortColumn(null);
    setSortDirection("asc");
  };

  // "active" is the default status, so it's not a user-applied filter for clear-button purposes.
  const hasActiveFilters =
    statusFilter !== "active" || categoryFilter !== "all" || grantTypeFilter !== "all";

  const clearFilters = () => {
    setStatusFilter("active");
    setCategoryFilter("all");
    setGrantTypeFilter("all");
  };

  const compareByColumn = (a: NOFO, b: NOFO, col: SortColumn, dir: SortDirection): number => {
    const mul = dir === "asc" ? 1 : -1;
    const stringCmp = (av: string | null | undefined, bv: string | null | undefined) => {
      // Missing values always sort last, regardless of direction
      const aEmpty = !av;
      const bEmpty = !bv;
      if (aEmpty && bEmpty) return 0;
      if (aEmpty) return 1;
      if (bEmpty) return -1;
      return av!.localeCompare(bv!, undefined, { sensitivity: "base" }) * mul;
    };

    switch (col) {
      case "name":
        return a.name.localeCompare(b.name, undefined, { sensitivity: "base" }) * mul;
      case "agency":
        return stringCmp(a.agency, b.agency);
      case "category":
        return stringCmp(a.category, b.category);
      case "type": {
        const aLabel = a.grantType ? GRANT_TYPES[a.grantType]?.label : null;
        const bLabel = b.grantType ? GRANT_TYPES[b.grantType]?.label : null;
        return stringCmp(aLabel, bLabel);
      }
      case "deadline": {
        // N/A always last; Rolling first when asc, last (before N/A) when desc
        const aNA = !a.isRolling && !a.expirationDate;
        const bNA = !b.isRolling && !b.expirationDate;
        if (aNA && bNA) return 0;
        if (aNA) return 1;
        if (bNA) return -1;
        if (a.isRolling && b.isRolling) return 0;
        if (a.isRolling) return dir === "asc" ? -1 : 1;
        if (b.isRolling) return dir === "asc" ? 1 : -1;
        return (new Date(a.expirationDate!).getTime() - new Date(b.expirationDate!).getTime()) * mul;
      }
    }
  };

  const getFilteredNofos = () => {
    const searchLower = searchTerm.toLowerCase().trim();
    const hasRankedResults = scoreMap !== null && scoreMap.size > 0;

    let filtered = nofos.filter((nofo) => {
      const normalizedName = nofo.name.toLowerCase().replace(/\/$/, "");

      if (hasRankedResults) {
        if (!scoreMap.has(normalizedName)) return false;
      } else if (searchLower !== "" && !awaitingAIResults) {
        const tokens = searchLower.split(/\s+/).filter(Boolean);
        const searchableText = [
          nofo.name,
          nofo.agency,
          nofo.category,
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();
        const matchesSearch = tokens.every((token) => searchableText.includes(token));
        if (!matchesSearch) return false;
      }

      const matchesStatus = statusFilter === "all" || nofo.status === statusFilter;
      const matchesCategory = categoryFilter === "all" || nofo.category === categoryFilter;
      const matchesGrantType = grantTypeFilter === "all" || nofo.grantType === grantTypeFilter;

      return matchesStatus && matchesCategory && matchesGrantType;
    });

    if (sortColumn) {
      filtered.sort((a, b) => {
        // Keep pinned rows on top when browsing; AI-ranked mode ignores pinning
        if (!hasRankedResults) {
          if (a.isPinned && !b.isPinned) return -1;
          if (!a.isPinned && b.isPinned) return 1;
        }
        return compareByColumn(a, b, sortColumn, sortDirection);
      });
    } else if (hasRankedResults) {
      filtered.sort((a, b) => {
        const scoreA = scoreMap.get(a.name.toLowerCase().replace(/\/$/, ""))?.score ?? 0;
        const scoreB = scoreMap.get(b.name.toLowerCase().replace(/\/$/, ""))?.score ?? 0;
        return scoreB - scoreA;
      });
    } else {
      filtered.sort((a, b) => {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        return a.name.localeCompare(b.name, undefined, { sensitivity: "base" });
      });
    }

    return filtered;
  };

  const filteredNofos = getFilteredNofos();

  const hasRankedResults = scoreMap !== null && scoreMap.size > 0;

  const totalPages = Math.ceil(filteredNofos.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;

  // For AI results: show top 10 initially, expand on "Show more".
  // For normal browsing: use existing pagination.
  const visibleNofos = hasRankedResults
    ? (showAllAIResults ? filteredNofos : filteredNofos.slice(0, AI_INITIAL_LIMIT))
    : filteredNofos.slice(startIndex, endIndex);

  // New AI results rank by score; the user's filters stay, so expired grants appear only under All or Archived.
  useEffect(() => {
    if (searchResults && searchResults.length > 0) {
      setShowAllAIResults(false);
      setSortColumn(null);
      setSortDirection("asc");
    }
  }, [searchResults]);

  useEffect(() => {
    setCurrentPage(1);
  }, [statusFilter, categoryFilter, grantTypeFilter, searchTerm, searchResults, preferAISearch, sortColumn, sortDirection]);

  // Written from an effect rather than during render so the live region is always
  // mounted and empty before its text arrives; a region created together with its
  // text is not reliably announced.
  useEffect(() => {
    if (awaitingAIResults) {
      setResultsAnnouncement("");
      return;
    }
    if (filteredNofos.length === 0) {
      setResultsAnnouncement(
        searchTerm
          ? `No grants found matching "${searchTerm}"`
          : "No grants found matching your filters"
      );
      return;
    }
    const total = `${filteredNofos.length} grant${filteredNofos.length !== 1 ? "s" : ""}`;
    setResultsAnnouncement(
      totalPages > 1 && !hasRankedResults
        ? `Showing ${visibleNofos.length} of ${total}, page ${currentPage} of ${totalPages}`
        : `Showing ${visibleNofos.length} of ${total}`
    );
  }, [
    awaitingAIResults,
    filteredNofos.length,
    visibleNofos.length,
    hasRankedResults,
    currentPage,
    totalPages,
    searchTerm,
  ]);

  const handleRowClick = (nofo: NOFO) => {
    onSelectDocument({
      label: nofo.name,
      value: nofo.name + "/",
    });
    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, 150);
  };

  if (loading) {
    return (
      <div className="landing-table-loading">
        <p>Loading grants...</p>
      </div>
    );
  }

  const getGrantTypeBadgeClassName = () => "gw-tag landing-grant-type-badge";

  return (
    <div className="landing-grants-table-container">
      {/* Filter Dropdowns */}
      <div className="gw-filters landing-table-filters">
        <FilterSelect<"all" | "active" | "archived">
          id="status-filter"
          label="Status"
          value={statusFilter}
          onChange={setStatusFilter}
          options={[
            {
              value: "all",
              label: `All grants (${nofos.filter((nofo) =>
                (categoryFilter === "all" || nofo.category === categoryFilter) &&
                (grantTypeFilter === "all" || nofo.grantType === grantTypeFilter)
              ).length})`,
            },
            { value: "active", label: `Active (${getStatusCount("active")})` },
            { value: "archived", label: `Archived (${getStatusCount("archived")})` },
          ]}
        />

        <FilterSelect
          id="category-filter"
          label="Category"
          value={categoryFilter}
          onChange={setCategoryFilter}
          options={[
            {
              value: "all",
              label: `All categories (${nofos.filter((nofo) =>
                (statusFilter === "all" || nofo.status === statusFilter) &&
                (grantTypeFilter === "all" || nofo.grantType === grantTypeFilter)
              ).length})`,
            },
            ...uniqueCategories.map((category) => ({ value: category, label: `${category} (${getCategoryCount(category)})` })),
          ]}
        />

        <FilterSelect<GrantTypeId | "all">
          id="grant-type-filter"
          label="Grant type"
          value={grantTypeFilter}
          onChange={setGrantTypeFilter}
          options={[
            {
              value: "all",
              label: `All grant types (${nofos.filter((nofo) =>
                (statusFilter === "all" || nofo.status === statusFilter) &&
                (categoryFilter === "all" || nofo.category === categoryFilter)
              ).length})`,
            },
            ...(Object.keys(GRANT_TYPES) as GrantTypeId[]).map((type) => ({
              value: type,
              label: `${GRANT_TYPES[type].label} (${getGrantTypeCount(type)})`,
            })),
          ]}
        />

        {hasActiveFilters && (
          <button
            type="button"
            className="gw-btn gw-btn--secondary landing-clear-filters-button"
            onClick={clearFilters}
            aria-label="Clear filters — reset all active filters"
          >
            <LuX size={14} aria-hidden="true" />
            Clear filters
          </button>
        )}
      </div>

      {/* Error banner. Announcing from the banner itself would create the region
          together with its text and sweep the dismiss button's label into the
          message, so the alert below carries the announcement instead. */}
      {searchError && (
        <div className="gw-alert gw-alert--urgent search-status-banner search-status-banner--error">
          <span>Search failed: {searchError}</span>
          {onClearSearch && (
            <button className="gw-btn gw-btn--secondary gw-btn--slim search-clear-button" onClick={onClearSearch} aria-label="Dismiss error">
              <LuX size={16} aria-hidden="true" />
            </button>
          )}
        </div>
      )}
      <div role="alert" aria-atomic="true" className="visually-hidden">
        {searchError ? `Search failed: ${searchError}` : ""}
      </div>

      {/* Results summary. Announced by the results region below, not here — this
          banner is built at the same moment as its text and contains a button. */}
      {searchResults && !isSearching && !searchError && (
        <div className="gw-alert gw-alert--brand search-status-banner">
          <span>
            Found <strong>{filteredNofos.length}</strong> grant{filteredNofos.length !== 1 ? "s" : ""} matching
            your search{!showAllAIResults && filteredNofos.length > AI_INITIAL_LIMIT
              ? ` (showing top ${AI_INITIAL_LIMIT})`
              : ""}
            {sortColumn && (
              <>
                {" · "}Sorted by {SORT_COLUMN_LABELS[sortColumn]}{" "}
                <button
                  type="button"
                  className="landing-sort-reset-link"
                  onClick={resetSort}
                >
                  back to relevance
                </button>
              </>
            )}
          </span>
        </div>
      )}

      {/* Kept mounted and empty when idle: a live region created at the same
          moment as its text is unreliably announced. */}
      <div role="status" aria-live="polite" aria-atomic="true" className="visually-hidden">
        {awaitingAIResults ? "Searching grants with AI…" : ""}
      </div>

      {/* Single announcement point for the result count: search, filter, sort,
          pagination and the empty state all resolve to this one region. */}
      <div role="status" aria-live="polite" aria-atomic="true" className="visually-hidden">
        {resultsAnnouncement}
      </div>

      <TableScrollRegion label="Grants table" className="landing-table-scroll">
      <div className="landing-table-container" role="table" aria-label="Grants" aria-busy={awaitingAIResults}>
        <div className="landing-table-header" role="rowgroup">
          <div className="landing-table-header-row" role="row">
            {(Object.keys(SORT_COLUMN_LABELS) as SortColumn[]).map((col) => {
              const isActive = sortColumn === col;
              const ariaSort = isActive ? (sortDirection === "asc" ? "ascending" : "descending") : "none";
              const Icon = isActive ? (sortDirection === "asc" ? LuArrowUp : LuArrowDown) : LuArrowUpDown;
              return (
                <div key={col} role="columnheader" aria-sort={ariaSort} className="landing-header-cell-wrapper">
                  <button
                    type="button"
                    className={`landing-header-cell landing-header-cell--sortable${isActive ? " landing-header-cell--active" : ""}`}
                    onClick={() => handleSort(col)}
                  >
                    <span>{SORT_COLUMN_LABELS[col]}</span>
                    <Icon size={12} className="landing-header-sort-icon" aria-hidden="true" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        <div className="landing-table-body" role={awaitingAIResults || visibleNofos.length === 0 ? undefined : "rowgroup"}>
          {awaitingAIResults ? (
            <div className="landing-search-loading" aria-hidden="true">
              <div className="skeleton-row-group">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="skeleton-row" aria-hidden="true">
                    <div className="skeleton-cell skeleton-cell--wide"><div className="skeleton-bar" /></div>
                    <div className="skeleton-cell"><div className="skeleton-bar" /></div>
                    <div className="skeleton-cell"><div className="skeleton-bar" /></div>
                    <div className="skeleton-cell skeleton-cell--narrow"><div className="skeleton-bar" /></div>
                    <div className="skeleton-cell skeleton-cell--narrow"><div className="skeleton-bar" /></div>
                  </div>
                ))}
              </div>
              <p className="search-loading-text">
                <span className="search-spinner" />
                Searching grants with AI&hellip;
              </p>
            </div>
          ) : filteredNofos.length === 0 ? (
            // Announced by the results region above; a role here would double it up.
            <div className="landing-no-data">
              <LuFileX size={24} className="landing-no-data-icon" aria-hidden="true" />
              <p>
                {searchTerm
                  ? `No grants found matching "${searchTerm}"`
                  : "No grants found matching your filters"}
              </p>
            </div>
          ) : null}
          {!awaitingAIResults && visibleNofos.map((nofo) => {
            const isArchived = nofo.status === "archived";
            const { title, stateBadge } = nofoDisplayName(nofo);
            return (
              <div
                key={nofo.name}
                role="row"
                className={`landing-table-row ${isArchived ? "archived" : ""}`}
                style={{
                  cursor: isArchived ? "not-allowed" : "pointer",
                  backgroundColor: isArchived ? "var(--gw-color-background)" : undefined,
                }}
              >
                <div className="landing-row-cell" role="cell">
                  {nofo.isPinned && (
                    <LuPin
                      size={14}
                      className="landing-pinned-icon"
                      role="img"
                      aria-label="Pinned — featured by an administrator"
                      title="Pinned — featured by an administrator"
                    />
                  )}
                  <button
                    type="button"
                    className="landing-nofo-name-button"
                    disabled={isArchived}
                    onClick={() => handleRowClick(nofo)}
                    aria-label={
                      isArchived
                        ? `${title} (Expired - no longer accepting applications)`
                        : `Select ${title}${stateBadge ? `, maintained by ${stateBadge}` : ""}`
                    }
                  >
                    <span className="landing-nofo-name" style={{ color: isArchived ? "var(--gw-color-text-muted)" : undefined }}>
                      {title}
                    </span>
                  </button>
                  {stateBadge && (
                    <span className="gw-tag gw-tag--neutral landing-state-badge" title={`Maintained by ${stateBadge}`}>
                      <span aria-hidden="true">{nofo.state}</span>
                      <span className="visually-hidden">Maintained by {stateBadge}</span>
                    </span>
                  )}
                  {!isArchived && isRecentlyAdded(nofo.createdAt) && (
                    <span
                      className="gw-tag gw-tag--info landing-new-badge"
                      title={`Added within the last ${NEW_GRANT_WINDOW_DAYS} days`}
                    >
                      New
                      <span className="visually-hidden">: added within the last {NEW_GRANT_WINDOW_DAYS} days</span>
                    </span>
                  )}
                  {isArchived && (
                    <span
                      className="gw-tag gw-tag--neutral landing-expired-badge"
                      title="This grant has expired and is no longer accepting applications"
                    >
                      Expired
                      <span className="visually-hidden">: no longer accepting applications</span>
                    </span>
                  )}
                </div>
                <div className="landing-row-cell" role="cell" style={{ color: isArchived ? "var(--gw-color-text-muted)" : undefined }}>
                  {nofo.agency || <span className="landing-no-value">N/A</span>}
                </div>
                <div className="landing-row-cell" role="cell" style={{ color: isArchived ? "var(--gw-color-text-muted)" : undefined }}>
                  {nofo.category || <span className="landing-no-value">N/A</span>}
                </div>
                <div className="landing-row-cell" role="cell">
                  {nofo.grantType && GRANT_TYPES[nofo.grantType] ? (
                    <span
                      className={getGrantTypeBadgeClassName()}
                      style={{
                        backgroundColor: grantTypeTint(GRANT_TYPES[nofo.grantType].color, 8),
                        color: GRANT_TYPES[nofo.grantType].color,
                        borderColor: grantTypeTint(GRANT_TYPES[nofo.grantType].color, 25),
                      }}
                    >
                      {GRANT_TYPES[nofo.grantType].label}
                    </span>
                  ) : (
                    <span className="gw-tag landing-grant-type-badge unset">Unset</span>
                  )}
                </div>
                <div className="landing-row-cell" role="cell" style={{ color: isArchived ? "var(--gw-color-text-muted)" : undefined }}>
                  {nofo.isRolling ? (
                    <span className="landing-expiry-date rolling">Rolling</span>
                  ) : nofo.expirationDate ? (
                    <span className="landing-expiry-date">
                      {Utils.formatExpirationDate(nofo.expirationDate)}
                    </span>
                  ) : (
                    <span className="landing-expiry-date landing-no-value">N/A</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      </TableScrollRegion>

      {/* Show More / Show Less for AI results */}
      {!awaitingAIResults && hasRankedResults && filteredNofos.length > AI_INITIAL_LIMIT && (
        <div className="landing-table-pagination">
          <button
            className="gw-btn gw-btn--primary landing-show-more-button"
            onClick={() => setShowAllAIResults((prev) => !prev)}
            aria-label={showAllAIResults
              ? `Show less — top ${AI_INITIAL_LIMIT} results only`
              : `Show more (${filteredNofos.length - AI_INITIAL_LIMIT} more) — all ${filteredNofos.length} results`}
          >
            {showAllAIResults
              ? "Show less"
              : `Show more (${filteredNofos.length - AI_INITIAL_LIMIT} more)`}
          </button>
        </div>
      )}

      {!awaitingAIResults && !hasRankedResults && filteredNofos.length > 0 && totalPages > 1 && (
        <PaginationControls
          currentPage={currentPage}
          totalPages={totalPages}
          totalItems={filteredNofos.length}
          itemsPerPage={itemsPerPage}
          itemLabel="grants"
          onPageChange={setCurrentPage}
        />
      )}
    </div>
  );
};
