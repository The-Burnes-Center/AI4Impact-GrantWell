import React from "react";
import type { IconType } from "react-icons";
import { LuCircleAlert, LuCircleCheck, LuTriangleAlert } from "react-icons/lu";
import type { ProcessingMetrics as MetricsType } from "../../../common/types/processing-review";
import { LiveStatus } from "../../../components/common/LiveStatus";

interface ProcessingMetricsProps {
  metrics: MetricsType | null;
  loading: boolean;
}

type ScoreRating = "high" | "medium" | "low";

const RATING_ICONS: Record<ScoreRating, IconType> = {
  high: LuCircleCheck,
  medium: LuTriangleAlert,
  low: LuCircleAlert,
};

const getScoreRating = (value: number, highThreshold: number, medThreshold: number): ScoreRating => {
  if (value >= highThreshold) return "high";
  if (value >= medThreshold) return "medium";
  return "low";
};

const ScoreFlag: React.FC<{ rating: ScoreRating; label: string }> = ({ rating, label }) => {
  const Icon = RATING_ICONS[rating];
  return (
    <div className={`metric-card__flag review-quality-score--${rating}`}>
      <Icon size={13} aria-hidden="true" />
      <span>{label}</span>
    </div>
  );
};

const RATING_LABELS: Record<ScoreRating, string> = {
  high: "High",
  medium: "Medium",
  low: "Low",
};

const ProcessingMetrics: React.FC<ProcessingMetricsProps> = ({
  metrics,
  loading,
}) => {
  if (loading || !metrics) {
    return (
      <>
        <LiveStatus className="visually-hidden">Loading processing metrics</LiveStatus>
        <div className="metrics-grid" aria-busy="true">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="metric-card metric-card--skeleton" />
          ))}
        </div>
      </>
    );
  }

  const successRating = getScoreRating(metrics.successRate, 80, 50);

  return (
    <div className="metrics-grid" role="region" aria-label="Processing pipeline metrics">
      <div className="metric-card">
        <div className="metric-card__value">{metrics.totalProcessed}</div>
        <div className="metric-card__label">Total processed</div>
      </div>
      <div className="metric-card">
        <div className={`metric-card__value review-quality-score--${successRating}`}>
          {metrics.successRate}%
        </div>
        <div className="metric-card__label">Success rate</div>
        <ScoreFlag rating={successRating} label={RATING_LABELS[successRating]} />
      </div>
      <div className="metric-card">
        <div className={`metric-card__value ${metrics.pendingCount > 0 ? "review-quality-score--medium" : ""}`}>
          {metrics.pendingCount}
        </div>
        <div className="metric-card__label">Pending review</div>
        {metrics.pendingCount > 0 && <ScoreFlag rating="medium" label="Needs review" />}
      </div>
      <div className="metric-card">
        <div className={`metric-card__value ${metrics.needsReuploadCount > 0 ? "review-quality-score--medium" : ""}`}>
          {metrics.needsReuploadCount}
        </div>
        <div className="metric-card__label">Needs re-upload</div>
        {metrics.needsReuploadCount > 0 && <ScoreFlag rating="medium" label="Needs action" />}
      </div>
      <div className="metric-card">
        <div className={`metric-card__value ${metrics.failedCount > 0 ? "review-quality-score--low" : ""}`}>
          {metrics.failedCount}
        </div>
        <div className="metric-card__label">Failed</div>
        {metrics.failedCount > 0 && <ScoreFlag rating="low" label="Failures" />}
      </div>
    </div>
  );
};

export default ProcessingMetrics;
