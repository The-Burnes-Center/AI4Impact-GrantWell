import React, { useState, useCallback, useEffect, useId, useRef } from "react";
import {
  LuPin, LuPinOff, LuFileX, LuUpload, LuInfo, LuFile, LuLoader, LuTriangleAlert, LuPlus, LuTrash,
} from "react-icons/lu";
import { ApiClient } from "../../../common/api-client/api-client";
import { Modal } from "../../../components/common/Modal";
import { DeleteConfirmationModal } from "../../../components/common/DeleteConfirmationModal";
import { ConfirmationModal } from "../../../components/common/ConfirmationModal";
import GrantActionsDropdown from "./GrantActionsDropdown";
import SummaryEditor from "./SummaryEditor";
import { PROCESSING_LABELS } from "./processing-stages";
import TableScrollRegion from "../../../components/ui/TableScrollRegion";
import { CardListItem } from "../../../components/ui/CardList";
import { CARD_LIST_QUERY, useMediaQuery } from "../../../hooks/use-media-query";
import { Utils } from "../../../common/utils";
import type { NOFO, GrantTypeId, CustomQuestion, ReviewFlag } from "../../../common/types/nofo";
import { GRANT_TYPES, grantTypeTint, GRANT_CATEGORIES } from "../../../common/types/nofo";
import { SINGLE_STATE, SUPPORTED_STATES } from "../../../common/states";
import { sectionLabel } from "./section-labels";

// A single-state deployment's state grants always belong to its state.
const DEFAULT_UPLOAD_STATE = SINGLE_STATE?.code ?? "";

function getErrorMessage(error: unknown, fallback: string) {
  return error instanceof Error && error.message ? error.message : fallback;
}

function reviewFlagTitle(flag: ReviewFlag) {
  const parts = [
    flag.missingCategories.length > 0 ? `Missing: ${flag.missingCategories.map(sectionLabel).join(", ")}` : "",
    flag.missingParts ?? "",
  ].filter(Boolean);
  return parts.length > 0 ? parts.join(". ") : undefined;
}

interface NOFOsTabProps {
  nofos: NOFO[];
  searchQuery: string;
  apiClient: ApiClient;
  updateNofos: (updater: (nofos: NOFO[]) => NOFO[]) => void;
  uploadNofoModalOpen: boolean;
  setUploadNofoModalOpen: React.Dispatch<React.SetStateAction<boolean>>;
  showGrantSuccessBanner?: (grantName: string) => void;
  addNotification: (type: string, message: string) => void;
  /** Open the review queue focused on a quarantined NOFO. */
  onOpenReview?: (nofoName: string) => void;
  /** True when the current admin is scoped to a single state (mirrors backend delete scope). */
  isStateAdmin?: boolean;
  /** The state-scoped admin's own state code, uppercased; empty otherwise. */
  userState?: string;
}

const NOFOsTab = React.memo(function NOFOsTab({
  nofos,
  searchQuery,
  apiClient,
  updateNofos,
  uploadNofoModalOpen,
  setUploadNofoModalOpen,
  showGrantSuccessBanner,
  addNotification,
  onOpenReview,
  isStateAdmin,
  userState,
}: NOFOsTabProps) {
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [selectedNofo, setSelectedNofo] = useState<NOFO | null>(null);
  const [editedNofoName, setEditedNofoName] = useState("");
  const [editedNofoStatus, setEditedNofoStatus] = useState<"active" | "archived">("active");
  const [editedNofoExpirationDate, setEditedNofoExpirationDate] = useState<string>("");
  const [editedNofoGrantType, setEditedNofoGrantType] = useState<GrantTypeId | "">("");
  const [editedNofoIsRolling, setEditedNofoIsRolling] = useState<boolean>(false);

  const [summaryModalOpen, setSummaryModalOpen] = useState(false);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [summarySaving, setSummarySaving] = useState(false);
  const [originalSummary, setOriginalSummary] = useState<Record<string, unknown> | null>(null);
  const [editedSummary, setEditedSummary] = useState<Record<string, unknown>>({});

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [customGrantName, setCustomGrantName] = useState("");
  const [uploadGrantType, setUploadGrantType] = useState<GrantTypeId | "">("");
  const [uploadState, setUploadState] = useState<string>(DEFAULT_UPLOAD_STATE);
  const [uploadCategory, setUploadCategory] = useState<string>("");
  const [uploadAgency, setUploadAgency] = useState<string>("");

  const [overlayModalOpen, setOverlayModalOpen] = useState(false);
  const [overlayLoading, setOverlayLoading] = useState(false);
  const [overlaySaving, setOverlaySaving] = useState(false);
  const [overlayNote, setOverlayNote] = useState("");

  const [customQuestionsModalOpen, setCustomQuestionsModalOpen] = useState(false);
  const [customQuestionsLoading, setCustomQuestionsLoading] = useState(false);
  const [customQuestionsSaving, setCustomQuestionsSaving] = useState(false);
  const [customQuestions, setCustomQuestions] = useState<CustomQuestion[]>([]);

  const [promoteModalOpen, setPromoteModalOpen] = useState(false);
  const [promoting, setPromoting] = useState(false);
  const reviewFlagIdPrefix = useId();

  const tableRef = useRef<HTMLTableElement>(null);
  // Pin re-sorts, archive/delete remove the row: keep focus on the control or fall back to the table.
  const focusBeforeUpdate = useRef<Element | null>(null);
  const updateNofosKeepingFocus = useCallback((updater: (nofos: NOFO[]) => NOFO[]) => {
    focusBeforeUpdate.current = document.activeElement;
    updateNofos(updater);
  }, [updateNofos]);

  useEffect(() => {
    const previous = focusBeforeUpdate.current;
    if (!previous) return;
    focusBeforeUpdate.current = null;
    if (document.activeElement && document.activeElement !== document.body) return;
    (previous instanceof HTMLElement && previous.isConnected ? previous : tableRef.current)?.focus();
  }, [nofos]);

  const handleEditSummary = useCallback(async (nofo: NOFO) => {
    setSelectedNofo(nofo);
    setSummaryModalOpen(true);
    setSummaryLoading(true);
    try {
      const result = await apiClient.landingPage.getNOFOSummary(nofo.name);
      const data = result.data || {};
      setOriginalSummary(JSON.parse(JSON.stringify(data)));
      setEditedSummary(data);
    } catch {
      addNotification("error", "Failed to load grant requirements. Please try again.");
      setSummaryModalOpen(false);
    } finally {
      setSummaryLoading(false);
    }
  }, [apiClient, addNotification]);

  const handleSummaryChange = useCallback((updated: Record<string, unknown>) => {
    setEditedSummary(updated);
  }, []);

  const isSummaryChanged = useCallback(() => {
    if (!originalSummary) return false;
    return JSON.stringify(editedSummary) !== JSON.stringify(originalSummary);
  }, [editedSummary, originalSummary]);

  const confirmSaveSummary = useCallback(async () => {
    if (!selectedNofo || !isSummaryChanged()) return;
    setSummarySaving(true);
    try {
      await apiClient.landingPage.updateNOFOSummary(selectedNofo.name, editedSummary);
      addNotification("success", `Requirements for "${selectedNofo.name}" updated successfully`);
      setSummaryModalOpen(false);
      setSelectedNofo(null);
      setOriginalSummary(null);
      setEditedSummary({});
    } catch {
      addNotification("error", "Failed to save requirements changes. Please try again.");
    } finally {
      setSummarySaving(false);
    }
  }, [selectedNofo, editedSummary, isSummaryChanged, apiClient, addNotification]);

  const closeSummaryModal = useCallback(() => {
    setSummaryModalOpen(false);
    setSelectedNofo(null);
    setOriginalSummary(null);
    setEditedSummary({});
  }, []);

  // State admins can't edit a federal NOFO, but they can attach guidance for their own state.
  const handleEditOverlay = useCallback(async (nofo: NOFO) => {
    setSelectedNofo(nofo);
    setOverlayModalOpen(true);
    setOverlayLoading(true);
    try {
      const result = await apiClient.landingPage.getStateOverlay(nofo.name);
      setOverlayNote(result.note || "");
    } catch {
      addNotification("error", "Failed to load state guidance. Please try again.");
      setOverlayModalOpen(false);
    } finally {
      setOverlayLoading(false);
    }
  }, [apiClient, addNotification]);

  const confirmSaveOverlay = useCallback(async () => {
    if (!selectedNofo) return;
    setOverlaySaving(true);
    try {
      await apiClient.landingPage.putStateOverlay(selectedNofo.name, overlayNote);
      addNotification("success", `State guidance for "${selectedNofo.name}" saved`);
      setOverlayModalOpen(false);
      setSelectedNofo(null);
      setOverlayNote("");
    } catch (error) {
      addNotification("error", getErrorMessage(error, "Failed to save state guidance."));
    } finally {
      setOverlaySaving(false);
    }
  }, [selectedNofo, overlayNote, apiClient, addNotification]);

  // Custom questions layer onto a state NOFO's application-writer questionnaire. Loaded from and
  // saved to the same overlay row as state guidance, but the backend writes only this field.
  const handleEditCustomQuestions = useCallback(async (nofo: NOFO) => {
    setSelectedNofo(nofo);
    setCustomQuestionsModalOpen(true);
    setCustomQuestionsLoading(true);
    try {
      const result = await apiClient.landingPage.getStateOverlay(nofo.name);
      setCustomQuestions(result.customQuestions || []);
    } catch {
      addNotification("error", "Failed to load custom questions. Please try again.");
      setCustomQuestionsModalOpen(false);
    } finally {
      setCustomQuestionsLoading(false);
    }
  }, [apiClient, addNotification]);

  const confirmSaveCustomQuestions = useCallback(async () => {
    if (!selectedNofo) return;
    // Drop blank rows; the backend re-validates and assigns ids.
    const cleaned = customQuestions
      .map((q) => ({ ...q, question: q.question.trim(), helpText: q.helpText?.trim() || undefined }))
      .filter((q) => q.question.length > 0);
    setCustomQuestionsSaving(true);
    try {
      await apiClient.landingPage.putCustomQuestions(selectedNofo.name, cleaned);
      addNotification("success", `Custom questions for "${selectedNofo.name}" saved`);
      setCustomQuestionsModalOpen(false);
      setSelectedNofo(null);
      setCustomQuestions([]);
    } catch (error) {
      addNotification("error", getErrorMessage(error, "Failed to save custom questions."));
    } finally {
      setCustomQuestionsSaving(false);
    }
  }, [selectedNofo, customQuestions, apiClient, addNotification]);

  // Fork a federal NOFO into a fully-owned state copy.
  const handlePromoteToCopy = useCallback((nofo: NOFO) => {
    setSelectedNofo(nofo);
    setPromoteModalOpen(true);
  }, []);

  const confirmPromoteToCopy = useCallback(async () => {
    if (!selectedNofo) return;
    setPromoting(true);
    try {
      const result = await apiClient.landingPage.promoteToCopy(selectedNofo.name);
      setPromoteModalOpen(false);
      setSelectedNofo(null);
      if (showGrantSuccessBanner) {
        showGrantSuccessBanner(result.newName);
      } else {
        addNotification("success", `Created state copy "${result.newName}". Refresh to see it.`);
      }
    } catch (error) {
      addNotification("error", getErrorMessage(error, "Failed to create state copy."));
    } finally {
      setPromoting(false);
    }
  }, [selectedNofo, apiClient, addNotification, showGrantSuccessBanner]);

  const handlePinGrant = async (nofo: NOFO, event?: React.MouseEvent) => {
    event?.stopPropagation();
    try {
      await apiClient.landingPage.updateNOFOStatus(nofo.name, undefined, true);
      updateNofosKeepingFocus((allNofos) =>
        allNofos.map((item) => item.id === nofo.id ? { ...item, isPinned: true } : item)
      );
      addNotification("success", `Grant "${nofo.name}" pinned successfully`);
    } catch {
      addNotification("error", "Failed to pin grant. Please try again.");
    }
  };

  const handleUnpinGrant = async (nofo: NOFO, event?: React.MouseEvent) => {
    event?.stopPropagation();
    try {
      await apiClient.landingPage.updateNOFOStatus(nofo.name, undefined, false);
      updateNofosKeepingFocus((allNofos) =>
        allNofos.map((item) => item.id === nofo.id ? { ...item, isPinned: false } : item)
      );
      addNotification("info", `Grant "${nofo.name}" unpinned`);
    } catch {
      addNotification("error", "Failed to unpin grant. Please try again.");
    }
  };

  const handleEditNofo = (nofo: NOFO) => {
    setSelectedNofo(nofo);
    setEditedNofoName(nofo.name);
    setEditedNofoStatus(nofo.status || "active");
    setEditedNofoGrantType(nofo.grantType || "");
    setEditedNofoIsRolling(nofo.isRolling || false);
    if (nofo.expirationDate) {
      if (/^\d{4}-\d{2}-\d{2}$/.test(nofo.expirationDate)) {
        setEditedNofoExpirationDate(nofo.expirationDate);
      } else {
        setEditedNofoExpirationDate(new Date(nofo.expirationDate).toISOString().split("T")[0]);
      }
    } else {
      setEditedNofoExpirationDate("");
    }
    setEditModalOpen(true);
  };

  const handleDeleteNofo = (nofo: NOFO) => {
    setSelectedNofo(nofo);
    setDeleteModalOpen(true);
  };

  const confirmEditNofo = async () => {
    if (!selectedNofo || !editedNofoName.trim()) return;
    try {
      if (selectedNofo.name !== editedNofoName.trim()) {
        await apiClient.landingPage.renameNOFO(selectedNofo.name, editedNofoName.trim());
      }
      if (selectedNofo.status !== editedNofoStatus) {
        await apiClient.landingPage.updateNOFOStatus(editedNofoName.trim(), editedNofoStatus);
      }
      const newExpirationDate = editedNofoExpirationDate || null;
      let normalizedOld = selectedNofo.expirationDate || null;
      if (normalizedOld && !/^\d{4}-\d{2}-\d{2}$/.test(normalizedOld)) {
        normalizedOld = new Date(normalizedOld).toISOString().split("T")[0];
      }
      if (newExpirationDate !== normalizedOld) {
        await apiClient.landingPage.updateNOFOStatus(editedNofoName.trim(), undefined, undefined, newExpirationDate);
      }
      const newGrantType = editedNofoGrantType || null;
      if (newGrantType !== (selectedNofo.grantType || null)) {
        await apiClient.landingPage.updateNOFOStatus(editedNofoName.trim(), undefined, undefined, undefined, newGrantType as GrantTypeId);
      }
      if (editedNofoIsRolling !== (selectedNofo.isRolling || false)) {
        await apiClient.landingPage.updateNOFOStatus(editedNofoName.trim(), undefined, undefined, undefined, undefined, undefined, undefined, editedNofoIsRolling);
      }
      updateNofos((allNofos) =>
        allNofos.map((nofo) =>
          nofo.id === selectedNofo.id
            ? { ...nofo, name: editedNofoName.trim(), status: editedNofoStatus, expirationDate: newExpirationDate, grantType: newGrantType as GrantTypeId | null, isRolling: editedNofoIsRolling }
            : nofo
        )
      );
      addNotification("success", "Grant updated successfully");
      setEditModalOpen(false);
      setSelectedNofo(null);
      setEditedNofoName("");
      setEditedNofoExpirationDate("");
      setEditedNofoGrantType("");
      setEditedNofoIsRolling(false);
    } catch (error) {
      addNotification("error", getErrorMessage(error, "Failed to update grant. Please try again."));
    }
  };

  const toggleNofoStatus = async (nofo: NOFO) => {
    const newStatus = nofo.status === "active" ? "archived" : "active";
    try {
      await apiClient.landingPage.updateNOFOStatus(nofo.name, newStatus);
      updateNofosKeepingFocus((allNofos) =>
        allNofos.map((item) => item.id === nofo.id ? { ...item, status: newStatus } : item)
      );
      addNotification("success", `Grant status changed to ${newStatus}`);
    } catch (error) {
      addNotification("error", getErrorMessage(error, "Failed to update grant status. Please try again."));
    }
  };

  const confirmDeleteNofo = async () => {
    if (!selectedNofo) return;
    try {
      await apiClient.landingPage.deleteNOFO(selectedNofo.name);
      updateNofosKeepingFocus((allNofos) => allNofos.filter((nofo) => nofo.id !== selectedNofo.id));
      addNotification("success", `Grant "${selectedNofo.name}" deleted successfully`);
      setDeleteModalOpen(false);
      setSelectedNofo(null);
    } catch {
      addNotification("error", "Failed to delete grant. Please try again.");
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      setSelectedFile(file);
      setCustomGrantName(file.name.split(".").slice(0, -1).join(""));
    }
  };

  const uploadNOFO = async () => {
    if (!selectedFile) { addNotification("error", "Please select a file first"); return; }
    if (!customGrantName.trim()) { addNotification("error", "Grant name cannot be empty"); return; }
    if (!uploadGrantType) { addNotification("error", "Grant type is required"); return; }
    if (uploadGrantType === "state" && !uploadState) {
      addNotification("error", "State is required for state grants");
      return;
    }
    if (!uploadCategory) { addNotification("error", "Category is required"); return; }

    try {
      const folderName = customGrantName.trim();
      let newFilePath: string;
      if (selectedFile.type === "text/plain") newFilePath = `${folderName}/NOFO-File-TXT`;
      else if (selectedFile.type === "application/pdf") newFilePath = `${folderName}/NOFO-File-PDF`;
      else if (selectedFile.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") newFilePath = `${folderName}/NOFO-File-DOCX`;
      else newFilePath = `${folderName}/NOFO-File`;

      const scope: "federal" | "state" = uploadGrantType === "state" ? "state" : "federal";
      const signedUrl = await apiClient.landingPage.getUploadURL(
        newFilePath,
        selectedFile.type,
        scope,
        scope === "state" ? uploadState : undefined
      );
      await apiClient.landingPage.uploadFileToS3(signedUrl, selectedFile);
      await apiClient.landingPage.updateNOFOStatus(
        folderName, "active", undefined, undefined,
        uploadGrantType as GrantTypeId,
        uploadCategory,
        uploadAgency || undefined
      );

      if (showGrantSuccessBanner) {
        showGrantSuccessBanner(folderName);
      } else {
        addNotification("success", `Grant "${folderName}" added successfully!`);
      }

      setSelectedFile(null);
      setCustomGrantName("");
      setUploadGrantType("");
      setUploadState(DEFAULT_UPLOAD_STATE);
      setUploadCategory("");
      setUploadAgency("");
      setUploadNofoModalOpen(false);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to upload the grant file.";
      addNotification("error", message);
    }
  };

  const isChanged = () => {
    if (!selectedNofo) return false;
    if (!editedNofoName.trim()) return false;
    let normalizedOldExp = selectedNofo.expirationDate || "";
    if (normalizedOldExp && !/^\d{4}-\d{2}-\d{2}$/.test(normalizedOldExp)) {
      normalizedOldExp = new Date(normalizedOldExp).toISOString().split("T")[0];
    }
    return (
      editedNofoName !== selectedNofo.name ||
      editedNofoStatus !== selectedNofo.status ||
      editedNofoExpirationDate !== normalizedOldExp ||
      editedNofoGrantType !== (selectedNofo.grantType || "") ||
      editedNofoIsRolling !== (selectedNofo.isRolling || false)
    );
  };


  const asCards = useMediaQuery(CARD_LIST_QUERY);

  const nameMarkers = (nofo: NOFO) => (
    <>
      {nofo.isPinned && (
        <span className="gw-tag gw-tag--info pinned-badge"><LuPin size={14} aria-hidden="true" /><span>Pinned</span></span>
      )}
      {nofo.processingStatus === "quarantined" ? (
        <button
          type="button"
          className="grant-review-link grant-review-link--needs-review"
          onClick={() => onOpenReview?.(nofo.name)}
        >
          <LuTriangleAlert size={12} aria-hidden="true" />
          Needs review
        </button>
      ) : nofo.processingStatus ? (
        <span className="grant-processing-marker">
          <span className="grant-processing-marker__dot" aria-hidden="true" />
          {PROCESSING_LABELS[nofo.processingStatus] || "Processing"}
        </span>
      ) : nofo.reviewFlag ? (
        <>
          <button
            type="button"
            className="grant-review-link grant-review-link--suggested"
            onClick={() => handleEditSummary(nofo)}
            aria-describedby={reviewFlagTitle(nofo.reviewFlag) ? `${reviewFlagIdPrefix}-${nofo.id}` : undefined}
          >
            <LuInfo size={12} aria-hidden="true" />
            Review suggested
          </button>
          {/* Shown, not a hover tooltip, so keyboard and touch users see why too. */}
          {reviewFlagTitle(nofo.reviewFlag) && (
            <span id={`${reviewFlagIdPrefix}-${nofo.id}`} className="grant-review-reason">
              {reviewFlagTitle(nofo.reviewFlag)}
            </span>
          )}
        </>
      ) : null}
    </>
  );

  const typeBadge = (nofo: NOFO) =>
    nofo.grantType && GRANT_TYPES[nofo.grantType] ? (
      <span
        className="gw-tag grant-type-badge"
        style={{
          backgroundColor: grantTypeTint(GRANT_TYPES[nofo.grantType].color, 8),
          color: GRANT_TYPES[nofo.grantType].color,
          borderColor: grantTypeTint(GRANT_TYPES[nofo.grantType].color, 60),
        }}
      >
        {GRANT_TYPES[nofo.grantType].label}
      </span>
    ) : (
      <span className="gw-tag grant-type-badge unset">Unset</span>
    );

  const deadlineText = (nofo: NOFO) =>
    nofo.isRolling ? (
      <span className="expiry-date rolling">Rolling</span>
    ) : nofo.expirationDate ? (
      <span className="expiry-date">{Utils.formatExpirationDate(nofo.expirationDate!)}</span>
    ) : (
      <span className="expiry-date no-date">N/A</span>
    );

  const rowActions = (nofo: NOFO) => {
    // Mirror the backend scope check: a state admin may only modify
    // NOFOs owned by their own state. Unknown scope fails closed, so
    // every mutating action (pin/delete/archive/edit) is gated together.
    // A single-state deployment's admins may edit every grant (canEditAnyNofo).
    const editDisabled = Boolean(
      isStateAdmin &&
        !(SINGLE_STATE && userState === SINGLE_STATE.code) &&
        !(nofo.scope === "state" && nofo.state === userState)
    );
    // On a federal grant, a state admin instead gets state-scoped actions:
    // attach guidance for their state, or fork it into their own copy.
    const showStateActions = Boolean(isStateAdmin && nofo.scope === "federal");
    // Custom questions apply to state grants; offer them to any admin allowed to edit
    // this grant (dev/regular admins, or the owning state's admin).
    const showCustomQuestions = Boolean(!editDisabled && nofo.scope === "state");
    return (
      <>
        {!editDisabled && (nofo.isPinned ? (
          <button className="gw-btn gw-btn--icon action-button unpin" onClick={(e) => handleUnpinGrant(nofo, e)} aria-label={`Unpin grant ${nofo.name}`} title="Unpin grant">
            <LuPinOff size={18} aria-hidden="true" />
          </button>
        ) : (
          <button className="gw-btn gw-btn--icon action-button pin" onClick={(e) => handlePinGrant(nofo, e)} aria-label={`Pin grant ${nofo.name}`} title="Pin grant">
            <LuPin size={18} aria-hidden="true" />
          </button>
        ))}
        <GrantActionsDropdown
          nofo={nofo}
          onToggleStatus={() => toggleNofoStatus(nofo)}
          onEdit={() => handleEditNofo(nofo)}
          onEditSummary={() => handleEditSummary(nofo)}
          onDelete={() => handleDeleteNofo(nofo)}
          editDisabled={editDisabled}
          showStateActions={showStateActions}
          onEditOverlay={() => handleEditOverlay(nofo)}
          onPromoteToCopy={() => handlePromoteToCopy(nofo)}
          showCustomQuestions={showCustomQuestions}
          onEditCustomQuestions={() => handleEditCustomQuestions(nofo)}
        />
      </>
    );
  };

  return (
    <div className="tab-content">
      {asCards ? (
        nofos.length === 0 ? (
          <div className="no-data">
            <LuFileX size={24} className="no-data-icon" aria-hidden="true" />
            <p>No grants found</p>
          </div>
        ) : (
          <ul className="gw-card-list" aria-label="Grants">
            {nofos.map((nofo) => (
              <CardListItem
                key={nofo.id}
                headingLevel={4}
                title={nofo.name}
                facts={[
                  { label: "Type", value: typeBadge(nofo) },
                  { label: "Deadline", value: deadlineText(nofo) },
                ]}
                badges={nameMarkers(nofo)}
                actions={rowActions(nofo)}
              />
            ))}
          </ul>
        )
      ) : (
      <TableScrollRegion label="Grants table" minWidth={640}>
      <div className="table-container">
      <table className="gw-table" aria-label="Grants" ref={tableRef} tabIndex={-1}>
        <colgroup>
          <col style={{ width: "57%" }} />
          <col style={{ width: "14%" }} />
          <col style={{ width: "14%" }} />
          <col />
        </colgroup>
        <thead>
          <tr>
            <th scope="col" className="header-cell">Name</th>
            <th scope="col" className="header-cell">Type</th>
            <th scope="col" className="header-cell">Deadline</th>
            <th scope="col" className="header-cell header-cell--end">Actions</th>
          </tr>
        </thead>
        <tbody>
          {nofos.length === 0 && (
            <tr>
              <td className="row-cell row-cell--empty" colSpan={4}>
                <div className="no-data">
                  <LuFileX size={24} className="no-data-icon" aria-hidden="true" />
                  <p>No grants found</p>
                </div>
              </td>
            </tr>
          )}
          {nofos.map((nofo) => (
            <tr key={nofo.id} className="table-row">
              <th scope="row" className="row-cell">
                <span className="nofo-name">{nofo.name}</span>
                {nameMarkers(nofo)}
              </th>
              <td className="row-cell">
                {typeBadge(nofo)}
              </td>
              <td className="row-cell">
                {deadlineText(nofo)}
              </td>
              <td className="row-cell actions">
                <div className="row-cell__flex row-cell__flex--end">
                {rowActions(nofo)}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
      </TableScrollRegion>
      )}

      {/* Edit NOFO Modal */}
      <Modal isOpen={editModalOpen} onClose={() => setEditModalOpen(false)} title="Edit grant">
        <div className="modal-form">
          <div className="form-group">
            <label htmlFor="nofo-name">Grant name</label>
            <input type="text" id="nofo-name" value={editedNofoName} onChange={(e) => setEditedNofoName(e.target.value)} className="gw-input form-input" placeholder="Enter grant name" />
          </div>
          <div className="form-group">
            <label htmlFor="nofo-status">Status</label>
            <div className="select-wrapper">
              <select id="nofo-status" aria-describedby="nofo-status-help" value={editedNofoStatus} onChange={(e) => setEditedNofoStatus(e.target.value as "active" | "archived")} className="gw-input form-input">
                <option value="active">Active</option>
                <option value="archived">Archived</option>
              </select>
            </div>
            <div id="nofo-status-help" className="gw-field__help field-note">Active grants are visible to users. Archived grants are hidden.</div>
          </div>
          <div className="form-group">
            <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
              <input
                type="checkbox"
                checked={editedNofoIsRolling}
                onChange={(e) => setEditedNofoIsRolling(e.target.checked)}
              />
              Rolling grant (no fixed deadline)
            </label>
            <div className="field-note">Rolling grants show "Rolling" instead of a deadline date.</div>
          </div>
          <div className="form-group">
            <label htmlFor="nofo-expiration-date">Deadline</label>
            <input type="date" id="nofo-expiration-date" aria-describedby="nofo-expiration-date-help" value={editedNofoExpirationDate} onChange={(e) => setEditedNofoExpirationDate(e.target.value)} className="gw-input form-input" disabled={editedNofoIsRolling} />
            <div id="nofo-expiration-date-help" className="gw-field__help field-note">Leave empty if no expiration date. Grants will be auto-archived after this date.</div>
          </div>
          <div className="form-group">
            <label htmlFor="nofo-grant-type">Grant type</label>
            <div className="select-wrapper">
              <select id="nofo-grant-type" aria-describedby="nofo-grant-type-help" value={editedNofoGrantType} onChange={(e) => setEditedNofoGrantType(e.target.value as GrantTypeId | "")} className="gw-input form-input">
                <option value="">Select type...</option>
                <option value="federal">Federal</option>
                <option value="state">State</option>
                <option value="quasi">Quasi</option>
                <option value="philanthropic">Philanthropic</option>
              </select>
            </div>
            <div id="nofo-grant-type-help" className="gw-field__help field-note">Federal, State, Quasi-governmental, or Philanthropic.</div>
          </div>
          <div className="modal-actions">
            <button className="gw-btn gw-btn--secondary modal-button secondary" onClick={() => setEditModalOpen(false)}>Cancel</button>
            <button className="gw-btn gw-btn--primary modal-button primary" onClick={confirmEditNofo} disabled={!isChanged()}>Save changes</button>
          </div>
        </div>
      </Modal>

      <DeleteConfirmationModal isOpen={deleteModalOpen} onClose={() => setDeleteModalOpen(false)} onConfirm={confirmDeleteNofo} title="Delete grant" itemName={selectedNofo?.name} itemLabel="grant" />

      <ConfirmationModal
        isOpen={promoteModalOpen}
        onClose={() => { setPromoteModalOpen(false); setSelectedNofo(null); }}
        onConfirm={confirmPromoteToCopy}
        title="Create state copy"
        message={<>Create your state&apos;s own editable copy of <strong>{selectedNofo?.name}</strong>?</>}
        warning="The federal grant stays unchanged, and the copy won't track later federal updates."
        confirmLabel="Create copy"
        confirming={promoting}
      />

      {/* Edit Summary Modal */}
      <Modal
        isOpen={summaryModalOpen}
        onClose={closeSummaryModal}
        title={`Edit requirements — ${selectedNofo?.name || ""}`}
        maxWidth="800px"
      >
        <div className="modal-form">
          <div role="status" aria-live="polite" className="visually-hidden">
            {summaryLoading ? "Loading grant requirements" : ""}
          </div>
          {summaryLoading ? (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 0", gap: "12px", color: "var(--gw-color-text-secondary)" }}>
              <LuLoader size={20} className="spin-animation" aria-hidden="true" />
              <span>Loading requirements...</span>
            </div>
          ) : (
            <>
              <p className="modal-description" style={{ marginBottom: "16px" }}>
                Review and correct the extracted grant requirements below. Changes will take effect immediately for all users.
              </p>
              <SummaryEditor
                editedSummary={editedSummary}
                onSummaryChange={handleSummaryChange}
              />
              <div className="modal-actions" style={{ marginTop: "16px" }}>
                <button className="gw-btn gw-btn--secondary modal-button secondary" onClick={closeSummaryModal}>
                  Cancel
                </button>
                <button
                  className="gw-btn gw-btn--primary modal-button primary"
                  onClick={() => isSummaryChanged() && !summarySaving && confirmSaveSummary()}
                  aria-disabled={!isSummaryChanged() || summarySaving || undefined}
                >
                  {summarySaving ? "Saving..." : "Save changes"}
                </button>
              </div>
            </>
          )}
        </div>
      </Modal>

      {/* State Guidance Overlay Modal */}
      <Modal
        isOpen={overlayModalOpen}
        onClose={() => { setOverlayModalOpen(false); setSelectedNofo(null); setOverlayNote(""); }}
        title={`State guidance — ${selectedNofo?.name || ""}`}
        maxWidth="720px"
      >
        <div className="modal-form">
          <div role="status" aria-live="polite" className="visually-hidden">
            {overlayLoading ? "Loading state guidance" : ""}
          </div>
          {overlayLoading ? (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 0", gap: "12px", color: "var(--gw-color-text-secondary)" }}>
              <LuLoader size={20} className="spin-animation" aria-hidden="true" />
              <span>Loading state guidance...</span>
            </div>
          ) : (
            <>
              <p className="modal-description" style={{ marginBottom: "16px" }}>
                Add guidance for this federal grant shown only to your state's users. The federal grant itself is unchanged. Leave empty to remove.
              </p>
              <label htmlFor="state-guidance-note" className="gw-field__label">State guidance note</label>
              <textarea className="gw-input"
                id="state-guidance-note"
                value={overlayNote}
                onChange={(e) => setOverlayNote(e.target.value)}
                rows={8}
                style={{ width: "100%" }}
                placeholder="e.g. Applicants from our state should also submit Form X and contact our office before applying."
              />
              <div className="modal-actions" style={{ marginTop: "16px" }}>
                <button className="gw-btn gw-btn--secondary modal-button secondary" onClick={() => { setOverlayModalOpen(false); setSelectedNofo(null); setOverlayNote(""); }}>
                  Cancel
                </button>
                <button className="gw-btn gw-btn--primary modal-button primary" onClick={() => !overlaySaving && confirmSaveOverlay()} aria-disabled={overlaySaving || undefined}>
                  {overlaySaving ? "Saving..." : "Save guidance"}
                </button>
              </div>
            </>
          )}
        </div>
      </Modal>

      {/* Custom Questions Modal */}
      <Modal
        isOpen={customQuestionsModalOpen}
        onClose={() => { setCustomQuestionsModalOpen(false); setSelectedNofo(null); setCustomQuestions([]); }}
        title={`Custom questions — ${selectedNofo?.name || ""}`}
        maxWidth="720px"
      >
        <div className="modal-form">
          <div role="status" aria-live="polite" className="visually-hidden">
            {customQuestionsLoading ? "Loading custom questions" : ""}
          </div>
          {customQuestionsLoading ? (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 0", gap: "12px", color: "var(--gw-color-text-secondary)" }}>
              <LuLoader size={20} className="spin-animation" aria-hidden="true" />
              <span>Loading custom questions...</span>
            </div>
          ) : (
            <>
              <p className="modal-description" style={{ marginBottom: "16px" }}>
                Add questions applicants answer in Write application, alongside any questions from the grant document. Useful when the grant doesn&apos;t spell out what your state wants to ask.
              </p>
              {customQuestions.length === 0 ? (
                <p style={{ color: "var(--gw-color-text-secondary)", marginBottom: "16px" }}>
                  No custom questions yet.
                </p>
              ) : (
                customQuestions.map((q, index) => (
                  <div key={q.id ?? index} style={{ marginBottom: "16px", padding: "12px", border: "1px solid var(--gw-color-border)", borderRadius: "var(--gw-radius-container)" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                      <span style={{ fontWeight: 500 }}>Question {index + 1}</span>
                      <button
                        type="button"
                        className="action-button"
                        aria-label={`Remove question ${index + 1}`}
                        onClick={() => setCustomQuestions((prev) => prev.filter((_, i) => i !== index))}
                      >
                        <LuTrash size={16} aria-hidden="true" />
                      </button>
                    </div>
                    <textarea className="gw-input"
                      value={q.question}
                      onChange={(e) => setCustomQuestions((prev) => prev.map((item, i) => i === index ? { ...item, question: e.target.value } : item))}
                      rows={2}
                      maxLength={500}
                      style={{ width: "100%", marginBottom: "8px" }}
                      placeholder="e.g. Describe how this project serves residents in our state."
                      aria-label={`Question ${index + 1} text`}
                    />
                    <input className="gw-input"
                      type="text"
                      value={q.helpText ?? ""}
                      onChange={(e) => setCustomQuestions((prev) => prev.map((item, i) => i === index ? { ...item, helpText: e.target.value } : item))}
                      maxLength={300}
                      style={{ width: "100%" }}
                      placeholder="Optional help text shown under the question"
                      aria-label={`Question ${index + 1} help text`}
                    />
                  </div>
                ))
              )}
              <button
                type="button"
                className="gw-btn gw-btn--secondary modal-button secondary"
                onClick={() => customQuestions.length < 25 && setCustomQuestions((prev) => [...prev, { question: "" }])}
                aria-disabled={customQuestions.length >= 25 || undefined}
                style={{ display: "inline-flex", alignItems: "center", gap: "6px" }}
              >
                <LuPlus size={16} aria-hidden="true" /> Add question
              </button>
              <div className="modal-actions" style={{ marginTop: "16px" }}>
                <button className="gw-btn gw-btn--secondary modal-button secondary" onClick={() => { setCustomQuestionsModalOpen(false); setSelectedNofo(null); setCustomQuestions([]); }}>
                  Cancel
                </button>
                <button className="gw-btn gw-btn--primary modal-button primary" onClick={() => !customQuestionsSaving && confirmSaveCustomQuestions()} aria-disabled={customQuestionsSaving || undefined}>
                  {customQuestionsSaving ? "Saving..." : "Save questions"}
                </button>
              </div>
            </>
          )}
        </div>
      </Modal>

      {/* Upload NOFO Modal */}
      <Modal
        isOpen={uploadNofoModalOpen}
        onClose={() => { setUploadNofoModalOpen(false); setSelectedFile(null); setCustomGrantName(""); setUploadGrantType(""); setUploadState(DEFAULT_UPLOAD_STATE); setUploadCategory(""); setUploadAgency(""); }}
        title="Add grant"
      >
        <div className="modal-form">
          <p className="modal-description">Upload a grant document in PDF, TXT, or DOCX format.</p>
          <div className="info-box">
            <LuInfo size={18} className="info-icon" aria-hidden="true" />
            <span>After you upload, the grant appears in the list above and processes automatically (about 5&ndash;7 minutes). You can watch each stage on its row &mdash; most grants publish on their own, and only ones that need a closer look are flagged for review.</span>
          </div>
          <div className="form-group">
            <label htmlFor="file-upload">Select file</label>
            <div className="file-upload-container">
              <input id="file-upload" type="file" accept=".pdf,.txt,.docx" onChange={handleFileSelect} className="file-input" />
              <div className="gw-btn gw-btn--secondary file-upload-button"><LuUpload size={16} className="button-icon" aria-hidden="true" /><span>Select file</span></div>
            </div>
            {selectedFile && (
              <div className="selected-file"><LuFile size={16} className="file-icon" aria-hidden="true" /><span>{selectedFile.name}</span></div>
            )}
          </div>
          {selectedFile && (
            <>
              <div className="form-group">
                <label htmlFor="custom-grant-name">Grant name</label>
                <input type="text" id="custom-grant-name" aria-describedby="custom-grant-name-help" value={customGrantName} onChange={(e) => setCustomGrantName(e.target.value)} className="gw-input form-input" placeholder="Enter grant name" />
                <div id="custom-grant-name-help" className="gw-field__help field-note">This name will be used to identify the grant in the system.</div>
              </div>
              <div className="form-group">
                <label htmlFor="upload-grant-type">Grant type<span className="gw-field__required" aria-hidden="true">*</span></label>
                <div className="select-wrapper">
                  <select
                    id="upload-grant-type" aria-describedby="upload-grant-type-help"
                    value={uploadGrantType}
                    onChange={(e) => {
                      const next = e.target.value as GrantTypeId | "";
                      setUploadGrantType(next);
                      if (next !== "state") setUploadState(DEFAULT_UPLOAD_STATE);
                    }}
                    className="gw-input form-input"
                    required
                  >
                    <option value="">Select type...</option>
                    <option value="federal">Federal</option>
                    <option value="state">State</option>
                    <option value="quasi">Quasi</option>
                    <option value="philanthropic">Philanthropic</option>
                  </select>
                </div>
                <div id="upload-grant-type-help" className="gw-field__help field-note">Required. Determines who this grant is visible to.</div>
              </div>
              {uploadGrantType === "state" && !SINGLE_STATE && (
                <div className="form-group">
                  <label htmlFor="upload-state">State<span className="gw-field__required" aria-hidden="true">*</span></label>
                  <div className="select-wrapper">
                    <select
                      id="upload-state" aria-describedby="upload-state-help"
                      value={uploadState}
                      onChange={(e) => setUploadState(e.target.value)}
                      className="gw-input form-input"
                      required
                    >
                      <option value="">Select state...</option>
                      {SUPPORTED_STATES.map((s) => (
                        <option key={s.code} value={s.code}>{s.name}</option>
                      ))}
                    </select>
                  </div>
                  <div id="upload-state-help" className="gw-field__help field-note">Required for state grants. Users from this state will see it in Chat with AI and Write application.</div>
                </div>
              )}
              <div className="form-group">
                <label htmlFor="upload-category">Category<span className="gw-field__required" aria-hidden="true">*</span></label>
                <div className="select-wrapper">
                  <select id="upload-category" aria-describedby="upload-category-help" value={uploadCategory} onChange={(e) => setUploadCategory(e.target.value)} className="gw-input form-input" required>
                    <option value="">Select category...</option>
                    {GRANT_CATEGORIES.map((category) => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
                <div id="upload-category-help" className="gw-field__help field-note">Required. Select the funding category for this grant.</div>
              </div>
              <div className="form-group">
                <label htmlFor="upload-agency">Agency</label>
                <input type="text" id="upload-agency" aria-describedby="upload-agency-help" value={uploadAgency} onChange={(e) => setUploadAgency(e.target.value)} className="gw-input form-input" placeholder="e.g. Department of Health and Human Services" />
                <div id="upload-agency-help" className="gw-field__help field-note">Optional. The government agency issuing this grant.</div>
              </div>
            </>
          )}
          <div className="modal-actions">
            <button className="gw-btn gw-btn--secondary modal-button secondary" onClick={() => { setUploadNofoModalOpen(false); setSelectedFile(null); setCustomGrantName(""); setUploadGrantType(""); setUploadState(DEFAULT_UPLOAD_STATE); setUploadCategory(""); setUploadAgency(""); }}>Cancel</button>
            <button
              className="gw-btn gw-btn--primary modal-button primary"
              onClick={uploadNOFO}
              disabled={
                !selectedFile ||
                !customGrantName.trim() ||
                !uploadGrantType ||
                (uploadGrantType === "state" && !uploadState) ||
                !uploadCategory
              }
            >
              <LuUpload size={16} className="button-icon" aria-hidden="true" /><span>Upload grant</span>
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
});

export default NOFOsTab;
