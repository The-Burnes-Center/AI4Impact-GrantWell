import React, { Suspense, useEffect, useRef } from "react";
import {
  Route,
  Routes,
  Navigate,
  useLocation,
} from "react-router";
import { ErrorBoundary } from "./components/common/ErrorBoundary";
import { NotificationProvider } from "./components/notifications/NotificationManager";
import NotificationBar from "./components/notifications/NotificationBar";
import { AccessDeniedProvider } from "./components/access-denied/AccessDeniedManager";
import { useBranding } from "./common/branding";
import { PageTitleProvider, usePageTitleOverride } from "./common/page-title";
import { IS_PROD } from "./common/instance";
import { EDITOR_STEPS } from "./common/helpers/document-editor-utils";
import NotFoundPage from "./pages/not-found/NotFoundPage";
import "./styles/app.scss";
import LoadingSpinner from "./components/ui/LoadingSpinner";

const Playground = React.lazy(() => import("./pages/chat/playground/PlaygroundPage"));
const SessionPage = React.lazy(() => import("./pages/chat/sessions/SessionsPage"));
const HomePage = React.lazy(() => import("./pages/home/HomePage"));
const Checklists = React.lazy(() => import("./pages/requirements/ChecklistPage"));
const DocumentEditor = React.lazy(() => import("./pages/document-editor/DocumentEditorPage"));
const DocEditorSessionsPage = React.lazy(() => import("./pages/document-editor/DocEditorSessionsPage"));
const Dashboard = React.lazy(() => import("./pages/dashboard/DashboardPage"));
const ProfilePage = React.lazy(() => import("./pages/profile/ProfilePage"));
const DocumentsPage = React.lazy(() => import("./pages/documents/DocumentsPage"));
const GrantPdfPage = React.lazy(() => import("./pages/grant-pdf/GrantPdfPage"));
const WhatsNewContent = React.lazy(() =>
  import("./pages/whats-new/WhatsNewPage").then((m) => ({ default: m.WhatsNewContent }))
);

function ScrollToTop(): null {
  const { pathname, search, hash } = useLocation();
  const prevPathRef = useRef<string>("");
  const { appName, analyticsId } = useBranding();
  const titleOverride = usePageTitleOverride();

  useEffect(() => {
    const fullPath = pathname + search;
    const routeChanged = prevPathRef.current !== fullPath;

    // Not on a hash-only change: in-page jump links and the Requirements tabs write the hash.
    if (routeChanged) {
      document.getElementById("main-content")?.focus({ preventScroll: true });
    }

    // Wizard steps navigate by query string only, so the browser keeps the previous offset.
    if (routeChanged && !hash) {
      window.scrollTo({ top: 0, left: 0, behavior: "auto" });
    }

    // Page label per route; the app name is appended from branding.
    const getPageLabel = (path: string): string | null => {
      const exactMatches: { [key: string]: string } = {
        "/": "Home",
        "/home": "Home",
        "/admin": "Admin dashboard",
        "/profile": "Profile",
        "/chat/sessions": "My chats",
        "/document-editor": "Write application",
        "/document-editor/drafts": "My applications",
        "/documents": "My documents",
        "/whats-new": "What's new",
      };

      if (exactMatches[path]) {
        return exactMatches[path];
      }

      if (path.startsWith("/chat/") && path !== "/chat/sessions") {
        return "Chat with AI";
      }
      if (path.startsWith("/document-editor/") && path !== "/document-editor/drafts") {
        return "Write application";
      }
      if (path.startsWith("/requirements/")) {
        return "Requirements";
      }

      return null;
    };

    const label = titleOverride ?? getPageLabel(pathname);
    const home = pathname === "/" || pathname === "/home";
    const step =
      !titleOverride &&
      label === "Write application" &&
      EDITOR_STEPS.find((s) => s.id === new URLSearchParams(search).get("step"));
    const baseTitle = !label
      ? appName
      : home
      ? `${label} – ${appName}`
      : step
      ? `${step.label} – ${label} – ${appName}`
      : `${label} – ${appName}`;
    document.title = baseTitle;

    const fullUrl = window.location.origin + fullPath;

    if (routeChanged) {
      prevPathRef.current = fullPath;
      
      if (IS_PROD && analyticsId && typeof window !== "undefined" && window.gtag) {
        window.gtag("config", analyticsId, {
          page_title: baseTitle,
          page_path: fullPath,
          page_location: fullUrl,
        });
      }
    }
  }, [pathname, search, hash, appName, analyticsId, titleOverride]);

  return null;
}

function App() {
  return <AppContent />;
}

function AppContent() {
  return (
    <NotificationProvider>
      <AccessDeniedProvider>
      <PageTitleProvider>
      <ScrollToTop />
      {/* Brand Banner, Header, and Footer are now rendered globally in AppConfigured */}
      <main id="main-content" tabIndex={-1}>
        <NotificationBar />
        <ErrorBoundary>
          <Suspense fallback={<LoadingSpinner message="Loading…" showMessage />}>
            <Routes>
            <Route
              index
              path="/"
              element={<Navigate to={`/home`} replace />}
            />
            <Route path="/login" element={<Navigate to="/home" replace />} />
            <Route path="/home" element={<HomePage />} />
            <Route
              path="/requirements/:documentIdentifier"
              element={<Checklists />}
            />
            <Route path="/chat/:sessionId" element={<Playground />} />
            <Route path="/chat/sessions" element={<SessionPage />} />
            <Route path="/document-editor" element={<DocumentEditor />} />
            <Route
              path="/document-editor/:sessionId"
              element={<DocumentEditor />}
            />
            <Route
              path="/document-editor/drafts"
              element={<DocEditorSessionsPage />}
            />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/documents" element={<DocumentsPage />} />
            <Route path="/whats-new" element={<WhatsNewContent />} />
            <Route path="/grant-pdf" element={<GrantPdfPage />} />
            <Route path="/admin" element={<Dashboard />} />
            <Route
              path="/admin/dashboard"
              element={<Navigate to="/admin" replace />}
            />
            <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </Suspense>
        </ErrorBoundary>
      </main>
      </PageTitleProvider>
      </AccessDeniedProvider>
    </NotificationProvider>
  );
}

export default App;
