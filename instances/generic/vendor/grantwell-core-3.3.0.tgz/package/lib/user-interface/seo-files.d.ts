import { InstanceConfig } from "../config/instance-config";
export interface ResolvedSeo {
    indexable: boolean;
    title: string;
    description: string;
    ogImage?: {
        path: string;
        alt: string;
    };
}
export declare function resolveSeo(config: InstanceConfig): ResolvedSeo;
/** The site-root files core writes into the UI build, keyed by their path under public/. */
export declare function seoFiles(config: InstanceConfig): Record<string, string>;
/** Run after the instance overlay, so a state's own copy of one of these fails instead of being overwritten. */
export declare function writeSeoFiles(appPath: string, config: InstanceConfig): void;
