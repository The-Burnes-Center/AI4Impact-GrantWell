import { Branding } from "../config/instance-config";
/**
 * Copies an instance's own files into the UI project's public/. A file the UI already ships is
 * never replaced: an upgrade could otherwise change it underneath the instance without notice.
 */
export declare function applyPublicOverlay(appPath: string, publicDir: string): void;
/** Fails the synth when a branding image isn't served by the site, instead of a broken image in production. */
export declare function checkBrandingImages(appPath: string, branding: Branding): void;
/** Copies the instance's chrome/ into the UI as src/instance-chrome/, where the UI looks for it. */
export declare function applyChromeOverlay(appPath: string, chromeDir: string): void;
