import * as cf from "aws-cdk-lib/aws-cloudfront";
import { Construct } from "constructs";
import { ChatBotApi } from "../chatbot-api";
import { InstanceConfig } from "../config/instance-config";
export interface UserInterfaceProps {
    readonly config: InstanceConfig;
    readonly uiSourceDir: string;
    /** The instance's own public files (logos, favicon), added to the UI's public/. */
    readonly publicDir?: string;
    /** The instance's own chrome components, copied to the UI's src/instance-chrome/. */
    readonly chromeDir?: string;
    readonly userPoolId: string;
    readonly userPoolClientId: string;
    readonly api: ChatBotApi;
    readonly cognitoDomain: string;
}
export declare class UserInterface extends Construct {
    readonly distribution: cf.Distribution;
    constructor(scope: Construct, id: string, props: UserInterfaceProps);
}
