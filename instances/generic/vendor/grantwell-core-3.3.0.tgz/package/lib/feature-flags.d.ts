export declare const featureFlags: Record<string, unknown>;
