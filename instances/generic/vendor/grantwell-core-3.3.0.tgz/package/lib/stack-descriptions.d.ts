import * as cdk from 'aws-cdk-lib';
import { InstanceConfig } from './config/instance-config';
/** Sets a readable template Description on the root stack and every stack under it. */
export declare function describeStacks(root: cdk.Stack, config: InstanceConfig): void;
