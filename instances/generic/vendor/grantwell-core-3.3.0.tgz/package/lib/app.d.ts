import 'source-map-support/register';
import * as cdk from 'aws-cdk-lib';
import { InstanceConfig } from './config/instance-config';
export interface RunGrantWellAppOptions {
    /** UI project to build. Defaults to the `grantwell-ui` package installed next to the app. */
    readonly uiSourceDir?: string;
    /** The instance's own public files. Defaults to `public/` in the app directory, when it exists. */
    readonly publicDir?: string;
    /** The instance's own banner, header, footer and public home (see the UI's chrome-api). Defaults to `chrome/`, when it exists. */
    readonly chromeDir?: string;
}
/** Synthesises the deployment whose `aws.environment` matches the ENVIRONMENT env var. */
export declare function runGrantWellApp(instances: InstanceConfig[], options?: RunGrantWellAppOptions): cdk.App;
