import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import * as sns from "aws-cdk-lib/aws-sns";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as logs from "aws-cdk-lib/aws-logs";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import * as sqs from "aws-cdk-lib/aws-sqs";
import * as apigwv2 from "aws-cdk-lib/aws-apigatewayv2";
import * as cf from "aws-cdk-lib/aws-cloudfront";
import { InstanceConfig } from "../config/instance-config";
import type { BedrockModelUse } from "../chatbot-api/functions/functions";
/**
 * - `critical`: users can't use GrantWell right now. Red (prod only).
 * - `medium`: something is degraded, or heading for critical. Yellow.
 * - `low`: worth knowing, nothing is broken. Blue.
 *
 * Reaches the formatter as a `[severity]` prefix on the description, which it strips.
 */
export type Severity = "critical" | "medium" | "low";
/** Log lines the handlers already emit. Rewording one disarms its alarm; 16a's unit tests pin them. */
export declare const LOG_MARKERS: {
    readonly turnstileUnavailable: readonly ["Turnstile siteverify returned a non-OK status", "Turnstile siteverify call failed"];
    readonly turnstileNotConfigured: readonly ["TURNSTILE_SECRET_KEY is not set"];
    readonly accountSetupFailed: readonly ["Failed to set custom:state at confirmation", "Failed to revoke sessions after password reset"];
    readonly kbRetrieveFailed: readonly ["could not retrieve Knowledge Base documents"];
    readonly grantSearchFailed: readonly ["Hybrid search error:"];
    readonly createMetadataFailed: readonly ["Error processing record:"];
    readonly draftVersionWriteFailed: readonly ["draft-version-writer failed on"];
    readonly pipelineDispatchFailed: readonly ["Error dispatching SQS record:"];
    readonly scraperFatal: readonly ["Fatal coordinator error:"];
    readonly digestSendFailed: readonly ["Digest send failed for", "Digest failed for user"];
    readonly modelCanaryFailed: readonly ["Model canary failed for"];
    readonly queueEmailSendFailed: readonly ["Processing queue email send failed"];
    readonly chatCapReached: readonly ["Daily chat message limit reached"];
    readonly applicationCapReached: readonly ["Daily application limit reached"];
};
export interface MonitoringStackProps extends cdk.NestedStackProps {
    readonly config: InstanceConfig;
    readonly httpApi: apigwv2.IHttpApi;
    readonly distribution: cf.IDistribution;
    readonly chatFunction: lambda.IFunction;
    /** The function that starts application generation logs here, not under /aws/lambda/. */
    readonly draftGeneratorApiLogGroup: logs.ILogGroup;
    readonly websocketAuthorizerFunction: lambda.IFunction;
    readonly signupTriggerFunction: lambda.IFunction;
    readonly createMetadataFunction: lambda.IFunction;
    readonly syncKBFunction: lambda.IFunction;
    readonly draftVersionWriterFunction: lambda.IFunction;
    readonly draftVersionWriterFailures: sqs.IQueue;
    readonly aiGrantSearchFunction: lambda.IFunction;
    readonly applicationPdfGeneratorFunction: lambda.IFunction;
    readonly nofoPipeline: {
        readonly stateMachine: sfn.IStateMachine;
        readonly extractText: lambda.IFunction;
        readonly extractAndAnalyze: lambda.IFunction;
        readonly synthesize: lambda.IFunction;
        readonly contentCheck: lambda.IFunction;
        readonly dispatcher: lambda.IFunction;
        readonly dlqProcessor: lambda.IFunction;
    };
    readonly draftGeneration: {
        readonly stateMachine: sfn.IStateMachine;
        readonly generateSection: lambda.IFunction;
    };
    readonly scraperCoordinatorFunction: lambda.IFunction;
    readonly notificationDigestFunction: lambda.IFunction;
    /** Only where the deployment has the processing-queue email on. */
    readonly processingQueueEmailFunction?: lambda.IFunction;
    readonly autoArchiveFunction: lambda.IFunction;
    readonly bedrockModels: readonly BedrockModelUse[];
}
export declare class MonitoringStack extends cdk.NestedStack {
    /** Alarms publish here; the formatter is the only subscriber. */
    readonly alarmTopic: sns.Topic;
    /** Readable alerts. This is the topic AWS Chatbot subscribes to. */
    readonly alertTopic: sns.Topic;
    readonly alarms: cloudwatch.Alarm[];
    /** Deploy workflows invoke it after every deploy, through the root stack's ModelCanaryFunctionName output. */
    readonly modelCanaryFunctionName: string;
    private readonly prefix;
    private readonly stage;
    private readonly logGroupPolicy;
    private readonly ensuredLogGroups;
    constructor(scope: Construct, id: string, props: MonitoringStackProps);
    /**
     * If the formatter breaks, alarms still fire but nothing reaches Slack, which looks healthy.
     * So its own two alarms publish straight to the alerts topic: a broken formatter degrades to
     * Chatbot's raw card rather than to silence.
     */
    private addAlertFormatter;
    private addSiteAndApiAlarms;
    /**
     * The trigger throws on purpose to reject a sign-up or sign-in, so its Errors count includes
     * every bot and unsupported-state rejection. The Turnstile markers separate an outage from that.
     */
    private addSignInAlarms;
    private addEmailAlarms;
    private addChatAndSearchAlarms;
    /** Counted, never alarmed: a user at a daily cap is the cap working. */
    private addDailyCapMetrics;
    private addDocumentAlarms;
    /**
     * Failures in the first four steps are caught into Quarantine (admin review) and the execution
     * SUCCEEDS; only Publish and Quarantine can fail it. So ExecutionsFailed means a NOFO that is
     * neither published nor waiting for review, and per-step Errors say which stage is breaking.
     */
    private addNofoPipelineAlarms;
    private addDraftAlarms;
    private addScheduledJobAlarms;
    /**
     * Covers every function whose name starts with the stack name, found at run time, so functions
     * added later are covered without touching this file. Its own log group is outside that prefix.
     */
    private addInitErrorScan;
    private addModelCanary;
    /** Every empty hour breaches, so this fires 24 hours after the last run rather than at a fixed day boundary. */
    private dailyHeartbeat;
    private addDailyBrief;
    /**
     * Counts log lines matching any of `phrases` in `fn`'s default log group.
     *
     * That group only exists once the function has run, and a metric filter on a missing group fails
     * the deploy, so a custom resource creates it first (ignoring "already exists").
     */
    private markerMetric;
    private ensureLogGroup;
    /** One alarm, named for a human reading Slack, with ALARM and OK wired to the topics. */
    private alarm;
}
