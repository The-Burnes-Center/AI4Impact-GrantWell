/**
 * This file defines the main stack for the GrantWell application using AWS CDK.
 * It sets up the authorization stack, chatbot API, and user interface, integrating them with Cognito for user authentication.
 */
import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { InstanceConfig } from "./config/instance-config";
export interface GrantWellStackProps extends cdk.StackProps {
    readonly config: InstanceConfig;
    /** UI project directory; copied before building, never written to. */
    readonly uiSourceDir: string;
    /** The instance's own public files, added to the UI's public/. */
    readonly publicDir?: string;
    /** The instance's own chrome components, copied into the UI build. */
    readonly chromeDir?: string;
}
export declare class GrantWellStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props: GrantWellStackProps);
}
