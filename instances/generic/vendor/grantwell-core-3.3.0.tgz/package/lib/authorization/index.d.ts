import { Construct } from 'constructs';
import { UserPool, UserPoolClient } from 'aws-cdk-lib/aws-cognito';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { InstanceConfig } from '../config/instance-config';
export interface AuthorizationStackProps {
    readonly config: InstanceConfig;
    readonly turnstileSecretKey?: string;
}
export declare class AuthorizationStack extends Construct {
    readonly lambdaAuthorizer: lambda.Function;
    /** PreSignUp, PostConfirmation and PreAuthentication share this one function. */
    readonly signupTriggerFunction: lambda.Function;
    readonly userPool: UserPool;
    readonly userPoolClient: UserPoolClient;
    constructor(scope: Construct, id: string, props: AuthorizationStackProps);
}
