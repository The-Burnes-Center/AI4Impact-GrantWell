export interface Link {
    label: string;
    href: string;
}
export interface LogoLink extends Link {
    logo?: string;
    className?: string;
}
/** One per instance, shared by its deployments. Plain JSON: core reads it at synth for emails. */
export interface Branding {
    appName: string;
    orgName: string;
    postalAddress: string;
    /** Shown in the UI, and the Reply-To on auth mail. */
    supportEmail: string;
    colors: {
        primary: string;
        primaryHover?: string;
        primaryActive?: string;
        primaryLight?: string;
        accent?: string;
        accentHover?: string;
    };
    /** Image paths are site-root URLs, e.g. "/images/marketing/logo.svg". */
    logo: string;
    favicon: string;
    footer: {
        /** Also the digest email header image; falls back to `logo`. */
        wordmark?: string;
        madeBy?: LogoLink;
        partners: LogoLink[];
    };
    omniPartners: Link[];
    /** A government deployment's identity: a strip above every page (logo + label, linking to href) and the logo beside the app logo. */
    govHeader?: {
        logo: string;
        label: string;
        href: string;
    };
    analyticsId?: string;
    seo?: {
        /** Home page <title>, at most 60 characters. Defaults to appName. */
        title?: string;
        /** Meta description, about 150 characters. */
        description?: string;
        /** 1200×630 share image, a site-root path like logo. No og:image when unset. */
        ogImage?: {
            path: string;
            alt: string;
        };
    };
}
export interface UsState {
    code: string;
    name: string;
}
interface InstanceConfigBase {
    /** Readable ID, e.g. "generic-prod", lowercase-kebab. Frozen AWS names never use it; monitoring names do (`grantwell-<id>`). */
    id: string;
    /** The instance this deployment belongs to, lowercase-kebab, e.g. "generic". Tagged as Instance. */
    instance: string;
    stage: "prod" | "dev";
    /** Frozen once deployed. Core derives every other physical name from these. */
    aws: {
        stackName: string;
        /** Prefix of the SES configuration sets; also baked into the UI build. */
        environment: string;
        cognitoDomainPrefix: string;
        knowledgeBaseIndexName: string;
        /** The vector collection's tags can't change after creation; set this to what a deployed one carries. Defaults to coreTags. */
        collectionTags?: Record<string, string>;
    };
    /** Public site URL, no trailing slash. */
    siteUrl: string;
    customDomain?: {
        domainName: string;
        certificateArn: string;
    };
    auth: {
        mfaRequired: boolean;
        /** "off" turns MFA off entirely (no authenticator setup); otherwise mfaRequired picks required or optional. */
        mfa?: "off";
        oidcProviderName?: string;
        /** ISO timestamp with offset. Until then the UI urges MFA at each sign-in; from then it blocks the app until the user enrolls. */
        mfaDeadline?: string;
        /** Cloudflare Turnstile on sign-up and sign-in; on unless false. Off needs no TURNSTILE_* keys. */
        turnstile?: boolean;
    };
    /** SES, or Cognito's own sender for an account without SES; the digest needs SES and is off without it. */
    email: SesEmail | {
        cognitoDefault: true;
    };
    scraper: {
        dailySchedule: boolean;
    };
    /** Admin emails, off unless set. They need an SES sender. */
    notifications?: {
        /**
         * Weekdays at 09:00 Eastern, when grants are waiting in the processing queue, one email to the
         * comma-separated addresses in the SSM String parameter `queueEmailRecipientsParameter(config)`.
         */
        processingQueueEmail?: boolean;
    };
    /** Alarms always ship; this adds the once-a-day health brief to the alerts topic. */
    monitoring: {
        dailyBrief: boolean;
    };
    /** Search engines may index the home page. Off unless set; never on a dev stage. */
    seo?: {
        indexable: boolean;
    };
    /** https URL the in-app feedback form is forwarded to; unset, feedback is only logged. */
    feedbackFormUrl?: string;
    /** Abuse and cost limits; every key is optional, `limits(config)` fills in the defaults. */
    limits?: Partial<Limits>;
    /** Dev only. These accounts may sign in past Turnstile with the token in SSM at `e2eBypassParameter(config)`. */
    e2e?: {
        testEmails: string[];
    };
    /** Extra tags for every resource except the vector collection. Project, Instance and Stage come from core. */
    tags: Record<string, string>;
    branding: Branding;
}
export interface SesEmail {
    /** Its domain is the SES identity auth and digest mail send from. */
    sender: string;
    /** False when another deployment in the same account and region already owns the identity. */
    manageSenderIdentity: boolean;
}
/** Stage-wide API Gateway throttling: shared by every caller, not per user. */
export interface Throttle {
    /** Steady requests per second. */
    rateLimit: number;
    /** Requests allowed in a burst above the steady rate. */
    burstLimit: number;
}
export interface Limits {
    /** Chat messages per user per UTC day. Admins are exempt. */
    chatMessagesPerDay: number;
    /** Generated applications per user per UTC day. Admins are exempt. */
    applicationsPerDay: number;
    /** Reserved concurrency of the chat Lambda: its ceiling, and taken from the account's shared pool. */
    chatConcurrency: number;
    httpApiThrottle: Throttle;
    websocketThrottle: Throttle;
}
export declare const DEFAULT_LIMITS: Limits;
export declare function limits(config: InstanceConfig): Limits;
export declare function turnstileEnabled(config: InstanceConfig): boolean;
/** The deployment's only state when tenancy is single: every user belongs to it. */
export declare function singleState(config: InstanceConfig): UsState | undefined;
/** Undefined when the deployment sends with Cognito's default sender. */
export declare function sesEmail(config: InstanceConfig): SesEmail | undefined;
export type InstanceConfig = InstanceConfigBase & ({
    tenancy: "single";
    states: [UsState];
} | {
    tenancy: "multi";
    states: UsState[];
});
export declare function validateInstanceConfig(config: InstanceConfig): void;
/** Reserved (RFC 2606), so no real person can hold an e2e account. The trigger Lambda re-checks it. */
export declare const E2E_TEST_EMAIL_DOMAIN = "@grantwell.invalid";
/** SecureString created out of band; only deployments with `e2e` can read it. */
export declare function e2eBypassParameter(config: InstanceConfig): string;
/** String parameter created out of band so the addresses stay out of the repo. */
export declare function queueEmailRecipientsParameter(config: InstanceConfig): string;
export declare function processingQueueEmailEnabled(config: InstanceConfig): boolean;
/** Tags core puts on every stack and resource. None of them may change for a deployed stack; see collectionTags. */
export declare function coreTags(config: InstanceConfig): Record<string, string>;
/** Prefix for monitoring names. The AWS account may be shared, so every one starts with "grantwell-". */
export declare function monitoringPrefix(config: InstanceConfig): string;
/** [{code,name}] so handlers get both membership checks and display names from one env var. */
export declare function supportedStatesEnv(config: InstanceConfig): string;
export {};
