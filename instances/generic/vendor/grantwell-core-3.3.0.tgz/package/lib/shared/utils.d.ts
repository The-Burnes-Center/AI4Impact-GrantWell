/**
 * This file defines utility functions used throughout the GrantWell application.
 * The Utils class provides a method for recursively copying directories and their contents.
 */
export declare abstract class Utils {
    static copyDirRecursive(sourceDir: string, targetDir: string): void;
}
