import type { InstanceConfig } from "../config/instance-config";
export interface Finding {
    level: "fail" | "warn";
    message: string;
}
export declare function chromeApiVersion(uiAppDir: string): number;
export declare function checkChromeVersion(chromeDir: string, uiAppDir: string): Finding[];
/** Every `--gw-*` name the GrantWell UI uses or defines: the only ones a chrome may set or read. */
export declare function knownTokens(uiAppDir: string): Set<string>;
export declare function checkChromeTokens(chromeDir: string, uiAppDir: string): Finding[];
export interface CompileOptions {
    /** Link this node_modules instead of running `npm ci` (tests, local runs). */
    nodeModulesDir?: string;
}
/** Type-checks chrome/ inside a copy of the shipped UI app, as the deploy's UI build does. */
export declare function checkChromeCompiles(chromeDir: string, uiAppDir: string, options?: CompileOptions): Finding[];
/** Deploy workflows read ModelCanaryFunctionName from `cdk deploy --outputs-file` to run check-models.sh. */
export declare function checkCanaryOutput(templatesDir: string, instances: InstanceConfig[]): Finding[];
export declare function checkScripts(instanceDir: string, shippedDir: string, version: string): Finding[];
/** Replaces scripts/ files with the release's copies. Writes then renames, so a running upgrade.sh keeps reading its old file. */
export declare function syncScripts(instanceDir: string, shippedDir: string): string[];
export declare function checkDeployWorkflow(instanceDir: string): Finding[];
/** Upgrade only: fails when a stateful resource in `before` is gone from, or would be replaced in, `after`. */
export declare function checkStateful(beforeDir: string, afterDir: string): Finding[];
/** The template's example values, which would deploy something that isn't yours. */
export declare function checkPlaceholders(instances: InstanceConfig[], level?: Finding["level"]): Finding[];
