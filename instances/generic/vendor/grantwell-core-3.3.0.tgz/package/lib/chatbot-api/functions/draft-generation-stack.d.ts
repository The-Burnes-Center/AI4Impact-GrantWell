/**
 * Nested stack holding the draft generation Step Functions pipeline: the prepare,
 * per-section generate and assemble Lambdas, their log groups, and the state machine
 * that chains them. Split out of the main app stack to stay under the 500-resource
 * CloudFormation limit.
 *
 * The NOFO bucket, the draft and draft-generation-jobs tables, the knowledge base and
 * the Bedrock inference profile stay in the parent: they are shared with functions
 * outside this stack or their physical identity must survive this refactor.
 *
 * The draft editor API handler and the draft version writer stay in the parent too:
 * the first is an API Gateway integration target, the second binds a DynamoDB stream
 * event source on a parent-owned table.
 */
import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { Table } from "aws-cdk-lib/aws-dynamodb";
export interface DraftGenerationStackProps extends cdk.NestedStackProps {
    readonly ffioNofosBucket: s3.Bucket;
    readonly draftTable: Table;
    readonly draftGenerationJobsTable: Table;
    /** Knowledge base owned by the parent; each section step only retrieves from it. */
    readonly knowledgeBaseId: string;
    readonly jsSharedLayer: lambda.ILayerVersion;
    /** Bedrock application inference profile owned by the parent. */
    readonly sonnetDraftProfileArn: string;
    readonly supportedStatesEnv: string;
    readonly legacyStatelessAdminIsPlatform: string;
}
export declare class DraftGenerationStack extends cdk.NestedStack {
    readonly draftGenerationStateMachine: sfn.StateMachine;
    readonly draftGenerateSectionFunction: lambda.Function;
    constructor(scope: Construct, id: string, props: DraftGenerationStackProps);
}
