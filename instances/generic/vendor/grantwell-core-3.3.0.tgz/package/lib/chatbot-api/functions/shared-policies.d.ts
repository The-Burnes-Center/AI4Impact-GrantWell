/**
 * IAM policy statements shared by the main app stack (functions.ts) and the nested
 * stacks split out of it.
 *
 * These are factories, not shared constants: a PolicyStatement is mutable and CDK
 * freezes it once rendered, so handing the same instance to roles in two different
 * stacks makes one stack's grants observable from the other. Every call returns a
 * fresh statement.
 *
 * Signatures take plain ARN strings rather than constructs so nested stacks can call
 * them with the parent-owned ARNs they receive as props, without importing the
 * construct across the stack boundary.
 */
import * as iam from "aws-cdk-lib/aws-iam";
export declare function s3ReadWritePolicy(bucketArn: string): iam.PolicyStatement;
export declare function s3ReadOnlyPolicy(bucketArn: string): iam.PolicyStatement;
export declare function s3ListBucketPolicy(bucketArn: string): iam.PolicyStatement;
export declare function s3ObjectReadWriteDeletePolicy(bucketArn: string): iam.PolicyStatement;
export declare function bedrockInvokePolicy(): iam.PolicyStatement;
export declare function textractPolicy(): iam.PolicyStatement;
export declare function metadataTableReadWritePolicy(tableArn: string): iam.PolicyStatement;
export declare function reviewTableReadWritePolicy(tableArn: string): iam.PolicyStatement;
export declare function dynamoUpdateItemPolicy(tableArn: string): iam.PolicyStatement;
export declare function lambdaInvokePolicy(functionArn: string): iam.PolicyStatement;
export declare function sesSendEmailPolicy(fromAddress: string): iam.PolicyStatement;
