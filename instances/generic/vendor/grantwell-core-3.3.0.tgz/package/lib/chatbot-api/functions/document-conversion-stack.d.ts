/**
 * Nested stack holding the document-conversion Lambda functions (HTML/DOCX <-> PDF)
 * and the layers used only by them. Split out of the main app stack to stay under
 * the 500-resource CloudFormation limit.
 */
import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as s3 from "aws-cdk-lib/aws-s3";
import { Table } from "aws-cdk-lib/aws-dynamodb";
export interface DocumentConversionStackProps extends cdk.NestedStackProps {
    readonly ffioNofosBucket: s3.Bucket;
    readonly analyticsTable: Table;
    /** Shared with functions outside this stack, so it stays in the parent. */
    readonly jsSharedLayer: lambda.ILayerVersion;
    readonly nofoProcessingReviewTable: Table;
    readonly draftGenerationJobsTable: Table;
}
export declare class DocumentConversionStack extends cdk.NestedStack {
    readonly htmlToPdfConverterFunction: lambda.Function;
    readonly applicationPdfGeneratorFunction: lambda.Function;
    readonly docxToTextConverterFunction: lambda.Function;
    readonly applicationDocxGeneratorFunction: lambda.Function;
    readonly applicationExportsBucket: s3.Bucket;
    constructor(scope: Construct, id: string, props: DocumentConversionStackProps);
}
