/**
 * Nested stack holding the NOFO processing pipeline: the six Step Functions task Lambdas,
 * the state machine itself, the SQS dispatcher, the DLQ drain job and the admin review API
 * Lambda. Split out of the main app stack to stay under the 500-resource CloudFormation
 * limit.
 *
 * The processing queue and both DLQs, the NOFO bucket, the metadata/review tables, the
 * Bedrock inference profiles and the KB sync Lambda stay in the parent: they are shared
 * with functions outside this stack or their physical identity must survive this refactor.
 *
 * The admin Lambda comes along even though it is an API handler, because it invokes the
 * publish Lambda by name (PUBLISH_FUNCTION_NAME) — keeping the pair together keeps that
 * wiring inside one stack.
 */
import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { Table } from "aws-cdk-lib/aws-dynamodb";
export interface NofoPipelineStackProps extends cdk.NestedStackProps {
    readonly ffioNofosBucket: s3.Bucket;
    readonly nofoMetadataTable: Table;
    readonly nofoProcessingReviewTable: Table;
    /** Shared with functions outside this stack, so it stays in the parent. */
    readonly jsSharedLayer: lambda.ILayerVersion;
    /** Bedrock application inference profiles owned by the parent. */
    readonly sonnetNofoProfileArn: string;
    readonly haikuNofoProfileArn: string;
    /** Parent-owned KB sync Lambda, invoked by the publish step. */
    readonly syncKBFunctionArn: string;
    /**
     * ARN/URL of the processing queue, which stays in the parent (the bucket notifications that
     * feed it and its DLQ are parent-owned). Imported rather than passed as the Queue object:
     * SqsEventSource binds against a concrete Queue in another stack and a nested stack may not
     * depend on its parent.
     */
    readonly nofoProcessingQueueArn: string;
    readonly nofoProcessingQueueUrl: string;
    readonly nofoProcessingDlqArn: string;
    readonly nofoProcessingDlqUrl: string;
    readonly scraperDownloadDlqArn: string;
    readonly scraperDownloadDlqUrl: string;
    readonly supportedStatesEnv: string;
    readonly legacyStatelessAdminIsPlatform: string;
    readonly singleStateEnv: Record<string, string>;
    readonly stackName: string;
}
export declare class NofoPipelineStack extends cdk.NestedStack {
    readonly nofoProcessingStateMachine: sfn.StateMachine;
    readonly nofoAdminFunction: lambda.Function;
    readonly extractTextFunction: lambda.Function;
    readonly extractAndAnalyzeFunction: lambda.Function;
    readonly synthesizeFunction: lambda.Function;
    readonly validateFunction: lambda.Function;
    readonly dispatcherFunction: lambda.Function;
    readonly dlqProcessorFunction: lambda.Function;
    constructor(scope: Construct, id: string, props: NofoPipelineStackProps);
}
