/**
 * This file defines a construct for creating a WebSocket API using AWS API Gateway v2.
 * The WebSocket API is configured with a production stage that auto-deploys changes.
 * This construct can be used to define WebSocket endpoints for real-time communication in the backend.
 */
import { aws_apigatewayv2 as apigwv2 } from "aws-cdk-lib";
import { Construct } from "constructs";
import type { Throttle } from "../../config/instance-config";
export declare class WebsocketBackendAPI extends Construct {
    readonly wsAPI: apigwv2.WebSocketApi;
    readonly wsAPIStage: apigwv2.WebSocketStage;
    constructor(scope: Construct, id: string, props: {
        throttle: Throttle;
    });
}
