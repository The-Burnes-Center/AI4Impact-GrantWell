/**
 * This file defines a construct for creating an HTTP API using AWS API Gateway v2.
 * The API is configured with CORS settings to allow cross-origin requests.
 * This construct can be used to define RESTful endpoints for the backend.
 */
import { Construct } from "constructs";
import { aws_apigatewayv2 as apigwv2 } from "aws-cdk-lib";
import type { Throttle } from "../../config/instance-config";
export declare class RestBackendAPI extends Construct {
    readonly restAPI: apigwv2.HttpApi;
    constructor(scope: Construct, id: string, props: {
        throttle: Throttle;
    });
}
