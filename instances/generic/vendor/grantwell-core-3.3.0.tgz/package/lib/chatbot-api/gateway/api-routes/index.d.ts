/**
 * This file configures API routes for the REST API Gateway.
 * It maps HTTP routes to Lambda functions.
 */
import { aws_apigatewayv2 as apigwv2 } from "aws-cdk-lib";
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
export interface RoutesProps {
    httpApi: apigwv2.HttpApi;
    sessionFunction: lambda.Function;
    uploadS3Function: lambda.Function;
    deleteS3Function: lambda.Function;
    getS3Function: lambda.Function;
    uploadNOFOS3Function: lambda.Function;
    getNOFOsFunction: lambda.Function;
    getNOFOSummaryFunction: lambda.Function;
    kbSyncFunction: lambda.Function;
    applicationPdfGeneratorFunction: lambda.Function;
    draftGenerationJobsTableName: string;
}
export declare class Routes extends Construct {
    constructor(scope: Construct, id: string, props: RoutesProps);
}
