/**
 * This file defines a construct for creating and configuring a Bedrock Knowledge Base using AWS CDK.
 * The Knowledge Base is configured with OpenSearch Serverless for storage and an S3 bucket as a data source.
 * This construct sets up the necessary IAM roles and permissions, and configures the Knowledge Base and data source.
 */
import * as cdk from 'aws-cdk-lib';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { aws_bedrock as bedrock } from 'aws-cdk-lib';
import { Construct } from "constructs";
import { InstanceConfig } from "../../config/instance-config";
import { OpenSearchStack } from "../opensearch/opensearch";
export interface KnowledgeBaseStackProps {
    readonly config: InstanceConfig;
    readonly openSearch: OpenSearchStack;
    readonly s3bucket: s3.Bucket;
    readonly userDocumentsBucket?: s3.Bucket;
}
export declare class KnowledgeBaseStack extends cdk.Stack {
    readonly knowledgeBase: bedrock.CfnKnowledgeBase;
    readonly dataSource: bedrock.CfnDataSource;
    readonly userDocumentsDataSource?: bedrock.CfnDataSource;
    constructor(scope: Construct, id: string, props: KnowledgeBaseStackProps);
}
