import { Construct } from "constructs";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import * as lambda from "aws-cdk-lib/aws-lambda";
import { ITable } from "aws-cdk-lib/aws-dynamodb";
export interface DraftGenerationStateMachineProps {
    prepareFunction: lambda.Function;
    generateSectionFunction: lambda.Function;
    assembleFunction: lambda.Function;
    draftGenerationJobsTable: ITable;
}
export declare class DraftGenerationStateMachine extends Construct {
    readonly stateMachine: sfn.StateMachine;
    constructor(scope: Construct, id: string, props: DraftGenerationStateMachineProps);
}
