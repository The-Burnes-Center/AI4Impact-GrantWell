/**
 * This file defines the OpenSearchStack class, which sets up an OpenSearch Serverless collection and related resources using AWS CDK.
 * It includes creating the collection, security policies, IAM roles, and a Lambda function to create an index in the collection.
 */
import * as cdk from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from "constructs";
import { aws_opensearchserverless as opensearchserverless } from 'aws-cdk-lib';
import { InstanceConfig } from "../../config/instance-config";
type OssPolicyNames = {
    enc: string;
    network: string;
    access: string;
};
export declare function ossPolicyNamesFor(name: string): OssPolicyNames;
export declare const COLLECTION_RESOURCE_TYPE = "AWS::OpenSearchServerless::Collection";
export interface OpenSearchStackProps {
    readonly config: InstanceConfig;
}
export declare class OpenSearchStack extends cdk.Stack {
    readonly openSearchCollection: opensearchserverless.CfnCollection;
    readonly collectionName: string;
    readonly knowledgeBaseRole: iam.Role;
    readonly lambdaCustomResource: cdk.CustomResource;
    constructor(scope: Construct, id: string, props: OpenSearchStackProps);
}
export {};
