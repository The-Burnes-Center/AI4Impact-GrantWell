import { Utils } from "../utils";
import { AppConfig } from "../types/app";
import { apiFetch } from "../session-ended";

export class KbSyncStatusError extends Error {
  constructor(readonly status: number) {
    super(`Failed to check sync status (HTTP ${status})`);
  }
}

export class KBSyncClient {
  private readonly API: string;

  constructor(protected _appConfig: AppConfig) {
    this.API = _appConfig.httpEndpoint;
  }

  async isSyncing(): Promise<string> {
    const auth = await Utils.authenticate();
    const response = await apiFetch(`${this.API}/kb-sync/still-syncing`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: auth,
      },
    });

    if (!response.ok) {
      throw new KbSyncStatusError(response.status);
    }
    return await response.json();
  }

  async lastSync(): Promise<string> {
    const auth = await Utils.authenticate();
    const response = await apiFetch(`${this.API}/kb-sync/get-last-sync`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: auth,
      },
    });

    if (!response.ok) {
      throw new Error("Failed to check last sync");
    }
    return await response.json();
  }
}
