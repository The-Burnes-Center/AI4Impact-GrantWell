import type { FormEvent, ReactNode } from "react";
import { Button, Form, Spinner } from "react-bootstrap";
import PasswordRequirementsList from "../PasswordRequirementsList";
import { PasswordRequirements } from "../auth-types";
import { SINGLE_STATE, SUPPORTED_STATES, stateNameFromCode } from "../../../common/states";
import { signUpHandoffUrl, stateSiteFor } from "../../../common/state-sites";

interface SignUpStepProps {
  email: string;
  password: string;
  confirmPassword: string;
  showPassword: boolean;
  stateCode: string;
  loading: boolean;
  passwordRequirements: PasswordRequirements;
  onEmailChange: (value: string) => void;
  onPasswordChange: (value: string) => void;
  onConfirmPasswordChange: (value: string) => void;
  onShowPasswordChange: (checked: boolean) => void;
  onStateChange: (value: string) => void;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  onSwitchToSignIn: () => void;
  emailErrorId?: string;
  passwordErrorId?: string;
  confirmPasswordErrorId?: string;
  turnstile?: ReactNode;
}

export default function SignUpStep({
  email,
  password,
  confirmPassword,
  showPassword,
  stateCode,
  loading,
  passwordRequirements,
  onEmailChange,
  onPasswordChange,
  onConfirmPasswordChange,
  onShowPasswordChange,
  onStateChange,
  onSubmit,
  onSwitchToSignIn,
  emailErrorId,
  passwordErrorId,
  confirmPasswordErrorId,
  turnstile,
}: SignUpStepProps) {
  const stateSite = stateSiteFor(stateCode);
  const handoffUrl = stateSite && signUpHandoffUrl(stateSite, email);
  const goToStateSite = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (handoffUrl) window.location.assign(handoffUrl);
  };

  return (
    <div className="login-form" role="region" aria-labelledby="auth-card-title">
      <Form onSubmit={handoffUrl ? goToStateSite : onSubmit} aria-label="Create account form" noValidate>
        <Form.Group className="mb-3">
          <Form.Label className="form-label" htmlFor="signup-email-input">
            Email address <span aria-hidden="true">*</span>
          </Form.Label>
          <Form.Control
            id="signup-email-input"
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(event) => onEmailChange(event.target.value)}
            disabled={loading}
            autoComplete="email"
            required
            className="form-input"
            aria-required="true"
            aria-invalid={emailErrorId ? true : undefined}
            aria-describedby={emailErrorId}
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label className="form-label" htmlFor="signup-password-input">
            Password <span aria-hidden="true">*</span>
          </Form.Label>
          <Form.Control
            id="signup-password-input"
            type={showPassword ? "text" : "password"}
            placeholder="Enter password"
            value={password}
            onChange={(event) => onPasswordChange(event.target.value)}
            disabled={loading}
            autoComplete="new-password"
            required
            className="form-input"
            aria-required="true"
            aria-invalid={passwordErrorId ? true : undefined}
            aria-describedby={
              passwordErrorId
                ? `${passwordErrorId} password-requirements`
                : "password-requirements"
            }
          />
          <PasswordRequirementsList
            id="password-requirements"
            requirements={passwordRequirements}
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label className="form-label" htmlFor="confirm-password-input">
            Confirm password <span aria-hidden="true">*</span>
          </Form.Label>
          <Form.Control
            id="confirm-password-input"
            type={showPassword ? "text" : "password"}
            placeholder="Re-enter password"
            value={confirmPassword}
            onChange={(event) => onConfirmPasswordChange(event.target.value)}
            disabled={loading}
            autoComplete="new-password"
            required
            className="form-input"
            aria-required="true"
            aria-invalid={confirmPasswordErrorId ? true : undefined}
            aria-describedby={confirmPasswordErrorId}
          />
        </Form.Group>
        {!SINGLE_STATE && (
        <Form.Group className="mb-3">
          <Form.Label className="form-label" htmlFor="signup-state-select">
            State <span className="text-muted">(optional)</span>
          </Form.Label>
          <Form.Select
            id="signup-state-select"
            value={stateCode}
            onChange={(event) => onStateChange(event.target.value)}
            disabled={loading}
            className="form-input"
            aria-describedby="signup-state-help"
          >
            <option value="">Other</option>
            {SUPPORTED_STATES.map((s) => (
              <option key={s.code} value={s.code}>{s.name}</option>
            ))}
          </Form.Select>
          <Form.Text id="signup-state-help" muted>
            Pick your state to see federal grants plus state-specific grants for that state.
          </Form.Text>
          <div aria-live="polite">
            {stateSite && (
              <p className="auth-state-site-note" id="signup-state-site-note">
                {stateNameFromCode(stateSite.state)} has its own GrantWell site. Create your account there.
              </p>
            )}
          </div>
        </Form.Group>
        )}
        <div className="login-form-options">
          <Form.Check
            type="checkbox"
            id="signup-show-password-checkbox"
            label="Show password"
            checked={showPassword}
            onChange={(event) => onShowPasswordChange(event.target.checked)}
            className="show-password-checkbox"
          />
        </div>
        {!handoffUrl && turnstile}
        <div className="login-form-actions">
          {handoffUrl ? (
            <a href={handoffUrl} className="btn btn-primary login-submit-button" aria-describedby="signup-state-site-note">
              Go to GrantWell {stateNameFromCode(stateSite.state)}
            </a>
          ) : (
          <Button
            variant="primary"
            type="submit"
            disabled={loading}
            className="login-submit-button"
          >
            {loading ? (
              <>
                <Spinner animation="border" size="sm" aria-hidden="true" className="me-2" />
                <span className="visually-hidden">Loading</span>
                Creating account...
              </>
            ) : (
              "Create account"
            )}
          </Button>
          )}
        </div>
      </Form>
      <div className="login-form-footer login-form-footer--center">
        <span className="auth-footer-prompt">Have an account already?</span>
        <Button
          variant="link"
          type="button"
          onClick={onSwitchToSignIn}
          disabled={loading}
          className="create-account-link create-account-link--inline"
        >
          Sign in
        </Button>
      </div>
    </div>
  );
}
