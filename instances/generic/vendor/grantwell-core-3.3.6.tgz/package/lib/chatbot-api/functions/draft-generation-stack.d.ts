/**
 * Nested stack holding the draft generation Step Functions pipeline: the prepare,
 * per-section generate and assemble Lambdas, their log groups, and the state machine
 * that chains them. Split out of the main app stack to stay under the 500-resource
 * CloudFormation limit.
 *
 * The grant, artifact and user-document buckets, the draft and draft-generation-jobs tables
 * and the Bedrock inference profile stay in the parent: they are shared with functions
 * outside this stack or their physical identity must survive this refactor.
 *
 * The draft editor API handler and the draft version writer stay in the parent too:
 * the first is an API Gateway integration target, the second binds a DynamoDB stream
 * event source on a parent-owned table.
 */
import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { Table } from "aws-cdk-lib/aws-dynamodb";
export interface DraftGenerationStackProps extends cdk.NestedStackProps {
    readonly ffioNofosBucket: s3.Bucket;
    readonly grantArtifactsBucket: s3.Bucket;
    /** Each section step reads the requesting user's supporting documents from it. */
    readonly userDocumentsBucket: s3.Bucket;
    readonly draftTable: Table;
    readonly draftGenerationJobsTable: Table;
    readonly jsSharedLayer: lambda.ILayerVersion;
    /** Bedrock application inference profile owned by the parent. */
    readonly sonnetDraftProfileArn: string;
    /** Holds each document's per-grant relevance verdict; a section step checks a document that has none. */
    readonly userDocumentTable: Table;
    readonly haikuDocCheckProfileArn: string;
    readonly supportedStatesEnv: string;
    readonly legacyStatelessAdminIsPlatform: string;
    /** Haiku profile for the plan step's check of which sections have material. */
    readonly haikuDraftPlanProfileArn: string;
    /** Assemble gives back the day's application when a draft had nothing to write from. */
    readonly dailyUsageTable: Table;
}
export declare class DraftGenerationStack extends cdk.NestedStack {
    readonly draftGenerationStateMachine: sfn.StateMachine;
    readonly draftGenerateSectionFunction: lambda.Function;
    constructor(scope: Construct, id: string, props: DraftGenerationStackProps);
}
