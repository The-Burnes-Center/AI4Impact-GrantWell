/**
 * This file defines an AWS CDK stack that creates and configures DynamoDB tables.
 * The tables are used for storing chat history and application data.
 * Each table is configured with partition keys, sort keys, and global secondary indexes.
 */
import { Stack, StackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { Table } from 'aws-cdk-lib/aws-dynamodb';
export declare class TableStack extends Stack {
    readonly historyTable: Table;
    readonly draftTable: Table;
    readonly draftVersionTable: Table;
    readonly nofoMetadataTable: Table;
    readonly draftGenerationJobsTable: Table;
    readonly featureRolloutTable: Table;
    readonly nofoProcessingReviewTable: Table;
    readonly userNotificationPrefsTable: Table;
    readonly digestSendLogTable: Table;
    readonly digestSuppressionTable: Table;
    readonly nofoStateOverlayTable: Table;
    readonly analyticsTable: Table;
    readonly dailyUsageTable: Table;
    readonly applicationOutcomeTable: Table;
    readonly userDocumentTable: Table;
    constructor(scope: Construct, id: string, props?: StackProps);
}
