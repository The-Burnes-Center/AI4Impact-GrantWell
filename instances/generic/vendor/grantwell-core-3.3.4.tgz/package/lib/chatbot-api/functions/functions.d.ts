/**
 * This file defines the LambdaFunctionStack class, which sets up various Lambda functions for the GrantWell application using AWS CDK.
 * These Lambda functions handle session management, S3 operations, and knowledge base synchronization.
 */
import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import { InstanceConfig } from "../../config/instance-config";
import * as lambda from "aws-cdk-lib/aws-lambda";
import { Table } from "aws-cdk-lib/aws-dynamodb";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as bedrock from "aws-cdk-lib/aws-bedrock";
import * as sqs from "aws-cdk-lib/aws-sqs";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { aws_opensearchserverless as opensearchserverless } from "aws-cdk-lib";
/** A Bedrock model or inference profile the app calls, as the model canary checks it. */
export interface BedrockModelUse {
    readonly label: string;
    readonly kind: "anthropic" | "titan-embed" | "rerank";
    /** Exactly what the app passes as modelId (for rerank, the modelArn). */
    readonly modelId: string;
    /** What invoking it needs bedrock:InvokeModel on: the ID plus the foundation models a profile routes to. */
    readonly invokeResources: string[];
}
interface LambdaFunctionStackProps {
    readonly config: InstanceConfig;
    readonly wsApiEndpoint: string;
    readonly sessionTable: Table;
    readonly draftTable: Table;
    readonly draftVersionTable: Table;
    readonly nofoMetadataTable: Table;
    readonly nofoProcessingReviewTable: Table;
    readonly draftGenerationJobsTable: Table;
    readonly featureRolloutTable: Table;
    readonly userNotificationPrefsTable: Table;
    readonly digestSendLogTable: Table;
    readonly digestSuppressionTable: Table;
    readonly nofoStateOverlayTable: Table;
    readonly analyticsTable: Table;
    readonly dailyUsageTable: Table;
    readonly applicationOutcomeTable: Table;
    readonly ffioNofosBucket: s3.Bucket;
    readonly grantArtifactsBucket: s3.Bucket;
    readonly userDocumentsBucket: s3.Bucket;
    readonly knowledgeBase: bedrock.CfnKnowledgeBase;
    readonly knowledgeBaseSource: bedrock.CfnDataSource;
    readonly userDocumentsDataSource?: bedrock.CfnDataSource;
    readonly grantsGovApiKey: string;
    readonly digestLogoWidth: number;
    readonly openSearchCollection: opensearchserverless.CfnCollection;
    readonly userPool: cdk.aws_cognito.UserPool;
}
export declare class LambdaFunctionStack extends cdk.Stack {
    readonly chatFunction: lambda.Function;
    readonly sessionFunction: lambda.Function;
    readonly deleteS3Function: lambda.Function;
    readonly getS3Function: lambda.Function;
    readonly uploadS3Function: lambda.Function;
    readonly downloadS3Function: lambda.Function;
    readonly uploadNOFOS3Function: lambda.Function;
    readonly syncKBFunction: lambda.Function;
    readonly createMetadataFunction: lambda.Function;
    readonly getNOFOsList: lambda.Function;
    readonly getNOFOSummary: lambda.Function;
    readonly getNOFOQuestions: lambda.Function;
    readonly nofoProcessingStateMachine: sfn.StateMachine;
    readonly nofoAdminFunction: lambda.Function;
    readonly nofoPipelineFunctions: {
        extractText: lambda.Function;
        extractAndAnalyze: lambda.Function;
        synthesize: lambda.Function;
        contentCheck: lambda.Function;
        dispatcher: lambda.Function;
        dlqProcessor: lambda.Function;
    };
    readonly draftGenerateSectionFunction: lambda.Function;
    readonly nofoReprocessFunction: lambda.Function;
    readonly nofoStatusFunction: lambda.Function;
    readonly nofoRenameFunction: lambda.Function;
    readonly nofoDeleteFunction: lambda.Function;
    readonly draftFunction: lambda.Function;
    readonly draftVersionWriterFunction: lambda.Function;
    readonly draftVersionWriterFailures: sqs.Queue;
    readonly draftGenerationStateMachine: sfn.StateMachine;
    readonly scraperCoordinatorFunction: lambda.Function;
    readonly opportunityProcessorFunction: lambda.Function;
    readonly htmlToPdfConverterFunction: lambda.Function;
    readonly applicationPdfGeneratorFunction: lambda.Function;
    readonly docxToTextConverterFunction: lambda.Function;
    readonly applicationDocxGeneratorFunction: lambda.Function;
    readonly applicationExportsBucket: s3.Bucket;
    readonly autoArchiveExpiredNofosFunction: lambda.Function;
    readonly notificationDigestFunction: lambda.Function;
    readonly notificationDigestPreviewFunction: lambda.Function;
    readonly notificationDigestBroadcastFunction: lambda.Function;
    readonly processingQueueEmailFunction?: lambda.Function;
    readonly notificationUnsubscribeFunction: lambda.Function;
    readonly notificationSesFeedbackFunction: lambda.Function;
    readonly aiGrantSearchFunction: lambda.Function;
    readonly feedbackProxyFunction: lambda.Function;
    readonly nofoSummaryUpdateFunction: lambda.Function;
    readonly nofoStateOverlayFunction: lambda.Function;
    readonly nofoPromoteCopyFunction: lambda.Function;
    readonly userProfileFunction: lambda.Function;
    readonly analyticsFunction: lambda.Function;
    readonly applicationOutcomesFunction: lambda.Function;
    readonly bedrockModels: BedrockModelUse[];
    constructor(scope: Construct, id: string, props: LambdaFunctionStackProps);
}
export {};
