/**
 * Every <Route> path in the UI router (packages/ui/src/App.tsx and components/AppConfigured.tsx),
 * minus the "*" catch-all. `:name` matches one non-empty segment. test/ui-contract.test.ts fails
 * when this list and the UI's routes drift apart.
 */
export declare const APP_ROUTES: readonly ["/", "/login", "/home", "/whats-new", "/profile", "/admin", "/admin/dashboard", "/chat/sessions", "/chat/:sessionId", "/document-editor", "/document-editor/drafts", "/document-editor/:sessionId", "/requirements/:documentIdentifier"];
/**
 * CloudFront Function (viewer request) for the site's default behavior: app routes get
 * /index.html (/whats-new gets its pre-rendered /whats-new.html); everything else goes to the
 * bucket as a file request, so a missing file or unknown page is a real 404 with /404.html.
 * App routes can carry grant titles with dots (/requirements/U.S.%20Grants), so files are matched
 * by prefix, not by extension, and routes match case-insensitively with one optional trailing
 * slash, as the UI router does. Requests for a redirect host get a 301 to the same path on the
 * canonical host first.
 */
export declare const spaRoutingCode: (redirect?: {
    from: string[];
    to: string;
}) => string;
export declare const SPA_ROUTING_CODE: string;
