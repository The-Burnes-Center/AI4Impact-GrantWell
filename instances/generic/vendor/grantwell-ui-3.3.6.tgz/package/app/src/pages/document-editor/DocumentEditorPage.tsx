import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useLocation, useNavigate, useParams, useSearchParams } from "react-router";
import { useApiClient } from "../../hooks/use-api-client";
import { useDraftsClient } from "../../hooks/use-drafts-client";
import { useDraftSave } from "../../hooks/use-draft-save";
import { useStartDraft } from "../../hooks/use-start-draft";
import {
  stepToStatus,
  statusToStep,
  EDITOR_STEPS,
  stepToIndex,
  readDraftCache,
  sweepLegacyDraftCache,
} from "../../common/helpers/document-editor-utils";
import UnifiedNavigation from "../../components/navigation/UnifiedNavigation";
import ProjectBasics from "./ProjectBasics";
import QuickQuestionnaire from "./QuickQuestionnaire";
import SectionEditor from "./SectionsEditor";
import ReviewApplication from "./ReviewApplication";
import UploadDocuments from "./UploadDocuments";
import WelcomeModal from "./components/WelcomeModal";
import GrantPickerModal, { type PickedGrant } from "../../components/common/GrantPickerModal";
import { addToRecentlyViewed } from "../../common/helpers/recently-viewed-nofos";
import ProgressStepper from "../../components/document-editor/ProgressStepper";
import { LiveStatus } from "../../components/common/LiveStatus";
import PageMessage from "../../components/common/PageMessage";
import GrantHeader from "../../components/common/GrantHeader";
import { getCurrentUser } from "aws-amplify/auth";
import type { DocumentDraft } from "../../common/api-client/drafts-client";
import type { DocumentData } from "../../common/types/document";
import { usePageTitle } from "../../common/page-title";
import "../../styles/document-editor.css";

const ERROR_MESSAGES = {
  LOAD_FAILED: "Failed to load application",
  SAVE_FAILED: "Failed to save application",
  START_FAILED: "Failed to start new application",
} as const;

const FIRST_SECTION_STEP_INDEX = stepToIndex("sectionEditor");

/** Custom hook: loads the document via DraftsClient */
const useDocumentStorage = (nofoId: string | null) => {
  const [documentData, setDocumentData] = useState<DocumentData | null>(null);
  const [loadedDraft, setLoadedDraft] = useState<DocumentDraft | null | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState("Loading application...");
  const [error, setError] = useState<string | null>(null);
  const [notFound, setNotFound] = useState(false);
  const { sessionId } = useParams();
  const [searchParams] = useSearchParams();
  const draftsClient = useDraftsClient();
  const nofoIdRef = useRef(nofoId);
  nofoIdRef.current = nofoId;
  const openedStepRef = useRef(searchParams.get("step"));

  const loadDocument = useCallback(async () => {
    if (!sessionId) return;
    setIsLoading(true);
    setError(null);
    setNotFound(false);
    setLoadingMessage("Loading application...");

    try {
      const username = (await getCurrentUser()).username;
      if (username) {
        // Rows are created before the editor opens, so only a failed read is worth polling for.
        let draft: DocumentDraft | null;
        try {
          draft = await draftsClient.getDraft({ sessionId, userId: username });
        } catch {
          draft = await draftsClient.waitForDraft({
            sessionId,
            userId: username,
            onProgress: (message: string, attempt: number) => {
              setLoadingMessage(message);
              if (attempt === 15) setLoadingMessage("Draft generation is taking longer than expected. Please wait...");
              if (attempt === 30) setLoadingMessage("Draft generation is still in progress. This may take up to 2 minutes...");
            },
          });
        }

        const openedStep = openedStepRef.current;
        if (!draft && openedStep && stepToIndex(openedStep) > 0) {
          setLoadedDraft(null);
          setNotFound(true);
        } else if (draft) {
          // Cache wins: it holds edits whose save was still pending at exit.
          const cachedSections = readDraftCache<Record<string, string>>(sessionId, "sections");
          setDocumentData({
            id: draft.sessionId,
            nofoId: draft.documentIdentifier,
            sections: { ...(draft.sections || {}), ...(cachedSections || {}) },
            projectBasics: draft.projectBasics,
            questionnaire: draft.questionnaire,
            lastModified: draft.lastModified || new Date().toISOString(),
          });
          setLoadedDraft(draft);
        } else {
          setDocumentData({ id: sessionId, nofoId: nofoIdRef.current ?? "", sections: {}, lastModified: new Date().toISOString() });
          setLoadedDraft(null);
        }
      }
    } catch (err) {
      console.error("Failed to load document:", err);
      setError(ERROR_MESSAGES.LOAD_FAILED);
    } finally {
      setIsLoading(false);
    }
  }, [sessionId, draftsClient]);

  useEffect(() => { loadDocument(); }, [loadDocument]);

  return { documentData, setDocumentData, loadedDraft, isLoading, loadingMessage, error, setError, notFound };
};

const DocumentEditor: React.FC = () => {
  const [currentStep, setCurrentStep] = useState("projectBasics");
  const [selectedNofo, setSelectedNofo] = useState<string | null>(null);
  const [nofoName, setNofoName] = useState("");
  const [isNofoLoading, setIsNofoLoading] = useState(false);
  const [welcomeModalOpen, setWelcomeModalOpen] = useState(false);
  const [grantPickerOpen, setGrantPickerOpen] = useState(false);
  const [startingDraft, setStartingDraft] = useState(false);
  const [activeJobId, setActiveJobId] = useState<string | undefined>(undefined);
  const [isGeneratingDraft, setIsGeneratingDraft] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const stepRestoredForRef = useRef<string | null>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const { sessionId } = useParams();
  const [searchParams] = useSearchParams();

  const apiClient = useApiClient();
  const draftsClient = useDraftsClient();
  const startDraft = useStartDraft();

  const { documentData, setDocumentData, loadedDraft, isLoading, loadingMessage, error, setError, notFound } =
    useDocumentStorage(selectedNofo);

  const draftSave = useDraftSave({
    sessionId,
    documentIdentifier: selectedNofo,
    fallbackTitle: selectedNofo ? `Application for ${selectedNofo}` : undefined,
  });
  const { setBaseline, saveFields } = draftSave;

  useEffect(() => {
    if (loadedDraft !== undefined) setBaseline(loadedDraft);
  }, [loadedDraft, setBaseline]);

  useEffect(() => {
    if (!selectedNofo && loadedDraft?.documentIdentifier) setSelectedNofo(loadedDraft.documentIdentifier);
  }, [selectedNofo, loadedDraft]);

  // Covers opening Review straight from a link; navigating there saves it already.
  const reviewStatusSavedRef = useRef<string | null>(null);
  useEffect(() => {
    if (currentStep !== "reviewApplication" || !sessionId || loadedDraft?.sessionId !== sessionId) return;
    if (Object.keys(loadedDraft.sections || {}).length === 0) return;
    if (reviewStatusSavedRef.current === sessionId) return;
    reviewStatusSavedRef.current = sessionId;
    if (loadedDraft.status === "reviewing" || loadedDraft.status === "submitted") return;
    saveFields({ status: "reviewing" }, { source: "status_change", immediate: true }).catch((err: unknown) =>
      console.error("Could not save the review status:", err)
    );
  }, [currentStep, sessionId, loadedDraft, saveFields]);

  useEffect(() => { sweepLegacyDraftCache(); }, []);

  // Extract NOFO and step from URL
  useEffect(() => {
    const nofo = searchParams.get("grant") ?? searchParams.get("folder") ?? searchParams.get("nofo");
    const stepFromUrl = searchParams.get("step");
    if (nofo) setSelectedNofo(decodeURIComponent(nofo));
    if (stepFromUrl && EDITOR_STEPS.some((s) => s.id === stepFromUrl)) {
      setCurrentStep(stepFromUrl);
    }
  }, [searchParams]);

  useEffect(() => {
    if (!sessionId || !loadedDraft || loadedDraft.sessionId !== sessionId) return;
    if (stepRestoredForRef.current === sessionId) return;
    stepRestoredForRef.current = sessionId;

    const urlStep = searchParams.get("step");
    const urlNamesOpenableStep =
      !!urlStep &&
      EDITOR_STEPS.some((s) => s.id === urlStep) &&
      (stepToIndex(urlStep) < FIRST_SECTION_STEP_INDEX ||
        Object.keys(loadedDraft.sections || {}).length > 0);
    if (urlNamesOpenableStep) return;
    if (!loadedDraft.status) return;

    const statusStep = statusToStep(loadedDraft.status);
    setCurrentStep(statusStep);
    if (urlStep) {
      const corrected = new URLSearchParams(searchParams);
      corrected.set("step", statusStep);
      const legacyGrant = corrected.get("folder") ?? corrected.get("nofo");
      if (legacyGrant && !corrected.has("grant")) corrected.set("grant", legacyGrant);
      corrected.delete("folder");
      corrected.delete("nofo");
      navigate({ search: `?${corrected.toString()}` }, { replace: true });
    }
  }, [sessionId, loadedDraft, searchParams, navigate]);

  // Backfill for rows written before reached_steps existed.
  const draftFloorIndex = useMemo(() => {
    if (!loadedDraft) return 0;
    const fromStatus = loadedDraft.status ? stepToIndex(statusToStep(loadedDraft.status)) : 0;
    const fromSections =
      Object.keys(loadedDraft.sections || {}).length > 0 ? FIRST_SECTION_STEP_INDEX : 0;
    return Math.max(0, fromStatus, fromSections, ...(loadedDraft.reachedSteps || []).map(stepToIndex));
  }, [loadedDraft]);

  const [furthest, setFurthest] = useState<{ id?: string; index: number }>({ index: 0 });
  useEffect(() => {
    const candidate = Math.max(draftFloorIndex, stepToIndex(currentStep));
    setFurthest((prev) =>
      prev.id === sessionId
        ? candidate > prev.index
          ? { id: sessionId, index: candidate }
          : prev
        : { id: sessionId, index: candidate }
    );
  }, [sessionId, draftFloorIndex, currentStep]);
  const furthestStepIndex = furthest.id === sessionId ? furthest.index : 0;

  const recordStepReached = useCallback((step: string) => {
    if (!sessionId) return;
    void draftsClient.markStepReached({ sessionId, step }).catch((): void => undefined);
  }, [sessionId, draftsClient]);

  // Show welcome modal only for new sessions
  useEffect(() => {
    if (!isLoading && !sessionId && !searchParams.get("step")) {
      setWelcomeModalOpen(true);
    } else {
      setWelcomeModalOpen(false);
    }
  }, [isLoading, sessionId, searchParams]);

  // Fetch NOFO name
  useEffect(() => {
    if (!selectedNofo) return;
    setIsNofoLoading(true);
    apiClient.landingPage
      .getNOFOSummary(selectedNofo, { forApplication: true })
      .then((result) => setNofoName(result?.data?.GrantName || selectedNofo))
      .catch(() => setNofoName(selectedNofo))
      .finally(() => setIsNofoLoading(false));
  }, [selectedNofo, apiClient]);

  const startNewDocument = useCallback(async (nofo: string) => {
    setStartingDraft(true);
    try {
      const url = await startDraft(nofo);
      setCurrentStep("projectBasics");
      navigate(url);
    } catch (err) {
      console.error("Failed to start new document:", err);
      setError(ERROR_MESSAGES.START_FAILED);
      setStartingDraft(false);
    } finally {
      setGrantPickerOpen(false);
    }
  }, [startDraft, navigate, setError]);

  // The router can commit the new session's URL after the picker closes; until it does,
  // stay on the loading view rather than flash a session-less form.
  useEffect(() => {
    if (sessionId) setStartingDraft(false);
  }, [sessionId]);

  const handleGrantPicked = useCallback(async (grant: PickedGrant) => {
    addToRecentlyViewed(grant);
    await startNewDocument(grant.value);
  }, [startNewDocument]);

  const navigateToSectionEditor = useCallback((jobId: string) => {
    setActiveJobId(jobId);
    setIsGeneratingDraft(true);
    setCurrentStep("sectionEditor");
    recordStepReached("sectionEditor");
    const nofoParam = selectedNofo ? `&grant=${encodeURIComponent(selectedNofo)}` : "";
    navigate(`/document-editor/${sessionId}?step=sectionEditor${nofoParam}`);
  }, [selectedNofo, sessionId, navigate, recordStepReached]);

  const performStepNavigation = useCallback(async (step: string) => {
    const go = () => {
      const nofoParam = selectedNofo ? `&grant=${encodeURIComponent(selectedNofo)}` : "";
      navigate(`/document-editor/${sessionId}?step=${step}${nofoParam}`);
    };

    if (!documentData) {
      go();
      return;
    }
    try {
      // Status only: useDraftSave's own baseline holds the authoritative
      // sections, which documentData does not see once SectionsEditor has run.
      await saveFields(
        { status: stepToStatus(step) },
        { source: "status_change", immediate: true }
      );
      if (step === "reviewApplication") reviewStatusSavedRef.current = sessionId ?? null;
      setCurrentStep(step);
      recordStepReached(step);
      go();
    } catch (err) {
      console.error("Failed to navigate to step:", err);
      setError(ERROR_MESSAGES.SAVE_FAILED);
    }
  }, [documentData, selectedNofo, sessionId, saveFields, navigate, setError, recordStepReached]);

  const navigateToStep = useCallback((step: string) => {
    void performStepNavigation(step);
  }, [performStepNavigation]);

  const handleUpdateData = useCallback((data: Partial<DocumentData>) => {
    setDocumentData((prev) => (prev ? { ...prev, ...data } : prev));
    saveFields({
      ...(data.sections ? { sections: data.sections } : {}),
      ...(data.projectBasics ? { projectBasics: data.projectBasics } : {}),
      ...(data.questionnaire ? { questionnaire: data.questionnaire } : {}),
      status: stepToStatus(currentStep),
    });
  }, [currentStep, saveFields, setDocumentData]);

  const renderCurrentStep = () => {
    switch (currentStep) {
      case "projectBasics":
        return <ProjectBasics onContinue={() => navigateToStep("questionnaire")} documentData={documentData} onUpdateData={handleUpdateData} saveStatus={draftSave.saveStatus} lastSavedAt={draftSave.lastSavedAt} onRetrySave={draftSave.retry} />;
      case "questionnaire":
        return <QuickQuestionnaire onContinue={() => navigateToStep("uploadDocuments")} selectedNofo={selectedNofo} onNavigate={navigateToStep} documentData={documentData} onUpdateData={handleUpdateData} saveStatus={draftSave.saveStatus} lastSavedAt={draftSave.lastSavedAt} onRetrySave={draftSave.retry} />;
      case "uploadDocuments":
        return <UploadDocuments selectedNofo={selectedNofo} onNavigate={navigateToStep} onNavigateToEditor={navigateToSectionEditor} sessionId={sessionId || ""} documentData={documentData} draftSave={draftSave} />;
      case "sectionEditor":
        return <SectionEditor onContinue={() => navigateToStep("reviewApplication")} onBack={() => navigateToStep("uploadDocuments")} selectedNofo={selectedNofo} sessionId={sessionId || ""} activeJobId={activeJobId} isGenerating={isGeneratingDraft} draftSave={draftSave} />;
      case "reviewApplication":
        return <ReviewApplication selectedNofo={selectedNofo} sessionId={sessionId || ""} onNavigate={navigateToStep} />;
      default:
        return <div>Welcome to GrantWell</div>;
    }
  };

  const activeStep = stepToIndex(currentStep);
  // Until the new draft has loaded there is no form to fill in, so the loading view stands in for it.
  const showLoading = isLoading || startingDraft || (!!sessionId && loadedDraft === undefined);
  const waitMessage = startingDraft ? "Starting application..." : loadingMessage;
  const draftsPath = selectedNofo
    ? `/document-editor/drafts?grant=${encodeURIComponent(selectedNofo)}`
    : "/document-editor/drafts";

  // WCAG 2.4.11: the stepper's offset and the page's scroll padding follow the pinned bars' real heights.
  useEffect(() => {
    const root = rootRef.current;
    const header = headerRef.current;
    if (!root || !header) return;
    const stepper = root.querySelector<HTMLElement>(".progress-stepper-container");
    const pinnedHeight = (el: HTMLElement | null) =>
      el && getComputedStyle(el).position === "sticky" ? el.offsetHeight : 0;
    const update = () => {
      root.style.setProperty("--gw-editor-header-height", `${pinnedHeight(header)}px`);
      document.documentElement.style.setProperty(
        "--gw-editor-sticky-height",
        `${pinnedHeight(header) + pinnedHeight(stepper)}px`
      );
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(header);
    if (stepper) observer.observe(stepper);
    // Opening "All steps" unpins both bars without changing their size, which ResizeObserver can't see.
    const unpinObserver = new MutationObserver(update);
    if (stepper) unpinObserver.observe(stepper, { attributes: true, attributeFilter: ["class"] });
    window.addEventListener("resize", update);
    return () => {
      observer.disconnect();
      unpinObserver.disconnect();
      window.removeEventListener("resize", update);
      document.documentElement.style.removeProperty("--gw-editor-sticky-height");
    };
  }, [welcomeModalOpen, grantPickerOpen, error]);

  usePageTitle(notFound ? "Application not found" : null);

  if (notFound) {
    return (
      <PageMessage
        title="Application not found"
        message="This application doesn't exist. It may have been deleted."
        action={{ label: "Go to My applications", to: "/document-editor/drafts" }}
      />
    );
  }

  // Replaces the whole editor, so it takes focus: the control that had it is gone.
  if (error) {
    return (
      <PageMessage
        alert
        focusTitle
        title="Something went wrong"
        message={`${error}. Try again in a moment.`}
        action={{ label: "Try again", onClick: () => window.location.reload() }}
      />
    );
  }

  return (
    <div ref={rootRef} className="document-editor-root" style={{ display: "flex", alignItems: "stretch", flex: "1 0 auto", width: "100%", margin: 0, padding: 0 }}>
      <UnifiedNavigation documentIdentifier={selectedNofo} currentStep={currentStep} furthestStepIndex={furthestStepIndex} onNavigate={navigateToStep} />

      <div className="document-content" style={{ flex: 1, display: "flex", flexDirection: "column", margin: 0, padding: 0 }}>
        {!welcomeModalOpen && !grantPickerOpen && (
          <>
            {/* Not pinned: the stepper below stays pinned, and two pinned bars would cover too much of the page. */}
            <div ref={headerRef} className="document-editor-header">
              <GrantHeader page="Write application" grantName={isNofoLoading ? "Loading…" : nofoName || "Grant"} />
            </div>

            <ProgressStepper
              steps={[...EDITOR_STEPS]}
              activeStep={activeStep}
              isStepClickable={(idx) => {
                const hasSections = documentData?.sections && Object.keys(documentData.sections).length > 0;
                if (idx <= furthestStepIndex) return true;
                if (idx === activeStep + 1) return idx < 3 || !!hasSections;
                return false;
              }}
              onStepClick={(idx) => navigateToStep(EDITOR_STEPS[idx].id)}
              completedSteps={Array.from({ length: furthestStepIndex }, (_, i) => i)}
            />

            <div className="document-editor-workspace" style={{ flex: 1 }}>
              {/* Outlives the loading view, so both the wait and its end are announced. */}
              <LiveStatus className="visually-hidden">
                {isLoading || startingDraft ? waitMessage : documentData ? "Application ready." : ""}
              </LiveStatus>

              {showLoading ? (
                <div id="document-loading-region" aria-busy="true" tabIndex={-1} style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "60vh" }}>
                  <div style={{ textAlign: "center", maxWidth: 400 }}>
                    <div className="loading-spinner" style={{ margin: "0 auto 16px" }} />
                    <p style={{ color: "var(--gw-color-text-secondary)", fontSize: 16, marginBottom: 8 }}>{waitMessage}</p>
                    {loadingMessage.includes("generation") && (
                      <p style={{ color: "var(--gw-color-text-muted)", fontSize: 14, marginTop: 8 }}>This may take 30-60 seconds. Please don&apos;t close this page.</p>
                    )}
                  </div>
                </div>
              ) : (
                renderCurrentStep()
              )}
            </div>
          </>
        )}
      </div>

      <WelcomeModal
        isOpen={welcomeModalOpen}
        onClose={() => {
          // There is no draft behind this modal yet, so closing it leaves the page.
          if (location.key !== "default") navigate(-1);
          else navigate(draftsPath);
        }}
        onGetStarted={() => {
          setWelcomeModalOpen(false);
          if (selectedNofo) startNewDocument(selectedNofo);
          else setGrantPickerOpen(true);
        }}
        onViewDrafts={() => {
          setWelcomeModalOpen(false);
          navigate(draftsPath);
        }}
      />
      <GrantPickerModal
        isOpen={grantPickerOpen}
        onClose={() => {
          setGrantPickerOpen(false);
          setWelcomeModalOpen(true);
        }}
        onSelect={handleGrantPicked}
        title="Start a new application"
        description="Choose the grant you want to apply for."
        busy={startingDraft}
      />
    </div>
  );
};

export default DocumentEditor;
