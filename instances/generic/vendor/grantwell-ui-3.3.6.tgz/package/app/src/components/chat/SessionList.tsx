import React, {
  useState,
  useEffect,
  useContext,
  useCallback,
  useId,
  useMemo,
} from "react";
import { getCurrentUser } from "aws-amplify/auth";
import { ApiClient } from "../../common/api-client/api-client";
import { AppContext } from "../../common/app-context";
import { DateTime } from "luxon";
import { Link, useNavigate } from "react-router";
import { LuPlus, LuTrash, LuRefreshCw, LuCalendar } from "react-icons/lu";
import { DeleteConfirmationModal } from "../common/DeleteConfirmationModal";
import GrantPickerModal, { type PickedGrant } from "../common/GrantPickerModal";
import { addToRecentlyViewed } from "../../common/helpers/recently-viewed-nofos";
import TableScrollRegion from "../ui/TableScrollRegion";
import SortableHeader from "../ui/SortableHeader";
import PaginationControls from "../common/PaginationControls";
import PageHeader from "../common/PageHeader";
import { v4 as uuidv4 } from "uuid";
import { useNotifications } from "../notifications/NotificationManager";
import "../../styles/dashboard.css";
import SkeletonRows from "../ui/SkeletonRows";
import { CardListItem, CardListToolbar } from "../ui/CardList";
import { CARD_LIST_QUERY, useMediaQuery } from "../../hooks/use-media-query";

export interface SessionsProps {
  readonly toolsOpen: boolean;
  readonly documentIdentifier: string | null;
  onSessionSelect?: (sessionId: string) => void;
}

type Session = import("../../common/api-client/sessions-client").SessionListItem;

const CHAT_SORTS = [
  { value: "time_stamp:desc", label: "Newest first" },
  { value: "time_stamp:asc", label: "Oldest first" },
  { value: "title:asc", label: "Title, A to Z" },
  { value: "title:desc", label: "Title, Z to A" },
];

export default function Sessions(props: SessionsProps) {
  const appContext = useContext(AppContext);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedItems, setSelectedItems] = useState<Session[]>([]);
  const [pageSize, setPageSize] = useState(20);
  const [currentPage, setCurrentPage] = useState(1);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showGrantPicker, setShowGrantPicker] = useState(false);
  const [sortField, setSortField] = useState<"title" | "time_stamp">(
    "time_stamp"
  );
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const pageSizeSelectId = useId();
  const navigate = useNavigate();
  const { addNotification } = useNotifications();

  const { documentIdentifier } = props;

  const getSessions = useCallback(async () => {
    if (!appContext) return;

    try {
      const apiClient = new ApiClient(appContext);
      const username = (await getCurrentUser()).username;

      if (username) {
        const result = await apiClient.sessions.getSessions(
          username,
          documentIdentifier,
          true
        );
        setSessions(result);
      }
    } catch (e) {
      console.error("Error fetching sessions:", e);
      setSessions([]);
    }
  }, [appContext, documentIdentifier]);

  useEffect(() => {
    if (!appContext) return;

    const loadSessions = async () => {
      setIsLoading(true);
      await getSessions();
      setIsLoading(false);
    };

    loadSessions();
  }, [appContext, getSessions, props.toolsOpen, documentIdentifier]);


  const deleteSelectedSessions = async () => {
    if (!appContext || selectedItems.length === 0) return;

    try {
      setIsLoading(true);
      const apiClient = new ApiClient(appContext);
      const username = (await getCurrentUser()).username;

      await Promise.all(
        selectedItems.map((session) =>
          apiClient.sessions.deleteSession(session.session_id, username)
        )
      );

      setSelectedItems([]);
      setShowModalDelete(false);
      await getSessions();
    } catch (e) {
      console.error("Error deleting sessions:", e);
      setShowModalDelete(false);
      addNotification(
        "error",
        `Could not delete the selected chat${selectedItems.length > 1 ? "s" : ""}. Please try again.`
      );
      await getSessions();
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedItems(e.target.checked ? paginatedItems : []);
  };

  const setItemSelected = (item: Session, checked: boolean) => {
    if (checked) {
      setSelectedItems((prev) => [...prev, item]);
    } else {
      setSelectedItems((prev) =>
        prev.filter((i) => i.session_id !== item.session_id)
      );
    }
  };

  const handleSelectItem = (
    item: Session,
    e: React.ChangeEvent<HTMLInputElement>
  ) => setItemSelected(item, e.target.checked);

  const chatPath = (item: Session) =>
    `/chat/${item.session_id}${item.document_identifier ? `?grant=${encodeURIComponent(item.document_identifier)}` : ""}`;

  const openChat = (item: Session) => {
    props.onSessionSelect?.(item.session_id);
    navigate(chatPath(item));
  };

  const handleSort = (field: "title" | "time_stamp") => {
    setSortDirection((prev) =>
      sortField === field ? (prev === "asc" ? "desc" : "asc") : "asc"
    );
    setSortField(field);
  };

  const sortedSessions = useMemo(() => {
    return [...sessions].sort((a, b) => {
      const sortMultiplier = sortDirection === "asc" ? 1 : -1;

      if (sortField === "title") {
        return sortMultiplier * a.title.localeCompare(b.title);
      } else {
        return (
          sortMultiplier *
          (new Date(a.time_stamp).getTime() - new Date(b.time_stamp).getTime())
        );
      }
    });
  }, [sessions, sortField, sortDirection]);

  const totalPages = Math.ceil(sortedSessions.length / pageSize);

  const paginatedItems = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    return sortedSessions.slice(startIndex, startIndex + pageSize);
  }, [sortedSessions, currentPage, pageSize]);

  const sortDirectionFor = (field: "title" | "time_stamp") =>
    sortField !== field ? null : sortDirection === "asc" ? "ascending" : "descending";

  const formatSessionTime = (timestamp: string) => {
    return DateTime.fromISO(new Date(timestamp).toISOString()).toLocaleString(
      DateTime.DATETIME_SHORT
    );
  };

  const startChat = (documentIdentifier: string) => {
    navigate(`/chat/${uuidv4()}?grant=${encodeURIComponent(documentIdentifier)}`);
  };

  const newChat = () => {
    if (props.documentIdentifier) {
      startChat(props.documentIdentifier);
    } else {
      setShowGrantPicker(true);
    }
  };

  const asCards = useMediaQuery(CARD_LIST_QUERY);

  const emptyState = (
    <div className="no-data">
      <p>No chats</p>
      <button type="button" className="gw-btn gw-btn--primary" onClick={newChat}>
        <LuPlus size={16} aria-hidden="true" />
        <span>New chat</span>
      </button>
    </div>
  );

  const handleGrantPicked = (grant: PickedGrant) => {
    addToRecentlyViewed(grant);
    setShowGrantPicker(false);
    startChat(grant.value);
  };

  return (
    <div className="dashboard-content">
      <GrantPickerModal
        isOpen={showGrantPicker}
        onClose={() => setShowGrantPicker(false)}
        onSelect={handleGrantPicked}
        title="Start a new chat"
        description="Choose the grant you want to ask about."
      />
      <DeleteConfirmationModal
        isOpen={showModalDelete}
        onClose={() => setShowModalDelete(false)}
        onConfirm={deleteSelectedSessions}
        title={`Delete chat${selectedItems.length > 1 ? "s" : ""}`}
        itemName={selectedItems.length === 1 ? selectedItems[0].title : undefined}
        itemCount={selectedItems.length > 1 ? selectedItems.length : undefined}
        itemLabel="chat"
      />

      <PageHeader
        title="My chats"
        intro="Manage and access your previous chats"
        actions={
          <>
            <button
              className="gw-btn gw-btn--primary action-button add-button"
              onClick={newChat}
            >
              <LuPlus size={16} className="button-icon" aria-hidden="true" />
              <span>New chat</span>
            </button>
            <button
              className="gw-btn gw-btn--danger action-button danger-button"
              onClick={() => selectedItems.length > 0 && setShowModalDelete(true)}
              aria-disabled={selectedItems.length === 0 || undefined}
            >
              <LuTrash size={16} className="button-icon" aria-hidden="true" />
              <span>Delete</span>
            </button>
            <button
              className="gw-btn gw-btn--secondary action-button refresh-button"
              onClick={async () => {
                if (isLoading) return;
                setIsLoading(true);
                await getSessions();
                setIsLoading(false);
              }}
              aria-disabled={isLoading || undefined}
              aria-label={isLoading ? "Refreshing chats list" : "Refresh chats list"}
              aria-busy={isLoading}
            >
              {isLoading ? (
                <span className="refresh-loading">Refreshing...</span>
              ) : (
                <>
                  <LuRefreshCw size={16} className="button-icon refresh-icon" aria-hidden="true" />
                  <span>Refresh</span>
                </>
              )}
            </button>
          </>
        }
      />

      {asCards ? (
        <>
          <CardListToolbar
            selectAll={{
              checked: paginatedItems.length > 0 && selectedItems.length === paginatedItems.length,
              onChange: (checked) => setSelectedItems(checked ? paginatedItems : []),
              label: "Select all chats",
              disabled: isLoading || sortedSessions.length === 0,
            }}
            sort={{
              value: `${sortField}:${sortDirection}`,
              options: CHAT_SORTS,
              onChange: (value) => {
                const [field, direction] = value.split(":") as ["title" | "time_stamp", "asc" | "desc"];
                setSortField(field);
                setSortDirection(direction);
              },
              disabled: isLoading,
            }}
          />
          {isLoading ? (
            <SkeletonRows label="Loading chats" />
          ) : sortedSessions.length === 0 ? (
            emptyState
          ) : (
            <ul className="gw-card-list" aria-label="Chats">
              {paginatedItems.map((item) => (
                <CardListItem
                  key={item.session_id}
                  select={{
                    checked: selectedItems.some((i) => i.session_id === item.session_id),
                    onChange: () => setItemSelected(item, !selectedItems.some((i) => i.session_id === item.session_id)),
                    label: `Select ${item.title}, ${formatSessionTime(item.time_stamp)}`,
                  }}
                  title={
                    <Link
                      to={chatPath(item)}
                      onClick={(e) => {
                        e.preventDefault();
                        openChat(item);
                      }}
                    >
                      {item.title}
                    </Link>
                  }
                  facts={[
                    { label: "Time", value: <time dateTime={item.time_stamp}>{formatSessionTime(item.time_stamp)}</time> },
                  ]}
                />
              ))}
            </ul>
          )}
        </>
      ) : (
      <TableScrollRegion label="Chats table" minWidth={520}>
      <div className="table-container">
        <table className="gw-table" aria-label="Chats">
          <colgroup>
            <col style={{ width: 104 }} />
            <col style={{ width: "71%" }} />
            <col />
          </colgroup>
          <thead>
            <tr>
              <td className="header-cell header-cell--select">
                <label className="gw-select-all">
                  <input
                    type="checkbox"
                    checked={
                      paginatedItems.length > 0 &&
                      selectedItems.length === paginatedItems.length
                    }
                    onChange={handleSelectAll}
                    aria-label="Select all chats"
                    style={{ cursor: "pointer" }}
                    disabled={isLoading || sortedSessions.length === 0}
                  />
                  <span aria-hidden="true">Select all</span>
                </label>
              </td>
              <SortableHeader
                label="Title"
                direction={sortDirectionFor("title")}
                onSort={() => !isLoading && handleSort("title")}
                disabled={isLoading}
              />
              <SortableHeader
                label="Time"
                direction={sortDirectionFor("time_stamp")}
                onSort={() => !isLoading && handleSort("time_stamp")}
                disabled={isLoading}
              />
            </tr>
          </thead>
          {!isLoading && (
            <tbody>
              {sortedSessions.length === 0 ? (
                <tr>
                  <td className="row-cell row-cell--empty" colSpan={3}>
                    {emptyState}
                  </td>
                </tr>
              ) : (
                paginatedItems.map((item) => (
                  <tr key={item.session_id} className="table-row">
                    <td className="row-cell">
                      <input
                        type="checkbox"
                        checked={selectedItems.some(
                          (i) => i.session_id === item.session_id
                        )}
                        onChange={(e) => handleSelectItem(item, e)}
                        aria-label={`Select ${item.title}, ${formatSessionTime(item.time_stamp)}`}
                        style={{ cursor: "pointer" }}
                      />
                    </td>
                    <td className="row-cell">
                      <button
                        onClick={() => openChat(item)}
                        style={{
                          color: "var(--gw-color-primary-hover)",
                          background: "none",
                          border: "none",
                          padding: "4px 2px",
                          cursor: "pointer",
                          textAlign: "left",
                          fontSize: "inherit",
                          textDecoration: "underline",
                        }}
                        aria-label={`${item.title}, ${formatSessionTime(item.time_stamp)}`}
                      >
                        {item.title}
                      </button>
                    </td>
                    <td className="row-cell">
                      <div style={{ display: "flex", alignItems: "center", gap: "8px", color: "var(--gw-color-text-secondary)" }}>
                        <LuCalendar size={16} aria-hidden="true" />
                        <time dateTime={item.time_stamp}>
                          {formatSessionTime(item.time_stamp)}
                        </time>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          )}
        </table>
        {isLoading && <SkeletonRows label="Loading chats" />}
      </div>
      </TableScrollRegion>
      )}

      <div role="status" aria-live="polite" className="visually-hidden">
        {isLoading
          ? "Loading chats"
          : sortedSessions.length === 0
          ? "No chats"
          : `${sortedSessions.length} chat${
              sortedSessions.length === 1 ? "" : "s"
            } loaded`}
      </div>

      {/* Pagination */}
      {!isLoading && sortedSessions.length > 0 && (
        <PaginationControls
          currentPage={currentPage}
          totalPages={totalPages}
          totalItems={sortedSessions.length}
          itemsPerPage={pageSize}
          itemsPerPageOptions={[10, 20, 50]}
          itemLabel="chats"
          selectId={pageSizeSelectId}
          live
          onPageChange={setCurrentPage}
          onItemsPerPageChange={(e) => {
            setPageSize(Number(e.target.value));
            setCurrentPage(1);
          }}
        />
      )}
    </div>
  );
}
