import React, { useCallback, useEffect, useRef, useState } from "react";
import { fetchAuthSession, fetchMFAPreference, signOut } from "aws-amplify/auth";
import { LuShieldCheck } from "react-icons/lu";
import Button from "../ui/Button";
import MfaSetupPanel from "./MfaSetupPanel";
import MfaRecoveryNote from "./MfaRecoveryNote";
import { useFocusTrap } from "../../hooks/use-focus-trap";
import { useBranding } from "../../common/branding";
import { mfaDeadlinePhase } from "../../common/mfa-deadline";
import "../profile-gate/profile-gate.css";
import "../../styles/totp.css";

/**
 * From the deployment's MFA deadline, or always when its pool requires MFA, blocks the app until the user enrolls. Fails open like
 * ProfileGate: the user pool's own MFA requirement is the real enforcement.
 */
export default function MfaGate({ children }: { children: React.ReactNode }) {
  const [phase] = useState(() => mfaDeadlinePhase());
  const [blocked, setBlocked] = useState(false);
  const [email, setEmail] = useState("");
  const [expanded, setExpanded] = useState(false);
  const [backFromSetup, setBackFromSetup] = useState(false);
  const setUpButton = useRef<HTMLButtonElement>(null);
  const dialogRef = useFocusTrap<HTMLDivElement>({ isOpen: blocked });
  const { appName } = useBranding();

  useEffect(() => {
    if (!blocked) return;
    const previous = document.title;
    document.title = `Set up two-step verification – ${appName}`;
    return () => {
      document.title = previous;
    };
  }, [blocked, appName]);

  // Back removes the panel that holds focus.
  useEffect(() => {
    if (!backFromSetup) return;
    setUpButton.current?.focus();
    setBackFromSetup(false);
  }, [backFromSetup]);

  useEffect(() => {
    if (phase !== "after") return;
    let active = true;
    (async () => {
      try {
        const isEnrolled = async () => {
          const pref = await fetchMFAPreference();
          return pref.enabled?.includes("TOTP") || pref.preferred === "TOTP";
        };
        if (await isEnrolled()) return;
        // An enrolled user was blocked once on a session from before the v3.3.5 deploy; a fresh session cleared it.
        const session = await fetchAuthSession({ forceRefresh: true });
        if (!active || (await isEnrolled())) return;
        const claims = session.tokens?.idToken?.payload ?? {};
        setEmail(typeof claims.email === "string" ? claims.email : "");
        setBlocked(true);
      } catch (err) {
        console.error("Could not check MFA status", err);
      }
    })();
    return () => {
      active = false;
    };
  }, [phase]);

  const onSignOut = useCallback(async () => {
    try {
      await signOut();
    } catch (err) {
      console.error("Error signing out:", err);
    } finally {
      window.location.assign("/");
    }
  }, []);

  if (!blocked) return <>{children}</>;

  return (
    <div
      className="profile-gate"
      role="dialog"
      aria-modal="true"
      aria-labelledby="mfa-gate-title"
      ref={dialogRef}
    >
      <div className={`gw-modal profile-gate__panel${expanded ? " profile-gate__panel--wide" : ""}`}>
        <header className="gw-modal__header profile-gate__header">
          <span className="profile-gate__header-icon" aria-hidden="true">
            <LuShieldCheck size={22} />
          </span>
          <h2 className="gw-modal__title profile-gate__title" id="mfa-gate-title">
            Set up two-step verification to continue
          </h2>
        </header>

        <div className="gw-modal__body profile-gate__body">
          <p className="profile-gate__lead">
            GrantWell asks for a code from an authenticator app when you sign in. Set it up to
            keep using GrantWell. It takes about a minute.
          </p>

          {expanded ? (
            <MfaSetupPanel
              email={email}
              onEnrolled={() => setBlocked(false)}
              onCancel={() => {
                setExpanded(false);
                setBackFromSetup(true);
              }}
              cancelLabel="Back"
            />
          ) : (
            <>
              <div className="profile-actions">
                <Button ref={setUpButton} type="button" onClick={() => setExpanded(true)}>
                  Set it up
                </Button>
                <Button type="button" variant="ghost" onClick={onSignOut}>
                  Sign out
                </Button>
              </div>
              <MfaRecoveryNote />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
