import React from "react";
import { LuCheck, LuX, LuRefreshCw, LuUpload, LuTriangleAlert } from "react-icons/lu";

type ReviewSource = "pipeline" | "dlq" | "duplicate" | "quality" | "verification";

interface ReviewActionsProps {
  actionInProgress: string | null;
  hasCorrections: boolean;
  canApprove: boolean;
  status: string;
  source?: ReviewSource;
  /** The admin guidance's reason, e.g. "unverified_items". */
  reason?: string;
  /** Every failing item is the grant's text itself, which couldn't be read. */
  unreadableText?: boolean;
  /** The grant's published version stays live, so rejecting drops only this new version. */
  keepsLive?: boolean;
  onApprove: () => void;
  onReject: () => void;
  onReprocess: () => void;
  onReupload: () => void;
  onNeedsReupload: () => void;
}

/**
 * The single action most likely to resolve a review, given how it failed. The
 * backend already knows this via `source`/`canApprove`; surfacing it as the
 * emphasized primary button spares the admin from deciding among five options.
 */
type RecommendedAction = "approve" | "reupload" | "reject" | "reprocess";

function recommendedAction(
  source: ReviewSource | undefined,
  canApprove: boolean,
  reason: string | undefined,
  unreadableText: boolean
): RecommendedAction {
  if (reason === "unverified_items" && unreadableText) return "reupload";
  // Reprocessing rarely fixes an item the grant doesn't support; the admin's check does.
  if (reason === "unverified_items" && canApprove) return "approve";
  if (source === "duplicate") return "reject";
  if (source === "quality") return "reupload";
  if (source === "dlq" || source === "pipeline") return "reprocess";
  // A content NEEDS_REVIEW: approvable partials → approve, otherwise re-upload.
  return canApprove ? "approve" : "reupload";
}

const ReviewActions: React.FC<ReviewActionsProps> = ({
  actionInProgress,
  hasCorrections,
  canApprove,
  status,
  source,
  reason,
  unreadableText = false,
  keepsLive = false,
  onApprove,
  onReject,
  onReprocess,
  onReupload,
  onNeedsReupload,
}) => {
  const busy = actionInProgress !== null;
  // aria-disabled, not disabled, while an action runs: the button pressed keeps keyboard focus.
  // Accessible names start with the visible (busy) label so SC 2.5.3 holds while an action runs.
  const rejectLabel = actionInProgress === "reject" ? "Rejecting..." : keepsLive ? "Reject new version" : "Reject";
  const rejectPurpose = keepsLive ? "the published version stays live" : "reject this grant";
  const reprocessLabel = actionInProgress === "reprocess" ? "Reprocessing..." : "Reprocess";

  // needs_reupload is a terminal holding state: the only meaningful moves are
  // supplying the new document or abandoning the entry.
  if (status === "needs_reupload") {
    const reuploadDocLabel = actionInProgress === "reupload" ? "Uploading..." : "Re-upload Document";
    return (
      <div className="review-expanded-row__actions">
        <button
          className="gw-btn gw-btn--primary review-btn review-btn--approve review-btn--recommended"
          onClick={() => !busy && onReupload()}
          aria-disabled={busy || undefined}
          aria-label={`${reuploadDocLabel} — upload the correct grant document (recommended)`}
        >
          <LuUpload size={14} aria-hidden="true" />
          {reuploadDocLabel}
        </button>
        <button
          className="gw-btn gw-btn--danger review-btn review-btn--reject"
          onClick={() => !busy && onReject()}
          aria-disabled={busy || undefined}
          aria-label={`${rejectLabel} — ${rejectPurpose}`}
        >
          <LuX size={14} aria-hidden="true" />
          {rejectLabel}
        </button>
      </div>
    );
  }

  const recommended = recommendedAction(source, canApprove, reason, unreadableText);
  // Recommendation is a color-only cue visually, so name it for assistive tech too.
  const rec = (action: RecommendedAction, label: string) =>
    recommended === action ? `${label} (recommended)` : label;

  // Visible text and accessible name share one expression so SC 2.5.3 cannot drift.
  const approveLabel =
    actionInProgress === "approve"
      ? "Publishing..."
      : hasCorrections
        ? "Approve with edits"
        : "Approve as is";

  const approveBtn = canApprove ? (
    <button
      key="approve"
      className={`gw-btn ${recommended && recommended !== "approve" ? "gw-btn--secondary" : "gw-btn--primary"} review-btn review-btn--approve ${recommended === "approve" ? "review-btn--recommended" : ""}`}
      onClick={() => !busy && onApprove()}
      aria-disabled={busy || undefined}
      aria-label={rec("approve", `${approveLabel} — publish this grant`)}
    >
      <LuCheck size={14} aria-hidden="true" />
      {approveLabel}
    </button>
  ) : null;

  const reuploadLabel = actionInProgress === "reupload" ? "Uploading..." : "Re-upload grant document";

  const reuploadBtn = (
    <button
      key="reupload"
      className={`gw-btn ${recommended === "reupload" ? "gw-btn--primary" : "gw-btn--secondary"} review-btn ${recommended === "reupload" ? "review-btn--approve review-btn--recommended" : "review-btn--secondary"}`}
      onClick={() => !busy && onReupload()}
      aria-disabled={busy || undefined}
      aria-label={rec("reupload", `${reuploadLabel} — upload a replacement grant document`)}
    >
      <LuUpload size={14} aria-hidden="true" />
      {reuploadLabel}
    </button>
  );

  const reprocessBtn = (
    <button
      key="reprocess"
      className={`gw-btn ${recommended === "reprocess" ? "gw-btn--primary" : "gw-btn--secondary"} review-btn ${recommended === "reprocess" ? "review-btn--approve review-btn--recommended" : "review-btn--reprocess"}`}
      onClick={() => !busy && onReprocess()}
      aria-disabled={busy || undefined}
      aria-label={rec("reprocess", `${reprocessLabel} — reprocess this grant through the pipeline`)}
    >
      <LuRefreshCw
        size={14}
        className={actionInProgress === "reprocess" ? "refresh-icon" : ""}
        aria-hidden="true"
      />
      {reprocessLabel}
    </button>
  );

  const rejectBtn = (
    <button
      key="reject"
      className={`gw-btn gw-btn--danger review-btn ${recommended === "reject" ? "review-btn--reject review-btn--recommended" : "review-btn--reject"}`}
      onClick={() => !busy && onReject()}
      aria-disabled={busy || undefined}
      aria-label={rec("reject", `${rejectLabel} — ${rejectPurpose}`)}
    >
      <LuX size={14} aria-hidden="true" />
      {rejectLabel}
    </button>
  );

  const needsReuploadLabel = actionInProgress === "needs_reupload" ? "Marking..." : "Needs Re-upload";

  const needsReuploadBtn = (
    <button
      key="needs_reupload"
      className="gw-btn gw-btn--secondary review-btn review-btn--needs-reupload"
      onClick={() => !busy && onNeedsReupload()}
      aria-disabled={busy || undefined}
      aria-label={`${needsReuploadLabel} — mark this grant as needing a new document upload`}
    >
      <LuTriangleAlert size={14} aria-hidden="true" />
      {needsReuploadLabel}
    </button>
  );

  // Order the recommended action first; the rest follow as secondary options.
  const byKey: Record<RecommendedAction, React.ReactNode> = {
    approve: approveBtn,
    reupload: reuploadBtn,
    reprocess: reprocessBtn,
    reject: rejectBtn,
  };
  const rest = (["approve", "reprocess", "reject", "reupload"] as RecommendedAction[])
    .filter((k) => k !== recommended)
    .map((k) => byKey[k]);

  return (
    <div className="review-expanded-row__actions">
      {byKey[recommended]}
      {rest}
      {needsReuploadBtn}
    </div>
  );
};

export default ReviewActions;
