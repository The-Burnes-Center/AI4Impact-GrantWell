import React from "react";
import { LuCircleCheckBig, LuCircleAlert, LuLoader, LuLock } from "react-icons/lu";
import type { ApplicationSection } from "../../../common/helpers/application-sections";
import AddSectionForm from "./AddSectionForm";

type Section = ApplicationSection;

const CONCURRENCY_WINDOW = 5;

interface SectionsSidebarProps {
  sections: Section[];
  activeSection: number;
  setActiveSection: (idx: number) => void;
  /** Keyed by section id. */
  sectionAnswers: { [key: string]: string };
  generating?: boolean;
  completedSectionCount?: number;
  /** Section ids. */
  failedSections?: string[];
  /** Sections the running job writes; all of them unless it is a retry. */
  generationTotal?: number;
  onAddSection?: (name: string) => void;
}

const SectionsSidebar = React.memo(function SectionsSidebar({
  sections,
  activeSection,
  setActiveSection,
  sectionAnswers,
  generating,
  completedSectionCount = 0,
  failedSections = [],
  generationTotal,
  onAddSection,
}: SectionsSidebarProps) {
  const total = generationTotal ?? sections.length;
  const isSectionReady = (section: Section) => {
    return !!sectionAnswers[section.id] || failedSections.includes(section.id);
  };

  // Backend generates sections in a sliding window of CONCURRENCY_WINDOW; anything
  // past it is still queued. Icon and accessible name must both use this test.
  const isActivelyGenerating = (idx: number) =>
    !!generating && idx >= completedSectionCount && idx < completedSectionCount + CONCURRENCY_WINDOW;

  const getStatus = (section: Section, idx: number) => {
    if (sectionAnswers[section.id]) return "completed";
    if (failedSections.includes(section.id)) return "failed";
    if (!generating) return "";
    return isActivelyGenerating(idx) ? "generating" : "pending";
  };

  const getStatusIcon = (section: Section, idx: number) => {
    switch (getStatus(section, idx)) {
      case "completed":
        return <LuCircleCheckBig size={16} className="se-sidebar__check" role="img" aria-label={`${section.name}: completed`} />;
      case "failed":
        return <LuCircleAlert size={16} style={{ color: 'var(--gw-color-danger)' }} role="img" aria-label={`${section.name}: failed`} />;
      case "generating":
        return (
          <LuLoader
            size={16}
            className="se-sidebar__spinner"
            style={{ color: 'var(--gw-color-primary)', animation: 'spin 1s linear infinite' }}
            role="img"
            aria-label={`${section.name}: generating`}
          />
        );
      case "pending":
        return <LuLock size={14} style={{ color: 'var(--gw-color-text-muted)' }} role="img" aria-label={`${section.name}: pending`} />;
      default:
        return null;
    }
  };

  // The running count, not each section's pending -> generating -> completed step: the generator flips
  // several sections at once, and the count matches the visible "n/total generated". Empty until the
  // section list arrives, so the text lands as a mutation on an already-mounted region.
  const overallStatus =
    sections.length === 0
      ? ""
      : generating
        ? `Generating sections: ${completedSectionCount} of ${total} done.`
        : completedSectionCount > 0
          ? `Section generation finished. ${completedSectionCount} of ${total} sections generated.`
          : "";

  return (
    <div className="se-sidebar">
      <div role="status" aria-live="polite" className="visually-hidden">
        {overallStatus}
      </div>
      {/* The running count sits beside the heading, not in it, so the heading text stays put. */}
      <div style={{ display: 'flex', alignItems: 'baseline', flexWrap: 'wrap', marginBottom: 16 }}>
        <h2 className="se-sidebar__title" style={{ margin: 0 }}>
          Sections
        </h2>
        {generating && (
          <span style={{ fontSize: '13px', fontWeight: 400, color: 'var(--gw-color-text-muted)', marginLeft: 8 }}>
            {completedSectionCount}/{total} generated
          </span>
        )}
      </div>
      <div className="se-sidebar__list">
        {sections.map((section, idx) => {
          const locked = generating && !isSectionReady(section);
          const status = getStatus(section, idx);
          return (
            <button
              key={section.id}
              onClick={() => { if (!locked) setActiveSection(idx); }}
              className={`se-sidebar__btn${activeSection === idx ? " se-sidebar__btn--active" : ""}${locked ? " se-sidebar__btn--locked" : ""}`}
              aria-label={`${idx + 1} ${section.name}, section ${idx + 1} of ${sections.length}${status ? `, ${status}` : ""}${locked ? ", not yet available" : ""}`}
              aria-current={activeSection === idx ? "true" : undefined}
              aria-disabled={locked}
              title={locked ? "This section is still being generated" : undefined}
              style={locked ? { cursor: "not-allowed", opacity: 0.55 } : undefined}
            >
              <div className="se-sidebar__number">{idx + 1}</div>
              <span className="se-sidebar__name">{section.name}</span>
              {getStatusIcon(section, idx)}
            </button>
          );
        })}
      </div>
      {onAddSection && (
        <div className="se-sidebar__add">
          <AddSectionForm onAdd={onAddSection} disabled={generating} />
        </div>
      )}
    </div>
  );
});

export default SectionsSidebar;
