import type { FormEvent } from "react";
import { useEffect, useId, useMemo, useRef, useState } from "react";
import { Alert } from "react-bootstrap";
import { useBranding } from "../../common/branding";
import {
  confirmResetPassword,
  confirmSignIn,
  confirmSignUp,
  resendSignUpCode,
  resetPassword,
  signIn,
  signOut,
  signUp,
  updateMFAPreference,
} from "aws-amplify/auth";
import type { SignInOutput } from "aws-amplify/auth";
import SignInStep from "./steps/SignInStep";
import ForgotPasswordStep from "./steps/ForgotPasswordStep";
import ResetPasswordStep from "./steps/ResetPasswordStep";
import NewPasswordStep from "./steps/NewPasswordStep";
import SignUpStep from "./steps/SignUpStep";
import VerifySignUpStep from "./steps/VerifySignUpStep";
import MfaChallengeStep from "./steps/MfaChallengeStep";
import MfaSetupStep from "./steps/MfaSetupStep";
import TurnstileWidget from "./TurnstileWidget";
import { AuthView } from "./auth-types";
import type { AuthErrorContext } from "./auth-utils";
import {
  getAuthErrorCode,
  getEmailValidationError,
  getForgotPasswordValidationError,
  getPasswordRequirements,
  getPasswordValidationError,
  getResetPasswordValidationError,
  getSignInValidationError,
  getSignUpValidationError,
  getTurnstileValidationError,
  getUnsupportedChallengeMessage,
  getVerificationCodeValidationError,
  getVerifySignUpValidationError,
  mapAuthError,
  normalizeEmail,
  turnstileClientMetadata,
} from "./auth-utils";
import "../../styles/auth-panel.css";
import { BrandLogo } from "../common/BrandLogo";
import { TURNSTILE_SITE_KEY } from "./turnstile-config";
import { SINGLE_STATE } from "../../common/instance";
import { readSignUpHandoff } from "../../common/state-sites";

interface AuthPanelProps {
  onAuthenticated: () => void;
  /** Shown above the form until dismissed, e.g. why the user was signed out. */
  notice?: string;
  onNoticeDismiss?: () => void;
  /** 2 on a page that has its own h1. */
  headingLevel?: 1 | 2;
}

interface CardCopy {
  title: string;
  subtitle: string;
}

type AuthErrorField =
  | "email"
  | "password"
  | "confirmPassword"
  | "newPassword"
  | "verificationCode";

function authErrorFields(
  code: string,
  context: AuthErrorContext,
): AuthErrorField[] {
  switch (code) {
    case "NotAuthorizedException":
      return context === "sign-in" ? ["email", "password"] : [];
    case "UserNotFoundException":
      return context === "sign-in" ? ["email", "password"] : ["email"];
    case "UsernameExistsException":
      return ["email"];
    case "CodeMismatchException":
    case "ExpiredCodeException":
    case "EnableSoftwareTokenMFAException":
      return ["verificationCode"];
    case "InvalidPasswordException":
      return context === "reset-password" || context === "new-password"
        ? ["newPassword"]
        : ["password"];
    default:
      return [];
  }
}

function signUpValidationFields(
  email: string,
  password: string,
): AuthErrorField[] {
  if (getEmailValidationError(email)) return ["email"];
  if (getPasswordValidationError(password)) return ["password"];
  return ["confirmPassword"];
}

function resetPasswordValidationFields(
  email: string,
  verificationCode: string,
  newPassword: string,
): AuthErrorField[] {
  if (getEmailValidationError(email)) return [];
  if (getVerificationCodeValidationError(verificationCode)) {
    return ["verificationCode"];
  }
  if (getPasswordValidationError(newPassword)) return ["newPassword"];
  return [];
}

async function signInFresh(
  username: string,
  password: string,
  clientMetadata?: Record<string, string>,
) {
  try {
    return await signIn({ username, password, options: { clientMetadata } });
  } catch (error) {
    if ((error as { name?: string })?.name === "UserAlreadyAuthenticatedException") {
      await signOut();
      return await signIn({ username, password, options: { clientMetadata } });
    }
    throw error;
  }
}

const PENDING_STATE_KEY = "grantwell.pendingSignupState";

/** Cognito ends a sign-in left at a challenge step after the app client's authSessionValidity (core: 15 minutes). */
const CODE_STEP_LIMIT_MS = 15 * 60_000;
/** WCAG 2.2.1: warn with time to spare, and let the user extend as often as they need. */
const CODE_STEP_WARNING_MS = 2 * 60_000;
const CODE_STEP_FINAL_MS = 30_000;
const TIMED_VIEWS: AuthView[] = ["mfa-challenge", "mfa-setup", "new-password-required"];
const TIMED_OUT_MESSAGE = "Your sign-in timed out. Sign in again to continue.";

function clockText(ms: number) {
  const seconds = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
}

function spokenTime(ms: number) {
  if (ms >= 60_000) {
    const minutes = Math.round(ms / 60_000);
    return `${minutes} minute${minutes === 1 ? "" : "s"}`;
  }
  const seconds = Math.max(1, Math.ceil(ms / 1000));
  return `${seconds} second${seconds === 1 ? "" : "s"}`;
}

function extendedMessage(view: AuthView) {
  const minutes = CODE_STEP_LIMIT_MS / 60_000;
  switch (view) {
    case "mfa-setup":
      return `Sign-in extended. You have ${minutes} minutes. A new QR code and setup key are shown: scan the new code, then enter the code your app shows.`;
    case "new-password-required":
      return `Sign-in extended. You have ${minutes} minutes to set your password.`;
    default:
      return `Sign-in extended. You have ${minutes} minutes to enter your code.`;
  }
}

function writePendingSignupState(email: string, state: string) {
  try {
    if (!state) {
      sessionStorage.removeItem(PENDING_STATE_KEY);
      return;
    }
    sessionStorage.setItem(PENDING_STATE_KEY, JSON.stringify({ email, state }));
  } catch {
    // Storage denied (private mode): state falls back to admin assignment.
  }
}

function readPendingSignupState(email: string): string {
  try {
    const raw = sessionStorage.getItem(PENDING_STATE_KEY);
    if (!raw) return "";
    const parsed = JSON.parse(raw);
    return parsed?.email === email ? String(parsed.state || "") : "";
  } catch {
    return "";
  }
}

function clearPendingSignupState() {
  try {
    sessionStorage.removeItem(PENDING_STATE_KEY);
  } catch {
    // Nothing to recover; the value is only a hint for confirmSignUp.
  }
}

export default function AuthPanel({
  onAuthenticated,
  notice: initialNotice,
  onNoticeDismiss,
  headingLevel = 1,
}: AuthPanelProps) {
  const branding = useBranding();
  const [handoff] = useState(() => readSignUpHandoff(window.location.hash));
  const [view, setView] = useState<AuthView>(handoff ? "sign-up" : "sign-in");
  const [email, setEmail] = useState(handoff?.email ?? "");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [signupState, setSignupState] = useState(SINGLE_STATE?.code ?? "");
  const [turnstileToken, setTurnstileToken] = useState("");
  const [turnstileResetKey, setTurnstileResetKey] = useState(0);
  const [stepDeadline, setStepDeadline] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const [timeAnnouncement, setTimeAnnouncement] = useState("");
  const [extendedNote, setExtendedNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [errorFields, setErrorFields] = useState<AuthErrorField[]>([]);
  const [success, setSuccess] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(initialNotice ?? null);
  const [newPasswordPending, setNewPasswordPending] = useState(false);
  const [totpSetup, setTotpSetup] = useState<{ uri: string; secret: string } | null>(
    null,
  );

  const errorId = useId();
  const titleRef = useRef<HTMLHeadingElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const pendingFocus = useRef<(() => void) | null>(null);
  const Heading = headingLevel === 2 ? "h2" : "h1";

  const normalizedEmail = useMemo(() => normalizeEmail(email), [email]);
  const inTimedStep = TIMED_VIEWS.includes(view);

  // Each challenge response starts a new Cognito session, so every timed view gets the full limit.
  useEffect(() => {
    setExtendedNote("");
    setStepDeadline(inTimedStep ? Date.now() + CODE_STEP_LIMIT_MS : null);
  }, [view, inTimedStep]);

  useEffect(() => {
    setTimeAnnouncement("");
    if (stepDeadline === null) return;
    let phase: "warn" | "final" | null = null;
    let interval: number | undefined;
    const tick = () => {
      const time = Date.now();
      setNow(time);
      const left = stepDeadline - time;
      const next = left <= CODE_STEP_FINAL_MS ? "final" : "warn";
      if (next === phase || left <= 0) return;
      phase = next;
      setTimeAnnouncement(
        next === "warn"
          ? `For your security, this sign-in times out in ${spokenTime(left)}. Select Keep signing in to continue.`
          : `This sign-in times out in ${spokenTime(left)}. Select Keep signing in to continue.`,
      );
    };
    const timeout = window.setTimeout(() => {
      tick();
      interval = window.setInterval(tick, 1000);
    }, Math.max(0, stepDeadline - CODE_STEP_WARNING_MS - Date.now()));
    return () => {
      window.clearTimeout(timeout);
      window.clearInterval(interval);
    };
  }, [stepDeadline]);

  const timeLeft = stepDeadline === null ? null : stepDeadline - now;
  const showTimeWarning = inTimedStep && timeLeft !== null && timeLeft <= CODE_STEP_WARNING_MS;
  const timedOut = showTimeWarning && timeLeft <= 0;

  useEffect(() => {
    const focus = pendingFocus.current;
    pendingFocus.current = null;
    focus?.();
  });

  // Every Turnstile token is single-use, so a widget that produced one must be reset before the
  // same form can be submitted again.
  const consumeTurnstileToken = () => {
    setTurnstileToken("");
    setTurnstileResetKey((key) => key + 1);
  };

  const passwordRequirements = useMemo(
    () => getPasswordRequirements(password),
    [password],
  );
  const newPasswordRequirements = useMemo(
    () => getPasswordRequirements(newPassword),
    [newPassword],
  );

  useEffect(() => {
    if (handoff) window.history.replaceState(window.history.state, "", window.location.pathname + window.location.search);
  }, [handoff]);

  // Focus follows a switch between views; on first render it stays where the page put it.
  const shownView = useRef(view);
  useEffect(() => {
    if (shownView.current === view) return;
    shownView.current = view;
    titleRef.current?.focus();
  }, [view]);

  const cardCopy = useMemo<CardCopy>(() => {
    switch (view) {
      case "sign-up":
        return {
          title: "Create account",
          subtitle: "Create a new account to get started.",
        };
      case "forgot-password":
        return {
          title: "Reset password",
          subtitle: "Enter your email and we will send you a verification code.",
        };
      case "reset-password":
        return {
          title: "Enter verification code",
          subtitle:
            "Use the code from your email to set a new password. If you don't see it, check your spam or junk folder.",
        };
      case "verify-sign-up":
        return {
          title: "Verify email",
          subtitle: "Confirm your email to finish creating your account.",
        };
      case "new-password-required":
        return {
          title: "Set new password",
          subtitle: "Create a permanent password to continue into GrantWell.",
        };
      case "mfa-challenge":
        return {
          title: "Two-step verification",
          subtitle: "Enter the code from your authenticator app.",
        };
      case "mfa-setup":
        return {
          title: "Set up two-step verification",
          subtitle: "Set up an authenticator app to finish signing in.",
        };
      default:
        return {
          title: "Sign in",
          subtitle: "Use the email address you created your account with.",
        };
    }
  }, [view]);

  useEffect(() => {
    document.title = `${cardCopy.title} – ${branding.appName}`;
  }, [cardCopy.title, branding.appName]);

  const errorTimer = useRef<number | undefined>(undefined);
  useEffect(() => () => window.clearTimeout(errorTimer.current), []);

  const setStepError = (message: string, fields: AuthErrorField[] = []) => {
    window.clearTimeout(errorTimer.current);
    setErrorFields(fields);
    if (message !== error) {
      setError(message);
      return;
    }
    // The live region only speaks when its text changes, so the same message is cleared first.
    setError(null);
    errorTimer.current = window.setTimeout(() => setError(message), 100);
  };

  const clearError = () => {
    window.clearTimeout(errorTimer.current);
    setError(null);
    setErrorFields([]);
  };

  const fieldErrorId = (field: AuthErrorField) =>
    error && errorFields.includes(field) ? errorId : undefined;

  const clearMessages = () => {
    clearError();
    setSuccess(null);
    setExtendedNote("");
  };

  const resetTransientState = () => {
    setConfirmPassword("");
    setNewPassword("");
    setVerificationCode("");
    setNewPasswordPending(false);
    setTotpSetup(null);
    setShowPassword(false);
  };

  const switchToSignIn = (message?: string) => {
    resetTransientState();
    setPassword("");
    setView("sign-in");
    clearError();
    setSuccess(message ?? null);
  };

  const switchToSignUp = () => {
    resetTransientState();
    setPassword("");
    clearMessages();
    setView("sign-up");
  };

  useEffect(() => {
    if (timedOut && !loading) switchToSignIn(TIMED_OUT_MESSAGE);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timedOut, loading]);

  const focusAfterExtension = (extendedView: AuthView) => {
    if (extendedView === "mfa-challenge") {
      const boxes = Array.from(
        contentRef.current?.querySelectorAll<HTMLInputElement>(".otp-input__box") ?? [],
      );
      (boxes.find((box) => !box.value) ?? boxes[boxes.length - 1])?.focus();
    } else if (extendedView === "new-password-required") {
      document.getElementById("new-password-input")?.focus();
    } else {
      titleRef.current?.focus();
    }
  };

  // Cognito can't lengthen a sign-in in progress, so start a fresh one with the password in hand.
  // A typed code or new password is kept; first-time setup gets a new secret, so its code is cleared.
  const keepSigningIn = async () => {
    if (loading) return;
    const checkError = getTurnstileValidationError(turnstileToken);
    if (checkError) {
      setStepError(checkError);
      return;
    }
    setLoading(true);
    clearMessages();
    try {
      const { nextStep } = await signInFresh(normalizedEmail, password, turnstileClientMetadata(turnstileToken));
      consumeTurnstileToken();
      const nextView = applySignInStep(nextStep, true);
      if (nextView === view) {
        setStepDeadline(Date.now() + CODE_STEP_LIMIT_MS);
        setExtendedNote(extendedMessage(view));
        pendingFocus.current = () => focusAfterExtension(view);
      }
    } catch {
      consumeTurnstileToken();
      switchToSignIn(TIMED_OUT_MESSAGE);
    } finally {
      setLoading(false);
    }
  };

  const applySignInStep = (
    nextStep: SignInOutput["nextStep"],
    extending = false,
  ): AuthView | null => {
    switch (nextStep.signInStep) {
      case "DONE":
        setStepDeadline(null);
        onAuthenticated();
        return null;
      case "CONFIRM_SIGN_IN_WITH_NEW_PASSWORD_REQUIRED":
        setNewPasswordPending(true);
        if (!(extending && view === "new-password-required")) setNewPassword("");
        setView("new-password-required");
        return "new-password-required";
      case "CONFIRM_SIGN_UP":
        setVerificationCode("");
        setView("verify-sign-up");
        setStepError(
          "Your account is not verified yet. Enter your verification code to continue.",
        );
        return "verify-sign-up";
      case "RESET_PASSWORD":
        setView("forgot-password");
        setStepError("You need to reset your password before signing in.");
        return "forgot-password";
      case "CONFIRM_SIGN_IN_WITH_TOTP_CODE":
        if (!(extending && view === "mfa-challenge")) setVerificationCode("");
        setView("mfa-challenge");
        return "mfa-challenge";
      case "CONTINUE_SIGN_IN_WITH_TOTP_SETUP":
        setVerificationCode("");
        setTotpSetup({
          uri: nextStep.totpSetupDetails
            .getSetupUri(branding.appName, normalizedEmail)
            .toString(),
          secret: nextStep.totpSetupDetails.sharedSecret,
        });
        setView("mfa-setup");
        return "mfa-setup";
      default:
        setStepError(getUnsupportedChallengeMessage(nextStep.signInStep));
        return null;
    }
  };

  const handleSignIn = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (loading) return;

    const fieldError = getSignInValidationError(email, password);
    const validationError = fieldError ?? getTurnstileValidationError(turnstileToken);
    if (validationError) {
      setStepError(
        validationError,
        fieldError ? [getEmailValidationError(email) ? "email" : "password"] : [],
      );
      setSuccess(null);
      return;
    }

    setLoading(true);
    clearMessages();

    try {
      const { nextStep } = await signInFresh(
        normalizedEmail,
        password,
        turnstileClientMetadata(turnstileToken),
      );
      consumeTurnstileToken();
      applySignInStep(nextStep);
    } catch (authError) {
      consumeTurnstileToken();
      const code = getAuthErrorCode(authError);
      if (code === "UserNotConfirmedException") {
        setView("verify-sign-up");
      }
      setStepError(
        mapAuthError(authError, "sign-in"),
        authErrorFields(code, "sign-in"),
      );
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (loading) return;

    const validationError = getForgotPasswordValidationError(email);
    if (validationError) {
      setStepError(validationError, ["email"]);
      setSuccess(null);
      return;
    }

    setLoading(true);
    clearMessages();

    try {
      await resetPassword({ username: normalizedEmail });
      setVerificationCode("");
      setNewPassword("");
      setSuccess("Check your email for a verification code to reset your password.");
      setView("reset-password");
    } catch (authError) {
      setStepError(
        mapAuthError(authError, "forgot-password"),
        authErrorFields(getAuthErrorCode(authError), "forgot-password"),
      );
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (loading) return;

    const validationError = getResetPasswordValidationError(
      email,
      verificationCode,
      newPassword,
    );
    if (validationError) {
      setStepError(
        validationError,
        resetPasswordValidationFields(email, verificationCode, newPassword),
      );
      setSuccess(null);
      return;
    }

    setLoading(true);
    clearMessages();

    try {
      await confirmResetPassword({
        username: normalizedEmail,
        confirmationCode: verificationCode.trim(),
        newPassword,
      });
      setNewPassword("");
      setVerificationCode("");
      switchToSignIn(
        "Password reset successful. Any other devices signed in to this account have been signed out. Sign in with your new password.",
      );
    } catch (authError) {
      setStepError(
        mapAuthError(authError, "reset-password"),
        authErrorFields(getAuthErrorCode(authError), "reset-password"),
      );
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (loading) return;

    const fieldError = getSignUpValidationError(email, password, confirmPassword);
    const validationError = fieldError ?? getTurnstileValidationError(turnstileToken);
    if (validationError) {
      setStepError(validationError, fieldError ? signUpValidationFields(email, password) : []);
      setSuccess(null);
      return;
    }

    setLoading(true);
    clearMessages();

    try {
      await signUp({
        username: normalizedEmail,
        password,
        options: {
          userAttributes: { email: normalizedEmail },
          clientMetadata: {
            ...(signupState ? { state: signupState } : {}),
            ...turnstileClientMetadata(turnstileToken),
          },
        },
      });
      consumeTurnstileToken();
      writePendingSignupState(normalizedEmail, signupState);
      setVerificationCode("");
      setSuccess("Verification code sent. Enter it below to finish creating your account.");
      setView("verify-sign-up");
    } catch (authError) {
      consumeTurnstileToken();
      setStepError(
        mapAuthError(authError, "sign-up"),
        authErrorFields(getAuthErrorCode(authError), "sign-up"),
      );
    } finally {
      setLoading(false);
    }
  };

  const handleVerifySignUp = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (loading) return;

    // The token here is for the auto sign-in below, not for confirmSignUp itself — so it is only
    // required when a password is still in hand to sign in with.
    const fieldError = getVerifySignUpValidationError(email, verificationCode);
    const validationError =
      fieldError ?? (password ? getTurnstileValidationError(turnstileToken) : null);
    if (validationError) {
      setStepError(
        validationError,
        fieldError && !getEmailValidationError(email) ? ["verificationCode"] : [],
      );
      setSuccess(null);
      return;
    }

    setLoading(true);
    clearMessages();

    try {
      const pendingState = signupState || readPendingSignupState(normalizedEmail);
      await confirmSignUp({
        username: normalizedEmail,
        confirmationCode: verificationCode.trim(),
        options: {
          clientMetadata: pendingState ? { state: pendingState } : undefined,
        },
      });
      clearPendingSignupState();

      if (!password) {
        switchToSignIn("Email verified. Sign in to continue.");
        return;
      }

      const { nextStep } = await signInFresh(
        normalizedEmail,
        password,
        turnstileClientMetadata(turnstileToken),
      );
      consumeTurnstileToken();
      applySignInStep(nextStep);
    } catch (authError) {
      consumeTurnstileToken();
      setStepError(
        mapAuthError(authError, "verify-sign-up"),
        authErrorFields(getAuthErrorCode(authError), "verify-sign-up"),
      );
    } finally {
      setLoading(false);
    }
  };

  const handleResendSignUpCode = async () => {
    if (loading) return;

    const validationError = getForgotPasswordValidationError(email);
    if (validationError) {
      setStepError(validationError);
      setSuccess(null);
      return;
    }

    setLoading(true);
    clearMessages();

    try {
      await resendSignUpCode({ username: normalizedEmail });
      setSuccess("Verification code resent. Check your email for the latest code.");
    } catch (authError) {
      setStepError(
        mapAuthError(authError, "resend-sign-up"),
        authErrorFields(getAuthErrorCode(authError), "resend-sign-up"),
      );
    } finally {
      setLoading(false);
    }
  };

  const submitChallengeCode = async (
    event: FormEvent<HTMLFormElement>,
    context: AuthErrorContext,
  ) => {
    event.preventDefault();
    if (loading) return;

    const validationError = getVerificationCodeValidationError(
      verificationCode,
      "authentication code",
    );
    if (validationError) {
      setStepError(validationError, ["verificationCode"]);
      setSuccess(null);
      return;
    }

    setLoading(true);
    clearMessages();

    try {
      const { nextStep } = await confirmSignIn({
        challengeResponse: verificationCode.trim(),
      });
      setVerificationCode("");
      if (context === "mfa-setup" && nextStep.signInStep === "DONE") {
        // Verifying the token does not add it to the user's MFA settings, so without this
        // Cognito asks them to enroll again at every sign in.
        try {
          await updateMFAPreference({ totp: "PREFERRED" });
        } catch (preferenceError) {
          console.error("Could not set TOTP as the MFA preference", preferenceError);
        }
      }
      applySignInStep(nextStep);
    } catch (authError) {
      const code = getAuthErrorCode(authError);
      if (code === "SignInException") {
        switchToSignIn(mapAuthError(authError, context));
        return;
      }
      if (code === "CodeMismatchException" || code === "EnableSoftwareTokenMFAException") {
        setVerificationCode("");
      }
      setStepError(
        mapAuthError(authError, context),
        authErrorFields(code, context),
      );
    } finally {
      setLoading(false);
    }
  };

  const handleMfaChallenge = (event: FormEvent<HTMLFormElement>) =>
    submitChallengeCode(event, "mfa");

  const handleMfaSetup = (event: FormEvent<HTMLFormElement>) =>
    submitChallengeCode(event, "mfa-setup");

  const handleNewPasswordRequired = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (loading) return;

    const validationError = getPasswordValidationError(newPassword);
    if (validationError) {
      setStepError(validationError, ["newPassword"]);
      setSuccess(null);
      return;
    }

    if (!newPasswordPending) {
      switchToSignIn("Your password setup session expired. Sign in again to continue.");
      return;
    }

    setLoading(true);
    clearMessages();

    try {
      const { nextStep } = await confirmSignIn({ challengeResponse: newPassword });
      setNewPasswordPending(false);
      // Keep signing in on the next step re-signs in, and the temporary password no longer works.
      setPassword(newPassword);
      applySignInStep(nextStep);
    } catch (authError) {
      setStepError(
        mapAuthError(authError, "new-password"),
        authErrorFields(getAuthErrorCode(authError), "new-password"),
      );
    } finally {
      setLoading(false);
    }
  };

  const turnstileSlot = (action: string, className?: string) =>
    TURNSTILE_SITE_KEY ? (
      <TurnstileWidget
        action={action}
        onToken={setTurnstileToken}
        resetKey={turnstileResetKey}
        className={className}
      />
    ) : null;

  const renderStep = () => {
    switch (view) {
      case "sign-up":
        return (
          <SignUpStep
            email={email}
            password={password}
            confirmPassword={confirmPassword}
            showPassword={showPassword}
            stateCode={signupState}
            loading={loading}
            passwordRequirements={passwordRequirements}
            onEmailChange={setEmail}
            onPasswordChange={setPassword}
            onConfirmPasswordChange={setConfirmPassword}
            onShowPasswordChange={setShowPassword}
            onStateChange={setSignupState}
            onSubmit={handleSignUp}
            onSwitchToSignIn={() => switchToSignIn()}
            turnstile={turnstileSlot("sign-up")}
            emailErrorId={fieldErrorId("email")}
            passwordErrorId={fieldErrorId("password")}
            confirmPasswordErrorId={fieldErrorId("confirmPassword")}
          />
        );
      case "forgot-password":
        return (
          <ForgotPasswordStep
            email={email}
            loading={loading}
            onEmailChange={setEmail}
            onSubmit={handleForgotPassword}
            onBackToSignIn={() => switchToSignIn()}
            emailErrorId={fieldErrorId("email")}
          />
        );
      case "reset-password":
        return (
          <ResetPasswordStep
            verificationCode={verificationCode}
            newPassword={newPassword}
            showPassword={showPassword}
            loading={loading}
            passwordRequirements={newPasswordRequirements}
            onVerificationCodeChange={setVerificationCode}
            onNewPasswordChange={setNewPassword}
            onShowPasswordChange={setShowPassword}
            onSubmit={handleResetPassword}
            onBackToSignIn={() => switchToSignIn()}
            verificationCodeErrorId={fieldErrorId("verificationCode")}
            newPasswordErrorId={fieldErrorId("newPassword")}
          />
        );
      case "verify-sign-up":
        return (
          <VerifySignUpStep
            email={normalizedEmail}
            verificationCode={verificationCode}
            loading={loading}
            onVerificationCodeChange={setVerificationCode}
            onSubmit={handleVerifySignUp}
            onResendCode={handleResendSignUpCode}
            onBackToSignUp={switchToSignUp}
            verificationCodeErrorId={fieldErrorId("verificationCode")}
            turnstile={password ? turnstileSlot("verify-sign-up") : null}
          />
        );
      case "mfa-challenge":
        return (
          <MfaChallengeStep
            verificationCode={verificationCode}
            loading={loading}
            onVerificationCodeChange={setVerificationCode}
            onSubmit={handleMfaChallenge}
            onCancel={() => switchToSignIn()}
            verificationCodeErrorId={fieldErrorId("verificationCode")}
          />
        );
      case "mfa-setup":
        return (
          <MfaSetupStep
            setupUri={totpSetup?.uri ?? ""}
            secret={totpSetup?.secret ?? ""}
            verificationCode={verificationCode}
            loading={loading}
            onVerificationCodeChange={setVerificationCode}
            onSubmit={handleMfaSetup}
            onCancel={() => switchToSignIn()}
            verificationCodeErrorId={fieldErrorId("verificationCode")}
          />
        );
      case "new-password-required":
        return (
          <NewPasswordStep
            newPassword={newPassword}
            showPassword={showPassword}
            loading={loading}
            passwordRequirements={newPasswordRequirements}
            onNewPasswordChange={setNewPassword}
            onShowPasswordChange={setShowPassword}
            onSubmit={handleNewPasswordRequired}
            onCancel={() => switchToSignIn()}
            newPasswordErrorId={fieldErrorId("newPassword")}
          />
        );
      default:
        return (
          <SignInStep
            email={email}
            password={password}
            showPassword={showPassword}
            loading={loading}
            onEmailChange={setEmail}
            onPasswordChange={setPassword}
            onShowPasswordChange={setShowPassword}
            onForgotPassword={() => {
              clearMessages();
              setVerificationCode("");
              setNewPassword("");
              setShowPassword(false);
              setView("forgot-password");
            }}
            onSubmit={handleSignIn}
            onSwitchToSignUp={switchToSignUp}
            turnstile={turnstileSlot("sign-in")}
            emailErrorId={fieldErrorId("email")}
            passwordErrorId={fieldErrorId("password")}
          />
        );
    }
  };

  const showTabs = view === "sign-in" || view === "sign-up";

  return (
    <div className="auth-login-card">
      <BrandLogo
        className="auth-card-logo"
        src={branding.logo}
        alt={branding.appName}
      />
      {showTabs && (
        <div className="gw-toggle auth-tabs" role="group" aria-label="Authentication mode">
          <button
            type="button"
            aria-pressed={view === "sign-in"}
            className={
              "gw-toggle__option auth-tab" + (view === "sign-in" ? " auth-tab--active" : "")
            }
            onClick={() => switchToSignIn()}
          >
            Sign in
          </button>
          <button
            type="button"
            aria-pressed={view === "sign-up"}
            className={
              "gw-toggle__option auth-tab" + (view === "sign-up" ? " auth-tab--active" : "")
            }
            onClick={switchToSignUp}
          >
            Create account
          </button>
        </div>
      )}
      <div className="auth-card-header">
        <Heading
          id="auth-card-title"
          className="auth-card-title"
          ref={titleRef}
          tabIndex={-1}
        >
          {cardCopy.title}
        </Heading>
        <p className="auth-card-subtitle">{cardCopy.subtitle}</p>
      </div>
      <div className="auth-card-content" ref={contentRef}>
        {/* Always mounted and text-only: a region created together with its text is
            not announced, and keeping the dismiss buttons out of it stops "Close
            alert" being read as part of the message. "Please wait…" announces the busy
            state, which otherwise only changes the button's own text. The Alerts below need
            transition={false} for role={undefined} to reach the div — otherwise
            react-bootstrap's hardcoded role="alert" announces the same text again. The
            signed-out notice stays out: it is there from the first render, so the region
            never spoke it, and it would mask "Please wait…". */}
        <div aria-live="polite" aria-atomic="true" className="visually-hidden">
          {error || success || extendedNote || (loading ? "Please wait…" : "")}
        </div>
        {/* The visible countdown changes every second, so it stays out of any live region;
            this one speaks only when the warning appears and at 30 seconds. */}
        <div role="alert" aria-atomic="true" className="visually-hidden">
          {showTimeWarning ? timeAnnouncement : ""}
        </div>
        {notice ? (
          <Alert
            variant="info"
            dismissible
            onClose={() => {
              setNotice(null);
              onNoticeDismiss?.();
            }}
            className="mb-3"
            transition={false}
            role={undefined}
          >
            {notice}
          </Alert>
        ) : null}
        {error ? (
          <Alert
            variant="danger"
            dismissible
            onClose={clearError}
            className="mb-3"
            transition={false}
            role={undefined}
          >
            <span id={errorId}>{error}</span>
          </Alert>
        ) : null}
        {success ? (
          <Alert
            variant="success"
            dismissible
            onClose={() => setSuccess(null)}
            className="mb-3"
            transition={false}
            role={undefined}
          >
            {success}
          </Alert>
        ) : null}
        {showTimeWarning && (
          <div className="gw-alert gw-alert--warning auth-timeout-warning">
            <p className="auth-timeout-warning__text">
              For your security, this sign-in times out in {clockText(timeLeft)}.
              {view === "mfa-setup" ? " If you keep signing in, scan the new QR code that appears." : ""}
            </p>
            <button
              type="button"
              className="gw-btn gw-btn--secondary gw-btn--slim auth-timeout-warning__button"
              onClick={() => void keepSigningIn()}
              aria-disabled={loading || undefined}
            >
              Keep signing in
            </button>
            {turnstileSlot("sign-in", "auth-timeout-warning__check")}
          </div>
        )}
        {renderStep()}
      </div>
    </div>
  );
}
