import { useCallback, useState, useContext, useRef } from "react";
import { fetchAuthSession } from "aws-amplify/auth";
import { AppContext } from "../common/app-context";

/**
 * Flag to distinguish intentional cancellation (e.g. user selected a NOFO)
 * from an AbortError caused by the timeout.
 */

export interface AISearchResult {
  name: string;
  score: number;
  source: "hybrid" | "category" | "agency";
  reason: string;
}

interface AISearchResponse {
  results: AISearchResult[];
  query: string;
  searchTimeMs: number;
}

const CACHE_MAX_SIZE = 5;
const CACHE_TTL_MS = 5 * 60 * 1000;
// Generous: an AI search under load routinely runs past 15s, and aborting a
// working request is worse for the user than waiting.
const SEARCH_TIMEOUT_MS = 40_000;

interface CacheEntry {
  results: AISearchResult[];
  searchTimeMs: number;
  timestamp: number;
}

export interface UseAIGrantSearchReturn {
  isSearching: boolean;
  error: string | null;
  results: AISearchResult[] | null;
  searchQuery: string | null;
  searchTimeMs: number | null;
  // `committed` marks a deliberate search (Enter / result selection) vs a debounced
  // as-you-type call; only committed searches are logged for analytics server-side.
  search: (query: string, committed?: boolean) => Promise<void>;
  clearResults: () => void;
}

export function useAIGrantSearch(): UseAIGrantSearchReturn {
  const appContext = useContext(AppContext);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<AISearchResult[] | null>(null);
  const [searchQuery, setSearchQuery] = useState<string | null>(null);
  const [searchTimeMs, setSearchTimeMs] = useState<number | null>(null);
  const cacheRef = useRef<Map<string, CacheEntry>>(new Map());
  const abortControllerRef = useRef<AbortController | null>(null);
  const cancelledRef = useRef(false);

  const search = useCallback(
    async (query: string, committed = false) => {
      if (!appContext) {
        setError("Application context not available");
        return;
      }

      if (!query || query.trim().length < 3) {
        return;
      }

      const trimmed = query.trim().toLowerCase();

      // A committed search (Enter/result-click) must reach the server so it gets logged for
      // analytics, even if the same query is already cached from a debounced keystroke. Debounced
      // calls still short-circuit on cache to avoid redundant network requests.
      const cached = cacheRef.current.get(trimmed);
      if (!committed && cached && (Date.now() - cached.timestamp) < CACHE_TTL_MS) {
        setResults(cached.results);
        setSearchTimeMs(cached.searchTimeMs);
        setSearchQuery(query.trim());
        setError(null);
        return;
      }
      if (cached) {
        cacheRef.current.delete(trimmed);
      }

      abortControllerRef.current?.abort();
      const controller = new AbortController();
      abortControllerRef.current = controller;
      cancelledRef.current = false;
      const timeoutId = setTimeout(() => controller.abort(), SEARCH_TIMEOUT_MS);
      const isLatest = () => abortControllerRef.current === controller && !cancelledRef.current;

      setIsSearching(true);
      setError(null);
      setSearchQuery(query.trim());

      try {
        const session = await fetchAuthSession();
        if (!isLatest()) return;
        const idToken = session.tokens?.idToken?.toString();
        if (!idToken) {
          throw new Error("Not signed in");
        }
        const endpoint = appContext.httpEndpoint;

        const response = await fetch(`${endpoint}/ai-grant-search`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${idToken}`,
          },
          body: JSON.stringify({ query: query.trim(), committed }),
          signal: controller.signal,
        });

        if (!isLatest()) return;
        if (!response.ok) {
          throw new Error(`Search failed (${response.status})`);
        }

        const data: AISearchResponse = await response.json();
        if (!isLatest()) return;

        const newResults = data.results || [];
        setResults(newResults);
        setSearchTimeMs(data.searchTimeMs);

        if (cacheRef.current.size >= CACHE_MAX_SIZE) {
          const oldestKey = cacheRef.current.keys().next().value;
          if (oldestKey !== undefined) {
            cacheRef.current.delete(oldestKey);
          }
        }
        cacheRef.current.set(trimmed, {
          results: newResults,
          searchTimeMs: data.searchTimeMs,
          timestamp: Date.now(),
        });
      } catch (err) {
        if (!isLatest()) return;
        let message: string;
        if (err instanceof DOMException && err.name === "AbortError") {
          message = `Search timed out after ${SEARCH_TIMEOUT_MS / 1000} seconds. Press Enter to try again, or try a more specific query.`;
        } else if (err instanceof Error) {
          message = err.message;
        } else {
          message = "Search failed";
        }
        setError(message);
        setResults([]);
      } finally {
        clearTimeout(timeoutId);
        if (abortControllerRef.current === controller) {
          abortControllerRef.current = null;
          if (!cancelledRef.current) setIsSearching(false);
        }
      }
    },
    [appContext]
  );

  const clearResults = useCallback(() => {
    // Abort any in-flight search request
    cancelledRef.current = true;
    abortControllerRef.current?.abort();
    abortControllerRef.current = null;
    setIsSearching(false);
    setResults(null);
    setSearchQuery(null);
    setSearchTimeMs(null);
    setError(null);
  }, []);

  return {
    isSearching,
    error,
    results,
    searchQuery,
    searchTimeMs,
    search,
    clearResults,
  };
}
