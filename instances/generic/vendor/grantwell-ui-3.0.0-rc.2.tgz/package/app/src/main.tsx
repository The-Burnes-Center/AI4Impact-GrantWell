import "regenerator-runtime/runtime";
import React from "react";
import ReactDOM from "react-dom/client";
import AppConfigured from "./components/AppConfigured";
import { StorageHelper } from "./common/helpers/storage-helper";
import "./styles/bootstrap-subset.scss";

const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);

const theme = StorageHelper.getTheme();
StorageHelper.applyTheme(theme);

root.render(
  <React.StrictMode>
    <AppConfigured />
  </React.StrictMode>
);
