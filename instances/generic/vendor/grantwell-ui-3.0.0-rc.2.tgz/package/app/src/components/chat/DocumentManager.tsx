import React, { useState, useContext, useEffect, useCallback, useRef, useId } from "react";
import { useFocusTrap } from "../../hooks/use-focus-trap";
import { ApiClient } from "../../common/api-client/api-client";
import { AppContext } from "../../common/app-context";
import { FileUploader } from "../../common/file-uploader";
import { getCurrentUser } from "aws-amplify/auth";
import { LuX, LuUpload, LuTrash2, LuFileText, LuRefreshCw, LuDownload, LuCheck, LuCircleAlert, LuClock, LuRotateCcw, LuSearch, LuArrowUpDown, LuArrowUp, LuArrowDown } from "react-icons/lu";
import "../../styles/document-manager.css";

const SUPPORTED_EXTENSIONS = [
  ".csv", ".doc", ".docx", ".epub", ".odt", ".pdf", ".ppt", ".pptx",
  ".tsv", ".xlsx", ".eml", ".html", ".json", ".md", ".msg", ".rst",
  ".rtf", ".txt", ".xml",
];

const MIME_TYPES: Record<string, string> = {
  ".pdf": "application/pdf",
  ".doc": "application/msword",
  ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ".xls": "application/vnd.ms-excel",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ".ppt": "application/vnd.ms-powerpoint",
  ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  ".txt": "text/plain",
  ".csv": "text/csv",
  ".html": "text/html",
  ".json": "application/json",
  ".xml": "application/xml",
  ".md": "text/markdown",
  ".rtf": "application/rtf",
  ".epub": "application/epub+zip",
  ".odt": "application/vnd.oasis.opendocument.text",
  ".tsv": "text/tab-separated-values",
  ".eml": "message/rfc822",
  ".msg": "application/vnd.ms-outlook",
};

interface DocumentManagerProps {
  isOpen: boolean;
  onClose: () => void;
  documentIdentifier: string | null;
  onSyncStarted?: () => void;
  onFileCountChange?: (count: number) => void;
}

interface UploadedFile {
  name: string;
  size: number;
  uploadDate: string;
}

type FileUploadStatus = "pending" | "uploading" | "complete" | "failed";

interface FileStatus {
  file: File;
  status: FileUploadStatus;
  progress: number;
  error?: string;
}

export default function DocumentManager({
  isOpen,
  onClose,
  documentIdentifier,
  onSyncStarted,
  onFileCountChange,
}: DocumentManagerProps) {
  const [activeTab, setActiveTab] = useState<"upload" | "view">("upload");
  const [dragActive, setDragActive] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [fileStatuses, setFileStatuses] = useState<Record<string, FileStatus>>({});
  const [uploading, setUploading] = useState(false);
  const [uploadStatusAnnouncement, setUploadStatusAnnouncement] = useState("");
  const [existingFiles, setExistingFiles] = useState<UploadedFile[]>([]);
  const [error, setErrorMessage] = useState<string | null>(null);
  const [errorSeq, setErrorSeq] = useState(0);
  const [errorAnnouncement, setErrorAnnouncement] = useState("");
  const [fileListAnnouncement, setFileListAnnouncement] = useState("");
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [downloadingFile, setDownloadingFile] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [fileToDelete, setFileToDelete] = useState<string | null>(null);
  const [duplicateFiles, setDuplicateFiles] = useState<File[]>([]);
  const [pendingUploadFiles, setPendingUploadFiles] = useState<File[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [searchFilter, setSearchFilter] = useState("");
  const [sortBy, setSortBy] = useState<"name" | "date" | "size">("date");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [selectedForDelete, setSelectedForDelete] = useState<Set<string>>(new Set());
  const [bulkDeleting, setBulkDeleting] = useState(false);

  const appContext = useContext(AppContext);
  const modalRef = useFocusTrap<HTMLDivElement>({ isOpen, onEscape: onClose });
  const titleId = useId();
  const confirmTitleId = useId();
  const duplicateTitleId = useId();
  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  /** The sequence number is what makes a repeat of the *same* error announce
   * again — identical text alone is not a DOM change. */
  const setError = useCallback((message: string | null) => {
    setErrorMessage(message);
    setErrorSeq((seq) => seq + 1);
  }, []);

  useEffect(() => {
    if (!error) {
      setErrorAnnouncement("");
      return;
    }
    setErrorAnnouncement("");
    const timer = setTimeout(() => setErrorAnnouncement(error), 100);
    return () => clearTimeout(timer);
  }, [error, errorSeq]);

  const extractNofoName = (docId: string | null): string => {
    if (!docId) return "";
    return docId.split("/").pop() || docId;
  };

  useEffect(() => {
    const fetchUserId = async () => {
      try {
        const user = await getCurrentUser();
        setUserId(user.username);
      } catch (err) {
        console.error("Error getting user:", err);
        setError("Failed to authenticate user. Please refresh the page.");
      }
    };
    if (isOpen) {
      fetchUserId();
    }
  }, [isOpen, setError]);



  // Auto-dismiss toast
  useEffect(() => {
    if (toastMessage) {
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
      toastTimerRef.current = setTimeout(() => setToastMessage(null), 5000);
    }
    return () => {
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    };
  }, [toastMessage]);

  const fetchExistingFiles = useCallback(async () => {
    if (!appContext || !documentIdentifier || !userId) return;

    setLoadingFiles(true);
    setError(null);

    try {
      const apiClient = new ApiClient(appContext);
      const nofoName = extractNofoName(documentIdentifier);
      const result = await apiClient.userDocuments.getDocuments(userId, nofoName);

      if (result && result.Contents) {
        const files = result.Contents
          .map((item: { Key: string; Size: number; LastModified: string }) => ({
            name: item.Key.split("/").pop() || item.Key,
            size: item.Size,
            uploadDate: item.LastModified,
          }))
          .filter((file: { name: string }) =>
            file.name !== "" && !file.name.endsWith(".metadata.json")
          );

        setExistingFiles(files);
        setFileListAnnouncement(
          files.length === 0
            ? "No files uploaded"
            : `${files.length} file${files.length === 1 ? "" : "s"} listed`
        );
        onFileCountChange?.(files.length);
      } else {
        setExistingFiles([]);
        setFileListAnnouncement("No files uploaded");
        onFileCountChange?.(0);
      }
    } catch (err) {
      console.error("Error fetching existing files:", err);
      setFileListAnnouncement("");
      setError("Failed to load existing files. Please try again.");
    } finally {
      setLoadingFiles(false);
    }
  }, [appContext, documentIdentifier, userId, onFileCountChange, setError]);

  useEffect(() => {
    if (isOpen && activeTab === "view") {
      fetchExistingFiles();
    }
  }, [isOpen, activeTab, fetchExistingFiles]);

  // Pre-fetch existing files when modal opens (needed for duplicate detection)
  useEffect(() => {
    if (isOpen && userId && appContext && documentIdentifier) {
      fetchExistingFiles();
    }
  }, [isOpen, userId, appContext, documentIdentifier, fetchExistingFiles]);

  // Fetch file count on mount (for badge display even when modal is closed)
  useEffect(() => {
    if (userId && appContext && documentIdentifier && onFileCountChange) {
      fetchExistingFiles();
    }
  }, [userId, appContext, documentIdentifier]);

  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(Array.from(e.target.files));
    }
  };

  const handleFiles = (files: File[]) => {
    setError(null);
    const validFiles: File[] = [];

    for (const file of files) {
      const extension = "." + file.name.split(".").pop()?.toLowerCase();
      if (!SUPPORTED_EXTENSIONS.includes(extension)) {
        setError(
          `Unsupported file type: ${extension}. Supported formats: ${SUPPORTED_EXTENSIONS.join(", ")}`
        );
        continue;
      }
      if (file.size > 100 * 1024 * 1024) {
        setError("File size exceeds 100MB limit.");
        continue;
      }
      validFiles.push(file);
    }

    setSelectedFiles((prev) => [...prev, ...validFiles]);
  };

  const removeFile = (index: number) => {
    setSelectedFiles((prev) => {
      const removed = prev[index];
      setFileStatuses((statuses) => {
        const updated = { ...statuses };
        delete updated[removed.name];
        return updated;
      });
      return prev.filter((_, i) => i !== index);
    });
  };

  const startUpload = async () => {
    if (!appContext || !documentIdentifier || !userId || selectedFiles.length === 0) return;

    // Check for duplicates before uploading
    const existingNames = new Set(existingFiles.map((f) => f.name));
    const dupes = selectedFiles.filter((f) => existingNames.has(f.name));

    if (dupes.length > 0) {
      setDuplicateFiles(dupes);
      setPendingUploadFiles(selectedFiles);
      return;
    }

    await executeUpload(selectedFiles);
  };

  const handleDuplicateReplace = async () => {
    setDuplicateFiles([]);
    await executeUpload(pendingUploadFiles);
    setPendingUploadFiles([]);
  };

  const handleDuplicateSkip = async () => {
    const dupeNames = new Set(duplicateFiles.map((f) => f.name));
    const nonDupes = pendingUploadFiles.filter((f) => !dupeNames.has(f.name));
    setDuplicateFiles([]);
    setPendingUploadFiles([]);

    if (nonDupes.length === 0) {
      setError("All selected files already exist. No files to upload.");
      return;
    }

    setSelectedFiles(nonDupes);
    await executeUpload(nonDupes);
  };

  const handleDuplicateCancel = () => {
    setDuplicateFiles([]);
    setPendingUploadFiles([]);
  };

  const executeUpload = async (filesToUpload: File[]) => {
    if (!appContext || !documentIdentifier || !userId) return;

    setUploading(true);
    setError(null);
    setUploadStatusAnnouncement("Uploading files");

    const initialStatuses: Record<string, FileStatus> = {};
    for (const file of filesToUpload) {
      initialStatuses[file.name] = { file, status: "pending", progress: 0 };
    }
    setFileStatuses(initialStatuses);

    const uploader = new FileUploader();
    const apiClient = new ApiClient(appContext);
    const nofoName = extractNofoName(documentIdentifier);
    let completedCount = 0;
    let failedCount = 0;

    for (const file of filesToUpload) {
      setFileStatuses((prev) => ({
        ...prev,
        [file.name]: { ...prev[file.name], status: "uploading", progress: 0 },
      }));

      const fileExt = "." + file.name.split(".").pop()?.toLowerCase();
      const fileType = MIME_TYPES[fileExt] || "application/octet-stream";

      try {
        const uploadUrl = await apiClient.userDocuments.getUploadURL(
          file.name, fileType, userId, nofoName, file.size
        );

        await uploader.upload(file, uploadUrl, fileType, (uploaded: number) => {
          const progress = Math.min(Math.round((uploaded / file.size) * 100), 100);
          setFileStatuses((prev) => ({
            ...prev,
            [file.name]: { ...prev[file.name], progress },
          }));
        });

        setFileStatuses((prev) => ({
          ...prev,
          [file.name]: { ...prev[file.name], status: "complete", progress: 100 },
        }));
        completedCount++;
      } catch (err) {
        console.error(`Error uploading file ${file.name}:`, err);
        setFileStatuses((prev) => ({
          ...prev,
          [file.name]: {
            ...prev[file.name],
            status: "failed",
            error: `Failed to upload ${file.name}`,
          },
        }));
        failedCount++;
      }
    }

    if (completedCount > 0) {
      setUploadStatusAnnouncement(
        `${completedCount} file${completedCount !== 1 ? "s" : ""} uploaded.${failedCount > 0 ? ` ${failedCount} failed.` : " Indexing documents."}`
      );

      onSyncStarted?.();

      const toastMsg = failedCount > 0
        ? `${completedCount} file${completedCount !== 1 ? "s" : ""} uploaded. ${failedCount} failed.`
        : `${completedCount} file${completedCount !== 1 ? "s" : ""} uploaded. Documents will be available in chat shortly.`;
      setToastMessage(toastMsg);
    }

    if (failedCount === 0) {
      setTimeout(() => {
        setSelectedFiles([]);
        setFileStatuses({});
        setUploading(false);
        setActiveTab("view");
        fetchExistingFiles();
        setUploadStatusAnnouncement("");
      }, 1500);
    } else {
      setUploading(false);
      setUploadStatusAnnouncement(`${failedCount} file${failedCount !== 1 ? "s" : ""} failed. Use retry to try again.`);
    }
  };

  const retryFailed = async () => {
    const failedFiles = Object.values(fileStatuses)
      .filter((fs) => fs.status === "failed")
      .map((fs) => fs.file);

    if (failedFiles.length === 0) return;
    await executeUpload(failedFiles);
  };

  const hasFailedFiles = Object.values(fileStatuses).some((fs) => fs.status === "failed");
  const confirmDelete = (fileName: string) => {
    setFileToDelete(fileName);
  };

  const cancelDelete = () => {
    setFileToDelete(null);
  };

  const confirmDialogRef = useFocusTrap<HTMLDivElement>({
    isOpen: !!fileToDelete,
    onEscape: cancelDelete,
    lockScroll: false,
  });
  const duplicateDialogRef = useFocusTrap<HTMLDivElement>({
    isOpen: duplicateFiles.length > 0,
    onEscape: handleDuplicateCancel,
    lockScroll: false,
  });

  const executeDelete = async () => {
    if (!fileToDelete || !appContext || !documentIdentifier || !userId) return;

    const fileName = fileToDelete;
    setFileToDelete(null);

    try {
      const apiClient = new ApiClient(appContext);
      const nofoName = extractNofoName(documentIdentifier);
      await apiClient.userDocuments.deleteFile(userId, nofoName, fileName);
      fetchExistingFiles();
    } catch (err) {
      console.error(`Error deleting file ${fileName}:`, err);
      setError(`Failed to delete ${fileName}. Please try again.`);
    }
  };

  const downloadFile = async (fileName: string) => {
    if (!appContext || !documentIdentifier || !userId) return;

    try {
      setDownloadingFile(fileName);
      setError(null);
      const apiClient = new ApiClient(appContext);
      const nofoName = extractNofoName(documentIdentifier);

      const downloadUrl = await apiClient.userDocuments.getDownloadURL(
        fileName, userId, nofoName
      );

      const link = document.createElement("a");
      link.href = downloadUrl;
      link.setAttribute("download", fileName);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error(`Error downloading file ${fileName}:`, err);
      setError(`Failed to download ${fileName}. Please try again.`);
    } finally {
      setDownloadingFile(null);
    }
  };

  const formatFileSize = (size: number): string => {
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    const opts: Intl.DateTimeFormatOptions = { timeZone: "America/New_York" };
    return date.toLocaleDateString("en-US", opts) + " " + date.toLocaleTimeString("en-US", opts);
  };

  const renderFileStatusIndicator = (fileName: string) => {
    const status = fileStatuses[fileName];
    if (!status) return null;

    switch (status.status) {
      case "pending":
        return (
          <div className="dm-file-status">
            <LuClock size={14} className="dm-file-status-icon dm-icon-pending" aria-hidden="true" />
            <span className="dm-file-status-text">Pending</span>
          </div>
        );
      case "uploading":
        return (
          <div className="dm-file-status">
            <div
              className="dm-file-progress-bar"
              role="progressbar"
              aria-valuenow={status.progress}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label="Upload progress"
            >
              <div className="dm-file-progress-fill" style={{ width: `${status.progress}%` }} />
            </div>
            <span className="dm-file-status-text">{status.progress}%</span>
          </div>
        );
      case "complete":
        return (
          <div className="dm-file-status">
            <LuCheck size={14} className="dm-file-status-icon dm-icon-complete" aria-hidden="true" />
            <span className="dm-file-status-text dm-status-complete">Done</span>
          </div>
        );
      case "failed":
        return (
          <div className="dm-file-status">
            <LuCircleAlert size={14} className="dm-file-status-icon dm-icon-failed" aria-hidden="true" />
            <span className="dm-file-status-text dm-status-failed">Failed</span>
          </div>
        );
    }
  };

  const filteredAndSortedFiles = React.useMemo(() => {
    let files = [...existingFiles];

    if (searchFilter.trim()) {
      const query = searchFilter.toLowerCase();
      files = files.filter((f) => f.name.toLowerCase().includes(query));
    }

    files.sort((a, b) => {
      let cmp = 0;
      if (sortBy === "name") {
        cmp = a.name.localeCompare(b.name);
      } else if (sortBy === "size") {
        cmp = a.size - b.size;
      } else {
        cmp = new Date(a.uploadDate).getTime() - new Date(b.uploadDate).getTime();
      }
      return sortDirection === "asc" ? cmp : -cmp;
    });

    return files;
  }, [existingFiles, searchFilter, sortBy, sortDirection]);

  const allFilteredSelected =
    filteredAndSortedFiles.length > 0 &&
    filteredAndSortedFiles.every((f) => selectedForDelete.has(f.name));

  const toggleSelectFile = (name: string) => {
    setSelectedForDelete((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (allFilteredSelected) {
      setSelectedForDelete(new Set());
    } else {
      setSelectedForDelete(new Set(filteredAndSortedFiles.map((f) => f.name)));
    }
  };

  const handleSortToggle = (field: "name" | "date" | "size") => {
    if (sortBy === field) {
      setSortDirection((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortBy(field);
      setSortDirection(field === "name" ? "asc" : "desc");
    }
  };

  const executeBulkDelete = async () => {
    if (!appContext || !documentIdentifier || !userId || selectedForDelete.size === 0) return;
    setBulkDeleting(true);
    setError(null);

    const apiClient = new ApiClient(appContext);
    const nofoName = extractNofoName(documentIdentifier);
    const names = Array.from(selectedForDelete);
    let failCount = 0;

    for (const fileName of names) {
      try {
        await apiClient.userDocuments.deleteFile(userId, nofoName, fileName);
      } catch {
        failCount++;
      }
    }

    setSelectedForDelete(new Set());
    setBulkDeleting(false);
    fetchExistingFiles();

    if (failCount > 0) {
      setError(`Failed to delete ${failCount} of ${names.length} files.`);
    } else {
      setToastMessage(`${names.length} file${names.length > 1 ? "s" : ""} deleted.`);
    }
  };

  const SortIcon = ({ field }: { field: "name" | "date" | "size" }) => {
    if (sortBy !== field) return <LuArrowUpDown size={12} aria-hidden="true" />;
    return sortDirection === "asc"
      ? <LuArrowUp size={12} aria-hidden="true" />
      : <LuArrowDown size={12} aria-hidden="true" />;
  };

  if (!isOpen) return null;

  return (
    <div
      className="dm-overlay"
      role="presentation"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={modalRef}
        className="dm-container"
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        style={{ position: "relative" }}
      >
        {/* Kept mounted and empty when idle: a live region created at the same
            moment as its text is unreliably announced. */}
        <div role="status" aria-live="polite" className="visually-hidden">
          {toastMessage ?? ""}
        </div>
        <div role="alert" className="visually-hidden">
          {errorAnnouncement}
        </div>
        {toastMessage && (
          <div
            className="dm-toast-container"
            role="presentation"
            onMouseEnter={() => { if (toastTimerRef.current) clearTimeout(toastTimerRef.current); }}
            onMouseLeave={() => { toastTimerRef.current = setTimeout(() => setToastMessage(null), 5000); }}
            onFocus={() => { if (toastTimerRef.current) clearTimeout(toastTimerRef.current); }}
            onBlur={() => { toastTimerRef.current = setTimeout(() => setToastMessage(null), 5000); }}
          >
            <div className="dm-toast">
              <LuCheck size={16} className="dm-toast-icon" aria-hidden="true" />
              <span className="dm-toast-message">{toastMessage}</span>
              <button
                className="dm-toast-close"
                onClick={() => setToastMessage(null)}
                aria-label="Dismiss notification"
              >
                <LuX size={14} aria-hidden="true" />
              </button>
            </div>
          </div>
        )}

        <div className="dm-header">
          <h2 id={titleId} className="dm-title">Document Manager</h2>
          <button className="dm-close-btn" onClick={onClose} aria-label="Close document manager">
            <LuX size={20} />
          </button>
        </div>

        <div
          className="dm-tab-container"
          role="tablist"
          tabIndex={-1}
          aria-label="Document manager tabs"
          onKeyDown={(e) => {
            const tabs = ["upload", "view"] as const;
            const currentIdx = tabs.indexOf(activeTab as typeof tabs[number]);
            if (e.key === "ArrowRight") {
              e.preventDefault();
              const next = tabs[(currentIdx + 1) % tabs.length];
              setActiveTab(next);
              if (next === "view") fetchExistingFiles();
            } else if (e.key === "ArrowLeft") {
              e.preventDefault();
              const prev = tabs[(currentIdx - 1 + tabs.length) % tabs.length];
              setActiveTab(prev);
              if (prev === "view") fetchExistingFiles();
            } else if (e.key === "Home") {
              e.preventDefault();
              setActiveTab(tabs[0]);
            } else if (e.key === "End") {
              e.preventDefault();
              setActiveTab(tabs[tabs.length - 1]);
              if (tabs[tabs.length - 1] === "view") fetchExistingFiles();
            }
          }}
        >
          <button
            className="dm-tab"
            onClick={() => setActiveTab("upload")}
            role="tab"
            tabIndex={activeTab === "upload" ? 0 : -1}
            aria-selected={activeTab === "upload"}
            aria-controls="upload-panel"
            id="upload-tab"
          >
            Upload New Files
          </button>
          <button
            className="dm-tab"
            onClick={() => { setActiveTab("view"); fetchExistingFiles(); }}
            role="tab"
            tabIndex={activeTab === "view" ? 0 : -1}
            aria-selected={activeTab === "view"}
            aria-controls="view-panel"
            id="view-tab"
          >
            View Existing Files
          </button>
        </div>

        <div className="dm-body">
          {activeTab === "upload" ? (
            <div role="tabpanel" aria-labelledby="upload-tab" id="upload-panel">
              <div
                className={`dm-drop-zone${dragActive ? " dm-drag-active" : ""}`}
                role="presentation"
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
              >
                <div
                  className="dm-drop-label"
                  role="button"
                  tabIndex={0}
                  onClick={() => fileInputRef.current?.click()}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      fileInputRef.current?.click();
                    }
                  }}
                >
                  <LuUpload size={40} className="dm-upload-icon" aria-hidden="true" />
                  <p className="dm-drop-text">Drag and drop your files here</p>
                  <p className="dm-browse-text" id="upload-instructions">
                    or <span className="dm-browse-link">browse files</span>
                  </p>
                </div>

                <input
                  ref={fileInputRef}
                  id="dm-file-input"
                  type="file"
                  multiple
                  className="dm-file-input"
                  onChange={handleFileInput}
                  accept={SUPPORTED_EXTENSIONS.join(",")}
                  aria-describedby="upload-instructions"
                />
              </div>

              {error && <div className="dm-error">{error}</div>}

              <div role="status" aria-live="polite" aria-atomic="true" className="sr-only">
                {uploadStatusAnnouncement}
              </div>

              {selectedFiles.length > 0 && (
                <div className="dm-file-list">
                  <p className="dm-file-list-header">
                    Selected Files ({selectedFiles.length})
                  </p>
                  {selectedFiles.map((file, index) => (
                    <div key={`${file.name}-${index}`} className="dm-file-item">
                      <LuFileText size={20} className="dm-file-icon" aria-hidden="true" />
                      <div className="dm-file-details">
                        <p className="dm-file-name">{file.name}</p>
                        <p className="dm-file-size">{formatFileSize(file.size)}</p>
                      </div>
                      {renderFileStatusIndicator(file.name)}
                      {!uploading && (
                        <button
                          className="dm-delete-btn"
                          onClick={() => removeFile(index)}
                          aria-label={`Remove ${file.name} from upload queue`}
                        >
                          <LuTrash2 size={16} aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  ))}

                  <div className="dm-upload-actions">
                    <button
                      className="dm-upload-btn"
                      onClick={startUpload}
                      disabled={uploading || selectedFiles.length === 0}
                      aria-label={
                        uploading
                          ? "Upload in progress"
                          : `Upload Files — ${selectedFiles.length} selected`
                      }
                    >
                      <LuUpload size={16} aria-hidden="true" />
                      {uploading ? "Uploading..." : "Upload Files"}
                    </button>

                    {hasFailedFiles && !uploading && (
                      <button className="dm-retry-btn" onClick={retryFailed}>
                        <LuRotateCcw size={16} aria-hidden="true" />
                        Retry Failed
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="dm-file-list" role="tabpanel" aria-labelledby="view-tab" id="view-panel">
              <div className="dm-file-list-header">
                <p>Current Files</p>
                <button
                  className="dm-refresh-btn"
                  onClick={fetchExistingFiles}
                  disabled={loadingFiles || !isOpen}
                  aria-label="Refresh file list"
                >
                  <LuRefreshCw size={14} />
                  {loadingFiles ? "Loading..." : "Refresh"}
                </button>
              </div>

              {existingFiles.length > 0 && (
                <div className="dm-toolbar">
                  <div className="dm-search-wrapper">
                    <LuSearch size={14} className="dm-search-icon" aria-hidden="true" />
                    <label htmlFor="dm-search-input" className="sr-only">Search files</label>
                    <input
                      id="dm-search-input"
                      type="text"
                      className="dm-search-input"
                      placeholder="Search files..."
                      value={searchFilter}
                      onChange={(e) => setSearchFilter(e.target.value)}
                    />
                  </div>

                  <div className="dm-sort-controls" role="group" aria-label="Sort files">
                    <button
                      className={`dm-sort-btn${sortBy === "name" ? " dm-sort-active" : ""}`}
                      onClick={() => handleSortToggle("name")}
                      aria-label={`Sort by name ${sortBy === "name" ? (sortDirection === "asc" ? "ascending" : "descending") : ""}`}
                    >
                      Name <SortIcon field="name" />
                    </button>
                    <button
                      className={`dm-sort-btn${sortBy === "date" ? " dm-sort-active" : ""}`}
                      onClick={() => handleSortToggle("date")}
                      aria-label={`Sort by date ${sortBy === "date" ? (sortDirection === "asc" ? "ascending" : "descending") : ""}`}
                    >
                      Date <SortIcon field="date" />
                    </button>
                    <button
                      className={`dm-sort-btn${sortBy === "size" ? " dm-sort-active" : ""}`}
                      onClick={() => handleSortToggle("size")}
                      aria-label={`Sort by size ${sortBy === "size" ? (sortDirection === "asc" ? "ascending" : "descending") : ""}`}
                    >
                      Size <SortIcon field="size" />
                    </button>
                  </div>

                  {selectedForDelete.size > 0 && (
                    <button
                      className="dm-bulk-delete-btn"
                      onClick={executeBulkDelete}
                      disabled={bulkDeleting}
                      aria-label={`Delete ${selectedForDelete.size} selected files`}
                    >
                      <LuTrash2 size={14} aria-hidden="true" />
                      {bulkDeleting ? "Deleting..." : `Delete (${selectedForDelete.size})`}
                    </button>
                  )}
                </div>
              )}

              {existingFiles.length > 0 && filteredAndSortedFiles.length > 0 && (
                <div className="dm-select-all-row">
                  <label className="dm-checkbox-label" htmlFor="dm-select-all">
                    <input
                      type="checkbox"
                      id="dm-select-all"
                      className="dm-checkbox"
                      checked={allFilteredSelected}
                      onChange={toggleSelectAll}
                    />
                    Select all ({filteredAndSortedFiles.length})
                  </label>
                </div>
              )}

              <div role="status" aria-live="polite" className="sr-only">
                {loadingFiles ? "Loading files" : fileListAnnouncement}
              </div>

              {loadingFiles ? (
                <div className="dm-loading-container">
                  <div className="dm-spinner" />
                </div>
              ) : existingFiles.length === 0 ? (
                <div className="dm-empty-state">
                  <p>No files have been uploaded yet.</p>
                </div>
              ) : filteredAndSortedFiles.length === 0 ? (
                <div className="dm-empty-state">
                  <p>No files match &ldquo;{searchFilter}&rdquo;</p>
                </div>
              ) : (
                filteredAndSortedFiles.map((file, index) => (
                  <div key={index} className="dm-file-item">
                    <input
                      type="checkbox"
                      className="dm-checkbox"
                      checked={selectedForDelete.has(file.name)}
                      onChange={() => toggleSelectFile(file.name)}
                      aria-label={`Select ${file.name} for deletion`}
                    />
                    <LuFileText size={20} className="dm-file-icon" aria-hidden="true" />
                    <div
                      className="dm-file-details-clickable"
                      onClick={() => downloadFile(file.name)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          downloadFile(file.name);
                        }
                      }}
                      role="button"
                      tabIndex={0}
                      aria-label={`Download ${file.name}`}
                    >
                      <p className="dm-file-name">
                        {file.name}
                        {downloadingFile === file.name && (
                          <span className="dm-download-status">(Preparing download...)</span>
                        )}
                      </p>
                      <p className="dm-file-size">
                        {formatFileSize(file.size)} &bull; Uploaded {formatDate(file.uploadDate)}
                      </p>
                    </div>
                    <button
                      className="dm-download-btn"
                      onClick={() => downloadFile(file.name)}
                      disabled={downloadingFile === file.name}
                      aria-label={`Download ${file.name}`}
                    >
                      {downloadingFile === file.name ? (
                        <div className="dm-download-spinner" />
                      ) : (
                        <LuDownload size={16} />
                      )}
                    </button>
                    <button
                      className="dm-delete-btn"
                      onClick={() => confirmDelete(file.name)}
                      disabled={downloadingFile === file.name}
                      aria-label={`Delete ${file.name}`}
                    >
                      <LuTrash2 size={16} aria-hidden="true" />
                    </button>
                  </div>
                ))
              )}

              {error && <div className="dm-error">{error}</div>}
            </div>
          )}
        </div>

        <div className="dm-footer">
          <button className="dm-footer-close-btn" onClick={onClose} aria-label="Close document manager">
            Close
          </button>
        </div>
      </div>

      {/* Delete confirmation dialog */}
      {fileToDelete && (
        <div
          className="dm-confirm-overlay"
          role="presentation"
          onClick={(e) => {
            if (e.target === e.currentTarget) cancelDelete();
          }}
        >
          <div
            ref={confirmDialogRef}
            className="dm-confirm-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby={confirmTitleId}
            tabIndex={-1}
          >
            <h3 id={confirmTitleId} className="dm-confirm-title">Delete File</h3>
            <p className="dm-confirm-message">
              Are you sure you want to delete <strong>{fileToDelete}</strong>?
              This will remove it from your uploaded documents and it will no
              longer be available in chat.
            </p>
            <div className="dm-confirm-actions">
              <button className="dm-confirm-cancel-btn" onClick={cancelDelete}>
                Cancel
              </button>
              <button className="dm-confirm-delete-btn" onClick={executeDelete}>
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Duplicate file confirmation dialog */}
      {duplicateFiles.length > 0 && (
        <div
          className="dm-confirm-overlay"
          role="presentation"
          onClick={(e) => {
            if (e.target === e.currentTarget) handleDuplicateCancel();
          }}
        >
          <div
            ref={duplicateDialogRef}
            className="dm-confirm-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby={duplicateTitleId}
            tabIndex={-1}
          >
            <h3 id={duplicateTitleId} className="dm-confirm-title">
              {duplicateFiles.length === 1 ? "File Already Exists" : "Files Already Exist"}
            </h3>
            <p className="dm-confirm-message" style={{ wordBreak: "normal" }}>
              The following {duplicateFiles.length === 1 ? "file already exists" : "files already exist"}.
              Would you like to replace {duplicateFiles.length === 1 ? "it" : "them"} or skip?
            </p>
            <ul className="dm-duplicate-list">
              {duplicateFiles.map((file) => (
                <li key={file.name} className="dm-duplicate-item">
                  <LuFileText size={14} aria-hidden="true" />
                  {file.name}
                </li>
              ))}
            </ul>
            <div className="dm-confirm-actions">
              <button className="dm-confirm-cancel-btn" onClick={handleDuplicateCancel}>
                Cancel
              </button>
              <button className="dm-confirm-cancel-btn" onClick={handleDuplicateSkip}>
                Skip Duplicates
              </button>
              <button className="dm-confirm-replace-btn" onClick={handleDuplicateReplace}>
                Replace
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
