import React, {
  Dispatch,
  SetStateAction,
  useContext,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
} from "react";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";
import { getCurrentUser } from "aws-amplify/auth";
import { ApiClient } from "../../common/api-client/api-client";
import TextareaAutosize from "react-textarea-autosize";
import { AppContext } from "../../common/app-context";
import {
  ChatBotHistoryItem,
  ChatBotMessageType,
  ChatInputState,
} from "./types";

import { assembleHistory } from "./utils";

import { Utils } from "../../common/utils";
import { SessionRefreshContext } from "../../common/session-refresh-context";
import { useNotifications } from "../notifications/NotificationManager";
import { useAccessDenied } from "../access-denied/AccessDeniedManager";
import { LuMic, LuMicOff, LuSend, LuCircleAlert, LuSquare } from "react-icons/lu";

// Styles for the components
const styles = {
  inputBorder: {
    border: "2px solid #767676",
    borderRadius: "16px",
    overflow: "hidden",
    backgroundColor: "white",
    display: "flex",
    alignItems: "flex-end",
    width: "100%",
    maxWidth: "800px",
    minWidth: "280px",
    margin: "0 auto",
    boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03)",
    transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
    padding: "8px 12px",
  },
  inputBorderFocused: {
    borderColor: "#23776C",
    boxShadow: "0 0 0 3px rgba(0, 115, 187, 0.1), 0 10px 15px -3px rgba(0, 0, 0, 0.05)",
  },
  micButton: {
    padding: "10px",
    background: "none",
    border: "none",
    cursor: "pointer",
    color: "#6b7280",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    minWidth: "44px",
    minHeight: "44px",
    borderRadius: "12px",
    margin: "0 4px 0 0",
    transition: "all 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
  },
  micActive: {
    color: "#ef4444",
    backgroundColor: "rgba(239, 68, 68, 0.1)",
  },
  micDisabled: {
    color: "#6b7280",
    cursor: "not-allowed",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    minWidth: "44px",
    minHeight: "44px",
    margin: "0 4px 0 0",
  },
  sendButton: {
    padding: "12px",
    background: "linear-gradient(135deg, #23776C 0%, #244140 100%)",
    border: "none",
    cursor: "pointer",
    color: "white",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
    borderRadius: "12px",
    minWidth: "44px",
    minHeight: "44px",
  },
  sendButtonDisabled: {
    background: "#e5e7eb",
    color: "#9ca3af",
    cursor: "not-allowed",
  },
  stopButton: {
    padding: "12px",
    background: "#dc2626",
    border: "none",
    cursor: "pointer",
    color: "white",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
    borderRadius: "12px",
    minWidth: "44px",
    minHeight: "44px",
  },
  timeoutWarning: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    width: "100%",
    maxWidth: "800px",
    minWidth: "280px",
    margin: "0 auto 8px",
    padding: "10px 14px",
    borderRadius: "12px",
    border: "1px solid #b45309",
    background: "#fffbeb",
    color: "#7c2d12",
    fontSize: "14px",
  },
  timeoutExtendButton: {
    marginLeft: "auto",
    padding: "6px 12px",
    minHeight: "32px",
    borderRadius: "8px",
    border: "1px solid #b45309",
    background: "white",
    color: "#7c2d12",
    fontSize: "14px",
    fontWeight: 600,
    cursor: "pointer",
  },
};

// WCAG 2.2.1 — the response deadline must be extendable, so warn with enough of the
// budget left for the user to ask for more time before anything is torn down.
const RESPONSE_WARN_MS = 40000;
const RESPONSE_EXTEND_MS = 20000;

export interface ChatInputPanelProps {
  running: boolean;
  setRunning: Dispatch<SetStateAction<boolean>>;
  session: { id: string; loading: boolean };
  messageHistory: ChatBotHistoryItem[];
  setMessageHistory: (history: ChatBotHistoryItem[]) => void;
  documentIdentifier: string;
  messageAreaRef?: React.RefObject<HTMLDivElement>;
}

export abstract class ChatScrollState {
  static userHasScrolled = false;
  static skipNextScrollEvent = false;
  static skipNextHistoryUpdate = false;
}

function ChatInputPanel(props: ChatInputPanelProps) {
  const appContext = useContext(AppContext);
  const { setNeedsRefresh } = useContext(SessionRefreshContext);
  const [micPermissionDenied, setMicPermissionDenied] = useState(false);
  const { addNotification } = useNotifications();
  const { showAccessDenied } = useAccessDenied();
  
  // Ref for chat input to enable auto-focus
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Active WebSocket — kept in a ref so the Stop button can close it.
  const wsRef = useRef<WebSocket | null>(null);
  const stoppedRef = useRef(false);
  const responseTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const responseWarnRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const extendResponseRef = useRef<(() => void) | null>(null);
  const [responseTimeoutWarning, setResponseTimeoutWarning] = useState(false);
  const [waitStatus, setWaitStatus] = useState("");

  const clearResponseTimeout = () => {
    if (responseTimeoutRef.current) {
      clearTimeout(responseTimeoutRef.current);
      responseTimeoutRef.current = null;
    }
    if (responseWarnRef.current) {
      clearTimeout(responseWarnRef.current);
      responseWarnRef.current = null;
    }
    extendResponseRef.current = null;
    setResponseTimeoutWarning(false);
    setWaitStatus("");
  };

  /** The warning — and the button carrying focus — unmounts on extend, so
   * confirm the extension and re-home focus instead of dropping it on <body>. */
  const handleKeepWaiting = () => {
    if (!extendResponseRef.current) return;
    extendResponseRef.current();
    setWaitStatus("Still waiting for the assistant");
    inputRef.current?.focus();
  };

  // Enhanced speech recognition config
  const {
    transcript,
    listening,
    browserSupportsSpeechRecognition,
  } = useSpeechRecognition({
    clearTranscriptOnListen: true,
    commands: [],
  });

  const [state, setState] = useState<ChatInputState>({
    value: "",
  });
  const messageHistoryRef = useRef<ChatBotHistoryItem[]>([]);
  const [isHovered, setIsHovered] = useState(false);
  const [micHovered, setMicHovered] = useState(false);
  const [isInputFocused, setIsInputFocused] = useState(false);

  // Handle microphone permission check with enhanced error handling
  const handleMicrophoneToggle = async () => {
    if (listening) {
      SpeechRecognition.stopListening();
      return;
    }

    try {
      // Request microphone permission explicitly
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((track) => track.stop()); // Stop the tracks after permission check

      // Start listening with enhanced settings. No app-imposed time limit
      // (WCAG 2.2.1): the user stops recording with the same toggle button.
      await SpeechRecognition.startListening({
        continuous: true,
        language: "en-US",
      });

      setMicPermissionDenied(false);
    } catch (error) {
      console.error("Microphone permission error:", error);
      setMicPermissionDenied(true);
      addNotification(
        "error",
        "Microphone access denied. Please enable microphone access in your browser settings."
      );
    }
  };

  useEffect(() => {
    messageHistoryRef.current = props.messageHistory;
  }, [props.messageHistory]);

  // Auto-focus chat input on component mount for keyboard accessibility
  useEffect(() => {
    // Small delay to ensure component is fully rendered
    const timer = setTimeout(() => {
      inputRef.current?.focus();
    }, 300);
    
    return () => clearTimeout(timer);
  }, []);

  /** Speech recognition */
  useEffect(() => {
    if (transcript) {
      setState((state) => ({ ...state, value: transcript }));
    }
  }, [transcript]);

  // Stop listening when the component unmounts
  useEffect(() => {
    return () => {
      if (listening) {
        SpeechRecognition.stopListening();
      }
    };
  }, [listening]);

  useEffect(() => {
    return () => {
      clearResponseTimeout();
    };
  }, []);

  useEffect(() => {
    const messageArea = props.messageAreaRef?.current;
    if (!messageArea) return;

    const onMessageAreaScroll = () => {
      if (ChatScrollState.skipNextScrollEvent) {
        ChatScrollState.skipNextScrollEvent = false;
        return;
      }

      const isScrollToTheEnd =
        Math.abs(
          messageArea.scrollHeight -
            messageArea.scrollTop -
            messageArea.clientHeight
        ) <= 10;

      if (!isScrollToTheEnd) {
        ChatScrollState.userHasScrolled = true;
      } else {
        ChatScrollState.userHasScrolled = false;
      }
    };

    messageArea.addEventListener("scroll", onMessageAreaScroll);

    return () => {
      messageArea.removeEventListener("scroll", onMessageAreaScroll);
    };
  }, [props.messageAreaRef]);

  useLayoutEffect(() => {
    if (ChatScrollState.skipNextHistoryUpdate) {
      ChatScrollState.skipNextHistoryUpdate = false;
      return;
    }

    const messageArea = props.messageAreaRef?.current;
    if (!messageArea) return;

    if (!ChatScrollState.userHasScrolled && props.messageHistory.length > 0) {
      ChatScrollState.skipNextScrollEvent = true;
      // Scroll to bottom of message area with smooth behavior
      messageArea.scrollTo({
        top: messageArea.scrollHeight,
        behavior: "smooth",
      });
    }
  }, [props.messageHistory, props.messageAreaRef]);

  const handleStopGeneration = async () => {
    stoppedRef.current = true;
    clearResponseTimeout();
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch (e) {
        console.warn("Error closing WebSocket on stop:", e);
      }
      wsRef.current = null;
    }
    props.setRunning(false);

    const history = messageHistoryRef.current;
    const last = history[history.length - 1];
    const prev = history[history.length - 2];

    if (last?.type !== ChatBotMessageType.AI) return;

    if (last.content.length === 0) {
      messageHistoryRef.current = history.slice(0, -1);
      props.setMessageHistory(messageHistoryRef.current);
      return;
    }

    if (prev?.type !== ChatBotMessageType.Human) return;

    const stoppedMetadata = { ...last.metadata, stopped: true };
    messageHistoryRef.current = [
      ...history.slice(0, -1),
      { ...last, metadata: stoppedMetadata },
    ];
    props.setMessageHistory(messageHistoryRef.current);

    try {
      const username = (await getCurrentUser()).username;
      if (!username) return;
      const apiClient = new ApiClient(appContext);
      await apiClient.sessions.appendChatEntry({
        sessionId: props.session.id,
        userId: username,
        documentIdentifier: props.documentIdentifier,
        entry: {
          user: prev.content,
          chatbot: last.content,
          metadata: JSON.stringify(stoppedMetadata),
        },
      });
    } catch (e) {
      console.warn("Failed to persist stopped response:", e);
    }
  };

  /**Sends a message to the chat API */
  const handleSendMessage = async () => {
    if (!props.documentIdentifier) {
      addNotification(
        "error",
        "No Document selected. Please select a document to proceed."
      );
      return;
    }
    if (props.running) return;
    ChatScrollState.userHasScrolled = false;

    let username: string | undefined;
    await getCurrentUser().then(
      (value: any) => {
        username = value.username;
      }
    );
    if (!username) return;

    const messageToSend = state.value.trim();
    if (messageToSend.length === 0) {
      addNotification("error", "Please do not submit blank text!");
      return;
    }
    setState({ value: "" });

    try {
      props.setRunning(true);
      let receivedData = "";

      let newChatEntry = [];

      const isFirstMessage = messageHistoryRef.current.length === 1;

      if (isFirstMessage) {
        newChatEntry = [
          messageHistoryRef.current[0],
          {
            type: ChatBotMessageType.Human,
            content: messageToSend,
            metadata: {},
          },
        ];
      } else {
        newChatEntry = [
          {
            type: ChatBotMessageType.Human,
            content: messageToSend,
            metadata: {},
          },
        ];
      }

      /**Add the user's query to the message history and a blank dummy message
       * for the chatbot as the response loads
       */
      const pendingAssistantTurn: ChatBotHistoryItem = {
        type: ChatBotMessageType.AI,
        content: receivedData,
        metadata: {},
      };

      messageHistoryRef.current = [
        ...messageHistoryRef.current,
        ...newChatEntry.slice(isFirstMessage ? 1 : 0),
        pendingAssistantTurn,
      ];
      props.setMessageHistory(messageHistoryRef.current);

      let firstTime = false;
      if (messageHistoryRef.current.length < 3) {
        firstTime = true;
      }

      const TEST_URL = appContext.wsEndpoint + "/";

      // Get a JWT token for the API to authenticate on
      const TOKEN = await Utils.authenticate();

      const wsUrl = TEST_URL + "?Authorization=" + TOKEN;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;
      stoppedRef.current = false;

      let incomingMetadata: boolean = false;
      let sources: Record<string, Array<{ title: string; uri: string }>> = {};

      /**If there is no response in time, warn first and only time out if the user
       * declines to extend. Any incoming chunk clears both timers. */
      const armResponseTimeout = () => {
        responseWarnRef.current = setTimeout(() => {
          responseWarnRef.current = null;
          if (receivedData != "") return;
          setResponseTimeoutWarning(true);
          // Clear so a second "Keep waiting" is a real text change and re-announces.
          setWaitStatus("");

          responseTimeoutRef.current = setTimeout(() => {
            responseTimeoutRef.current = null;
            extendResponseRef.current = null;
            setResponseTimeoutWarning(false);
            if (receivedData != "") return;
            ws.close();
            const history = messageHistoryRef.current;
            if (history[history.length - 1] !== pendingAssistantTurn) return;
            messageHistoryRef.current = [
              ...history.slice(0, -1),
              {
                type: ChatBotMessageType.AI,
                content: "Response timed out!",
                // Read by Chat's status region so the timeout is still spoken
                // now that the transcript is no longer a live region.
                metadata: { timedOut: true },
              },
            ];
            props.setMessageHistory(messageHistoryRef.current);
            props.setRunning(false);
          }, RESPONSE_EXTEND_MS);
        }, RESPONSE_WARN_MS);
      };

      clearResponseTimeout();
      extendResponseRef.current = () => {
        if (responseTimeoutRef.current) {
          clearTimeout(responseTimeoutRef.current);
          responseTimeoutRef.current = null;
        }
        setResponseTimeoutWarning(false);
        armResponseTimeout();
      };
      armResponseTimeout();

      // Event listener for when the connection is open
      ws.addEventListener("open", function open() {
        const message = JSON.stringify({
          action: "getChatbotResponse",
          data: {
            userMessage: messageToSend,
            chatHistory: assembleHistory(
              messageHistoryRef.current.slice(0, -2)
            ),
            projectId: "apck1608",
            user_id: username,
            session_id: props.session.id,
            documentIdentifier: props.documentIdentifier,
          },
        });

        ws.send(message);
      });
      // Event listener for incoming messages
      ws.addEventListener("message", async function incoming(data) {
        clearResponseTimeout();
        if (stoppedRef.current) return;
        if (typeof data.data === "string" && data.data.startsWith("<!ACCESS_DENIED!>")) {
          try {
            const json = JSON.parse(data.data.slice("<!ACCESS_DENIED!>".length));
            showAccessDenied({
              message: json.message,
              userState: json.userState,
              nofoState: json.nofoState,
              cta: json.cta,
            });
          } catch (e) {
            addNotification("error", "Access denied for this grant.");
          }
          props.setRunning(false);
          ws.close();
          return;
        }
        /**This is a custom tag from the API that denotes that an error occured
         * and the next chunk will be an error message. */
        if (data.data.includes("<!ERROR!>:")) {
          addNotification("error", data.data);
          ws.close();
          return;
        }
        /**This is a custom tag from the API that denotes when the model response
         * ends and when the sources are coming in
         */
        if (data.data == "!<|EOF_STREAM|>!") {
          incomingMetadata = true;
          return;
        }
        if (!incomingMetadata) {
          receivedData += data.data;
        } else {
          const parsed: Array<{ title: string; uri: string }> = JSON.parse(data.data);
          const sourceData = parsed.map((item: { title: string; uri: string }) => {
            if (item.title == "") {
              return {
                title: item.uri.slice(
                  item.uri.lastIndexOf("/") + 1
                ),
                uri: item.uri,
              };
            } else {
              return item;
            }
          });
          sources = { Sources: sourceData };
        }

        // Update the chat history state with the new message
        messageHistoryRef.current = [
          ...messageHistoryRef.current.slice(0, -2),

          {
            type: ChatBotMessageType.Human,
            content: messageToSend,
            metadata: {},
          },
          {
            type: ChatBotMessageType.AI,
            content: receivedData,
            metadata: sources,
          },
        ];
        props.setMessageHistory(messageHistoryRef.current);
      });
      // Handle possible errors
      ws.addEventListener("error", function error(err) {
        console.error("WebSocket error:", err);
      });
      // Handle WebSocket closure
      ws.addEventListener("close", async function close() {
        const isActiveSocket = wsRef.current === ws;
        if (isActiveSocket) wsRef.current = null;
        if (firstTime) {
          Utils.delay(1500).then(() => setNeedsRefresh(true));
        }
        if (!isActiveSocket) return;
        clearResponseTimeout();
        props.setRunning(false);

        // Ensure final scroll to bottom after message is complete
        // Small delay to ensure DOM has updated with final content
        setTimeout(() => {
          const messageArea = props.messageAreaRef?.current;
          if (messageArea && !ChatScrollState.userHasScrolled) {
            ChatScrollState.skipNextScrollEvent = true;
            messageArea.scrollTo({
              top: messageArea.scrollHeight,
              behavior: "smooth",
            });
          }
        }, 150);
      });
    } catch (error) {
      console.error("Error sending message:", error);
      addNotification(
        "error",
        "Sorry, something went wrong sending your message. Please try again or refresh the page."
      );
      props.setRunning(false);
    }
  };

  return (
    <>
      <div role="status" aria-live="polite" className="visually-hidden">
        {waitStatus}
      </div>
      {responseTimeoutWarning && (
        <div style={styles.timeoutWarning}>
          <LuCircleAlert size={18} aria-hidden="true" />
          {/* Only the message is live — the button inside it made the alert
              announce "...to respond.Keep waiting". */}
          <span role="alert">
            The assistant is taking longer than usual to respond.
          </span>
          <button
            type="button"
            style={styles.timeoutExtendButton}
            onClick={handleKeepWaiting}
            aria-label="Keep waiting for the response"
          >
            Keep waiting
          </button>
        </div>
      )}
      <div
        style={{
          ...styles.inputBorder,
          ...(isInputFocused ? styles.inputBorderFocused : {}),
        }}
      >
      <label htmlFor="chat-input" className="sr-only">
        Message the GrantWell assistant
      </label>
      {/* Microphone button with enhanced feedback */}
      {browserSupportsSpeechRecognition ? (
        <button
          style={{
            ...styles.micButton,
            ...(listening ? styles.micActive : {}),
            ...(micHovered && !listening ? { backgroundColor: "#f3f4f6", color: "#23776C" } : {}),
            ...(micPermissionDenied ? { color: "#ef4444" } : {}),
          }}
          aria-label={
            micPermissionDenied
              ? "Microphone access denied. Click to try again."
              : listening
              ? "Stop voice input"
              : "Start voice input"
          }
          aria-pressed={listening}
          onClick={handleMicrophoneToggle}
          onMouseEnter={() => setMicHovered(true)}
          onMouseLeave={() => setMicHovered(false)}
          title={
            micPermissionDenied
              ? "Microphone access denied. Click to try again."
              : listening
              ? "Click to stop speech recognition"
              : "Click to start speech recognition"
          }
        >
          {micPermissionDenied ? (
            <LuCircleAlert size={20} aria-hidden="true" />
          ) : listening ? (
            <LuMicOff size={20} aria-hidden="true" />
          ) : (
            <LuMic size={20} aria-hidden="true" />
          )}
        </button>
      ) : (
        <span
          style={styles.micDisabled}
          title="Your browser doesn't support speech recognition"
          aria-hidden="true"
        >
          <LuMicOff size={20} />
        </span>
      )}

      {/* Add visual feedback for speech recognition */}
      {listening && (
        <div
          role="status"
          aria-live="polite"
          style={{
            position: "absolute",
            bottom: "100%",
            left: "50%",
            transform: "translateX(-50%)",
            backgroundColor: "#1f2937",
            color: "white",
            padding: "10px 18px",
            borderRadius: "12px",
            fontSize: "14px",
            marginBottom: "12px",
            whiteSpace: "nowrap",
            boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.2), 0 4px 6px -2px rgba(0, 0, 0, 0.1)",
            display: "flex",
            alignItems: "center",
            gap: "8px",
          }}
        >
          <span style={{
            width: "6px",
            height: "6px",
            borderRadius: "50%",
            backgroundColor: "#ef4444",
            animation: "pulse 1.5s ease-in-out infinite",
          }} />
          Listening... Click to stop
        </div>
      )}

      {/* Text input */}
      <TextareaAutosize
        ref={inputRef}
        id="chat-input"
        aria-describedby="chat-input-help"
        style={{
          flex: 1,
          resize: "none",
          padding: "12px 8px",
          border: "none",
          fontFamily: "inherit",
          fontSize: "15px",
          lineHeight: "1.5",
          backgroundColor: "transparent",
          color: "#1f2937",
        }}
        maxRows={5}
        minRows={1}
        spellCheck={true}
        onChange={(e) =>
          setState((state) => ({ ...state, value: e.target.value }))
        }
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
          }
        }}
        onFocus={() => setIsInputFocused(true)}
        onBlur={() => setIsInputFocused(false)}
        value={state.value}
        placeholder="Type your message..."
      />
      <span id="chat-input-help" className="sr-only">
        Press Enter to send, Shift+Enter for new line
      </span>

      {/* Send / Stop button */}
      {props.running ? (
        <button
          style={styles.stopButton}
          onClick={handleStopGeneration}
          aria-label="Stop generating response"
          title="Stop generating"
        >
          <LuSquare size={16} fill="white" />
        </button>
      ) : (
        <button
          style={{
            ...(state.value.trim().length === 0 || props.session.loading
              ? { ...styles.sendButton, ...styles.sendButtonDisabled }
              : {
                  ...styles.sendButton,
                  ...(isHovered
                    ? {
                        transform: "scale(1.05)",
                        boxShadow: "0 4px 12px rgba(0, 115, 187, 0.3)",
                      }
                    : {}),
                }),
          }}
          disabled={state.value.trim().length === 0 || props.session.loading}
          onClick={handleSendMessage}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          aria-label="Send message"
          title="Send message"
        >
          <LuSend size={20} />
        </button>
      )}
      </div>
    </>
  );
}

export default React.memo(ChatInputPanel);
