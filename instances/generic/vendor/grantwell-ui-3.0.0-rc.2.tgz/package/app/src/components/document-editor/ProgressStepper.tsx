import React, { useState } from "react";
import { LuCheck } from "react-icons/lu";

interface ProgressStepperProps {
  steps: Array<{
    id: string;
    label: string;
    description?: string;
    tooltip?: string; // Optional detailed tooltip text
  }>;
  activeStep: number;
  onStepClick?: (stepIndex: number) => void;
  completedSteps?: number[];
  showProgress?: boolean;
  isStepClickable?: (stepIndex: number) => boolean; // Custom function to determine if step is clickable
}

const ProgressStepper: React.FC<ProgressStepperProps> = ({
  steps,
  activeStep,
  onStepClick,
  completedSteps = [],
  showProgress = true,
  isStepClickable: customIsStepClickable,
}) => {
  const [tooltipDismissed, setTooltipDismissed] = useState(false);
  const progressPercentage = ((activeStep + 1) / steps.length) * 100;
  const isStepCompleted = (index: number) => completedSteps.includes(index) || index < activeStep;
  const isStepActive = (index: number) => index === activeStep;
  const isStepClickable = (index: number) => {
    if (!onStepClick) return false;
    if (customIsStepClickable) {
      return customIsStepClickable(index);
    }
    return isStepCompleted(index) || index === activeStep + 1;
  };

  const getTooltipText = (step: typeof steps[0], index: number): string => {
    if (step.tooltip) return step.tooltip;
    
    const status = isStepCompleted(index) 
      ? "Completed" 
      : isStepActive(index) 
      ? "Current step" 
      : index < activeStep 
      ? "Completed" 
      : "Upcoming";
    
    const description = step.description ? ` - ${step.description}` : "";
    return `${step.label}${description}\nStatus: ${status}`;
  };

  return (
    <div
      className="progress-stepper-container"
      style={{
        width: "100%",
        background: "#ffffff",
        borderBottom: "1px solid #e5e7eb",
        padding: "20px 24px",
        position: "sticky",
        top: "62px", // Height of header (16px padding top + 16px padding bottom + ~30px h1 height)
        zIndex: 100,
        boxShadow: "0 1px 3px rgba(0, 0, 0, 0.05)",
      }}
    >
      <style>
        {`
          .step-wrapper {
            z-index: 1;
          }

          .step-wrapper:hover,
          .step-wrapper:focus-within {
            z-index: 10;
          }

          .step-tooltip {
            position: absolute;
            top: calc(100% + 8px);
            left: 50%;
            transform: translateX(-50%);
            padding: 8px 12px;
            background-color: #1f2937;
            color: #ffffff;
            border-radius: 6px;
            font-family: 'Noto Sans', sans-serif;
            font-size: 12px;
            font-weight: 400;
            white-space: pre-line;
            text-align: left;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.2s ease, transform 0.2s ease;
            max-width: 220px;
            min-width: 150px;
            line-height: 1.5;
          }
          .step-wrapper:hover .step-tooltip,
          .step-wrapper:focus-within .step-tooltip,
          .step-tooltip:hover {
            opacity: 1;
            visibility: visible;
          }

          /* WCAG 1.4.13: tooltip is dismissible with Escape */
          .step-tooltip--dismissed {
            opacity: 0 !important;
            visibility: hidden !important;
          }
          
          .step-wrapper:first-child .step-tooltip {
            left: 0;
            transform: translateX(0);
          }
          
          .step-wrapper:last-child .step-tooltip {
            left: 50%;
            right: auto;
            transform: translateX(calc(-50% + 16px)); /* Center on step circle (16px = half circle width) */
            max-width: min(220px, calc(100vw - 32px));
          }
          
          .step-wrapper:last-child:hover .step-tooltip,
          .step-wrapper:last-child:focus-within .step-tooltip {
            transform: translateX(calc(-50% + 16px)) translateY(2px);
          }
          
          .step-tooltip::before {
            content: '';
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            border: 6px solid transparent;
            border-bottom-color: #1f2937;
          }
          
          .step-wrapper:first-child .step-tooltip::before {
            left: 20px;
            transform: translateX(0);
          }
          
          .step-wrapper:last-child .step-tooltip::before {
            left: 50%;
            right: auto;
            transform: translateX(calc(-50% + 16px));
          }
          
          .step-wrapper:hover .step-tooltip,
          .step-wrapper:focus-within .step-tooltip {
            opacity: 1;
            transform: translateX(-50%) translateY(2px);
          }
          
          .step-wrapper:first-child:hover .step-tooltip,
          .step-wrapper:first-child:focus-within .step-tooltip {
            transform: translateX(0) translateY(2px);
          }
          
          
          @media (max-width: 768px) {
            .progress-stepper-container {
              padding: 16px 12px !important;
            }
            .progress-stepper-container .step-label {
              font-size: 13px !important;
            }
            .progress-stepper-container .step-description {
              display: none;
            }
            .progress-stepper-container > div:last-child {
              font-size: 11px !important;
            }
            .step-tooltip {
              display: none; /* Hide tooltips on mobile for better UX */
            }
          }
          @media (max-width: 480px) {
            .progress-stepper-container {
              padding: 12px 8px !important;
            }
            .progress-stepper-container button {
              width: 28px !important;
              height: 28px !important;
              font-size: 12px !important;
            }
            .progress-stepper-container .step-label {
              font-size: 12px !important;
            }
          }
        `}
      </style>
      {/* Steps */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          position: "relative",
          gap: "8px",
        }}
      >
        {/* Connector Lines */}
        {steps.length > 1 && (
          <div
            style={{
              position: "absolute",
              top: "16px",
              left: "16px",
              right: "16px",
              height: "2px",
              // Light enough that the completed fill reads against it at 3.4:1.
              // The circles, not this rail, carry the per-step state.
              backgroundColor: "#c9ced3",
              zIndex: 0,
            }}
          >
            <div
              style={{
                width: steps.length > 1 ? `${(activeStep / (steps.length - 1)) * 100}%` : "0%",
                height: "100%",
                backgroundColor: "#23776C",
                transition: "width 0.3s ease",
              }}
            />
          </div>
        )}

        {steps.map((step, index) => {
          const completed = isStepCompleted(index);
          const active = isStepActive(index);
          const clickable = isStepClickable(index);
          const tooltipText = getTooltipText(step, index);

          return (
            <div
              key={step.id}
              className="step-wrapper"
              style={{
                flex: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                position: "relative",
              }}
            >
              <div
                id={`tooltip-${step.id}`}
                className={`step-tooltip${tooltipDismissed ? " step-tooltip--dismissed" : ""}`}
                role="tooltip"
              >
                {tooltipText}
              </div>

              {/* Step Circle */}
              <button
                onClick={() => clickable && onStepClick?.(index)}
                disabled={!clickable}
                aria-label={`Step ${index + 1}: ${step.label}${active ? " (current)" : ""}${completed ? " (completed)" : ""}`}
                aria-current={active ? "step" : undefined}
                aria-describedby={`tooltip-${step.id}`}
                style={{
                  width: "32px",
                  height: "32px",
                  borderRadius: "50%",
                  border: `2px solid ${completed || active ? "#23776C" : "#6b7280"}`,
                  backgroundColor: completed || active ? "#23776C" : "#ffffff",
                  color: completed || active ? "#ffffff" : "#4b5563",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: clickable ? "pointer" : "default",
                  transition: "all 0.2s ease",
                  fontFamily: "'Noto Sans', sans-serif",
                  fontSize: "14px",
                  fontWeight: 600,
                  padding: 0,
                  marginBottom: "8px",
                }}
                onKeyDown={(e) => { if (e.key === "Escape") setTooltipDismissed(true); }}
                onMouseEnter={(e) => {
                  setTooltipDismissed(false);
                  if (clickable) {
                    e.currentTarget.style.transform = "scale(1.1)";
                    e.currentTarget.style.boxShadow = "0 2px 8px rgba(20, 85, 143, 0.3)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (clickable) {
                    e.currentTarget.style.transform = "scale(1)";
                    e.currentTarget.style.boxShadow = "none";
                  }
                }}
                onFocus={(e) => {
                  setTooltipDismissed(false);
                  if (clickable) {
                    e.currentTarget.style.outline = "2px solid #23776C";
                    e.currentTarget.style.outlineOffset = "2px";
                  }
                }}
                onBlur={(e) => {
                  e.currentTarget.style.outline = "none";
                }}
              >
                {completed ? (
                  <LuCheck size={18} strokeWidth={3} />
                ) : (
                  <span>{index + 1}</span>
                )}
              </button>

              {/* Step Label */}
              <div
                style={{
                  textAlign: "center",
                  maxWidth: "120px",
                  position: "relative",
                }}
              >
                <div
                  style={{
                    fontFamily: "'Noto Sans', sans-serif",
                    fontSize: "15px",
                    fontWeight: active ? 600 : 500,
                    color: active ? "#23776C" : completed ? "#6b7280" : "#4b5563",
                    lineHeight: "1.4",
                    transition: "color 0.2s ease",
                    cursor: "default",
                  }}
                  className="step-label"
                >
                  {step.label}
                </div>
                {step.description && (
                  <div
                    style={{
                      fontFamily: "'Noto Sans', sans-serif",
                      fontSize: "13px",
                      color: "#4b5563",
                      marginTop: "4px",
                      lineHeight: "1.3",
                    }}
                    className="step-description"
                  >
                    {step.description}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {showProgress && (
        <div
          style={{
            textAlign: "center",
            marginTop: "12px",
            fontFamily: "'Noto Sans', sans-serif",
            fontSize: "12px",
            color: "#6b7280",
            fontWeight: 500,
          }}
        >
          {`Application progress: step ${activeStep + 1} of ${steps.length} (${Math.round(progressPercentage)}%)`}
        </div>
      )}
    </div>
  );
};

export default ProgressStepper;
