import React, { useContext, useEffect, useState, useRef } from "react";
import { ChatBotHistoryItem, ChatBotMessageType } from "./types";
import { getCurrentUser } from "aws-amplify/auth";
import { v4 as uuidv4 } from "uuid";
import { AppContext } from "../../common/app-context";
import { ApiClient } from "../../common/api-client/api-client";
import ChatMessage from "./ChatMessage";
import ChatInputPanel from "./ChatInputPanel";
import { useBranding } from "../../common/branding";
import { useNotifications } from "../notifications/NotificationManager";
import { LuCircleHelp, LuChevronDown, LuLoader } from "react-icons/lu";
import { parseChatHistory } from "./utils";

// Styles for components
const styles: Record<string, React.CSSProperties> = {
  chatContainer: {
    display: "flex",
    flexDirection: "column",
    height: "100%",
    position: "relative",
    overflow: "hidden",
    backgroundColor: "#fbfbfd",
    minHeight: 0,
    flex: 1,
  },
  messageArea: {
    flex: 1,
    overflowY: "auto",
    overflowX: "hidden",
    padding: "20px",
    paddingBottom: "20px",
    backgroundColor: "#fbfbfd",
    minHeight: 0,
    scrollBehavior: "smooth",
  },
  messageList: {
    display: "flex",
    flexDirection: "column",
    gap: "16px",
  },
  infoAlert: {
    backgroundColor: "#f0f4f8",
    border: "1px solid #d0e0f0",
    borderRadius: "6px",
    padding: "12px 16px",
    marginBottom: "16px",
    display: "flex",
    alignItems: "flex-start",
    color: "#2c5282",
    fontSize: "14px",
  },
  infoIcon: {
    marginRight: "10px",
    marginTop: "2px",
    flexShrink: 0,
    color: "#3182ce",
  },
  loadingContainer: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "30px 0",
    color: "#5a6876",
  },
  spinner: {
    display: "inline-block",
    width: "20px",
    height: "20px",
    border: "3px solid rgba(0, 0, 0, 0.1)",
    borderRadius: "50%",
    borderTopColor: "#3182ce",
    animation: "spin 1s linear infinite",
    marginRight: "8px",
  },
  welcomeText: {
    textAlign: "center",
    color: "#5a6876",
    fontStyle: "italic",
    padding: "20px",
  },
  inputContainer: {
    border: "none",
    backgroundColor: "#f8fafc",
    padding: "20px",
    width: "100%",
    maxWidth: "100%",
    zIndex: 100,
    boxShadow: "0 -4px 20px rgba(0, 0, 0, 0.1)",
    borderTop: "3px solid #23776C",
    flexShrink: 0,
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
  },
  scrollToBottomButton: {
    position: "absolute",
    bottom: "140px", // Increased from 100px to position it higher above the input container
    right: "20px",
    backgroundColor: "#23776C",
    color: "white",
    border: "none",
    borderRadius: "50%",
    width: "44px",
    height: "44px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.2)",
    zIndex: 60, // Increased z-index to ensure it's above the input container
    transition: "all 0.2s ease",
    opacity: 0,
    pointerEvents: "none",
    WebkitAppearance: "none", // Remove webkit default styling
    MozAppearance: "none", // Remove Firefox default styling
  },
  scrollToBottomButtonVisible: {
    opacity: 1,
    pointerEvents: "auto",
  },
};

export default function Chat(props: {
  sessionId?: string;
  documentIdentifier?: string;
  kbSyncing?: boolean;
}) {
  const appContext = useContext(AppContext);
  const branding = useBranding();
  const [running, setRunning] = useState<boolean>(true);
  const [session, setSession] = useState<{ id: string; loading: boolean }>({
    id: props.sessionId ?? uuidv4(),
    loading: typeof props.sessionId !== "undefined",
  });

  const { addNotification } = useNotifications();
  const [messageHistory, setMessageHistory] = useState<ChatBotHistoryItem[]>(
    []
  );
  const messageAreaRef = useRef<HTMLDivElement>(null);
  const [showScrollToBottom, setShowScrollToBottom] = useState(false);
  const [replyStatus, setReplyStatus] = useState<string>("");
  const messageHistoryRef = useRef<ChatBotHistoryItem[]>([]);
  const prevRunningRef = useRef<boolean>(running);
  const awaitingReplyRef = useRef<boolean>(false);

  /** Loads session history */
  useEffect(() => {
    if (!appContext) return;
    setMessageHistory([]);

    (async () => {
      if (!props.sessionId) {
        const newSessionId = uuidv4();
        setSession({ id: newSessionId, loading: false });
        return;
      }

      setSession({ id: props.sessionId, loading: true });

      const apiClient = new ApiClient(appContext);
      try {
        const username = await getCurrentUser().then(
          (value) => value.username
        );
        if (!username) return;
        
        let hist;
        try {
          hist = await apiClient.sessions.getSession({
            sessionId: props.sessionId,
            userId: username,
          });
        } catch (error: unknown) {
          // If session doesn't exist (404), create it with initial greeting
          // Otherwise, rethrow the error
          if (error instanceof Error && error.message.includes("No record found")) {
            hist = null; // Session doesn't exist, will create it below
          } else {
            throw error; // Re-throw other errors
          }
        }

        if (hist?.chatHistory && hist.chatHistory.length > 0) {
          // Convert backend format to frontend format
          const parsedHistory = parseChatHistory(hist.chatHistory as unknown as Array<Record<string, unknown>>);
          setMessageHistory(parsedHistory);
          // Scroll to bottom of message area to show latest messages
          setTimeout(() => {
            if (messageAreaRef.current) {
              messageAreaRef.current.scrollTop = messageAreaRef.current.scrollHeight;
            }
          }, 100);
        } else {
          // Session doesn't exist or has no history - create initial greeting
          const summaryResult = await apiClient.landingPage.getNOFOSummary(
            props.documentIdentifier
          );
          const grantName = summaryResult.data.GrantName;

          const initialMessage = {
            type: ChatBotMessageType.AI,
            content: `Hello! I see that you are working on the ${grantName} grant. Could you please tell me which agency, municipality, or tribe we are building this narrative for?`,
            metadata: {},
          };
          setMessageHistory([initialMessage]);
          
          // Save the initial greeting to DynamoDB so it persists on refresh
          try {
            await apiClient.sessions.createSession({
              sessionId: props.sessionId,
              userId: username,
              title: `Chat about ${grantName}`,
              documentIdentifier: props.documentIdentifier || "",
              chatHistory: [{ user: "", chatbot: initialMessage.content, metadata: "" }],
            });
          } catch (error) {
            console.warn("Failed to save initial greeting:", error);
            // Don't show error to user, just log it - the message is still displayed
          }
        }
        setSession({ id: props.sessionId, loading: false });
        setRunning(false);
      } catch (error) {
        console.log(error);
        addNotification("error", error instanceof Error ? error.message : String(error));
        addNotification("info", "Please refresh the page");
      }
    })();
  }, [appContext, props.sessionId, props.documentIdentifier]);

  // Check if user has scrolled up to show scroll-to-bottom button
  useEffect(() => {
    const messageArea = messageAreaRef.current;
    if (!messageArea) return;

    const checkScrollPosition = () => {
      const isNearBottom =
        messageArea.scrollHeight -
          messageArea.scrollTop -
          messageArea.clientHeight <
        100;
      setShowScrollToBottom(!isNearBottom && messageHistory.length > 0);
    };

    messageArea.addEventListener("scroll", checkScrollPosition);
    checkScrollPosition(); // Initial check

    return () => {
      messageArea.removeEventListener("scroll", checkScrollPosition);
    };
  }, [messageHistory]);

  // Scroll to bottom when typing finishes (running changes from true to false)
  useEffect(() => {
    if (!running && messageHistory.length > 0) {
      // Small delay to ensure DOM has updated with final message content
      setTimeout(() => {
        if (messageAreaRef.current) {
          messageAreaRef.current.scrollTo({
            top: messageAreaRef.current.scrollHeight,
            behavior: "smooth",
          });
        }
      }, 100);
    }
  }, [running, messageHistory.length]);

  useEffect(() => {
    messageHistoryRef.current = messageHistory;
  }, [messageHistory]);

  /** The transcript is deliberately not a live region, so nothing announces the
   * end of a reply — an empty status region is silent. Report the outcome once,
   * on the running true -> false edge. */
  useEffect(() => {
    const wasRunning = prevRunningRef.current;
    prevRunningRef.current = running;

    if (running) {
      // True on mount as well as while replying, so only a false -> true edge
      // counts as a reply the user actually asked for.
      awaitingReplyRef.current = !wasRunning;
      return;
    }
    if (!wasRunning || !awaitingReplyRef.current) return;
    awaitingReplyRef.current = false;

    const history = messageHistoryRef.current;
    const last = history[history.length - 1];
    if (last?.type !== ChatBotMessageType.AI || last.metadata?.stopped) {
      setReplyStatus("Response stopped");
    } else if (last.metadata?.timedOut) {
      setReplyStatus("Response timed out. Send your message again to retry.");
    } else {
      setReplyStatus(last.content ? "Assistant replied" : "No response received");
    }
  }, [running]);

  const scrollToBottom = () => {
    if (messageAreaRef.current) {
      messageAreaRef.current.scrollTo({
        top: messageAreaRef.current.scrollHeight,
        behavior: "smooth",
      });
    }
  };

  return (
    <section aria-label="GrantWell assistant chat" style={styles.chatContainer}>
      {/* Not role="log": every streamed chunk rewrites the last turn, so a live
          transcript re-announces the whole growing reply. Completion is
          announced by the status region below instead. */}
      <div
        ref={messageAreaRef}
        role="group"
        aria-label="Chat transcript"
        // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex -- scrollable region needs keyboard access (WCAG 2.1.1)
        tabIndex={0}
        style={styles.messageArea}
      >
        <ul style={{ ...styles.messageList, listStyle: "none", padding: 0, margin: 0 }}>
          {messageHistory.length === 0 && !session?.loading && (
            <li style={styles.infoAlert}>
              <LuCircleHelp size={20} style={styles.infoIcon} />
              <span>
                AI Models can make mistakes. Be mindful in validating important
                information.
              </span>
            </li>
          )}

          {messageHistory.map((message, idx) => (
            <li key={idx}>
              <ChatMessage message={message} documentIdentifier={props.documentIdentifier} />
            </li>
          ))}

          {messageHistory.length === 0 && !session?.loading && (
            <li style={styles.welcomeText}>{branding.appName}</li>
          )}

          {session?.loading && (
            <li style={styles.loadingContainer}>
              <div style={styles.spinner} aria-hidden="true"></div>
              <span>Loading session</span>
            </li>
          )}
        </ul>
      </div>

      {/* Scroll to bottom button */}
      {showScrollToBottom && (
        <button
          onClick={scrollToBottom}
          aria-label="Scroll to bottom"
          style={{
            ...styles.scrollToBottomButton,
            ...styles.scrollToBottomButtonVisible,
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = "#195C53";
            e.currentTarget.style.transform = "scale(1.05)";
            e.currentTarget.style.boxShadow = "0 6px 16px rgba(0, 0, 0, 0.25)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = "#23776C";
            e.currentTarget.style.transform = "scale(1)";
            e.currentTarget.style.boxShadow = "0 4px 12px rgba(0, 0, 0, 0.2)";
          }}
        >
          <LuChevronDown size={20} />
        </button>
      )}

      <div role="status" aria-live="polite" aria-atomic="true" className="sr-only">
        {session?.loading
          ? "Loading chat session"
          : running
          ? "Assistant is replying"
          : replyStatus}
      </div>

      <div role="status" aria-live="polite" className="visually-hidden">
        {props.kbSyncing ? "Indexing your documents. You can keep chatting." : ""}
      </div>

      {/* KB indexing banner */}
      {props.kbSyncing && (
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            padding: "10px 20px",
            backgroundColor: "var(--gw-color-primary-light, #DFECE0)",
            borderTop: "1px solid var(--gw-color-border, #e2e8f0)",
            color: "var(--gw-color-primary, #23776C)",
            fontSize: "13px",
            fontWeight: 500,
            flexShrink: 0,
          }}
        >
          <LuLoader
            size={14}
            aria-hidden="true"
            style={{ animation: "spin 1s linear infinite" }}
          />
          Your documents are being indexed. Newly added documents will appear in
          results once indexing completes — you can keep chatting in the meantime.
        </div>
      )}

      {/* Chat input area */}
      <div style={styles.inputContainer}>
        <ChatInputPanel
          session={session}
          running={running}
          setRunning={setRunning}
          messageHistory={messageHistory}
          setMessageHistory={(history) => setMessageHistory(history)}
          documentIdentifier={props.documentIdentifier}
          messageAreaRef={messageAreaRef}
        />
      </div>
    </section>
  );
}
