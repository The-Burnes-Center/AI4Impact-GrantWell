import React, { useState, useRef, useEffect, useCallback, type CSSProperties } from "react";
import { useApiClient } from "../../hooks/use-api-client";
import { getCurrentUser } from "aws-amplify/auth";
import { FileUploader } from "../../common/file-uploader";
import Card from "../../components/ui/Card";
import NavigationButtons from "../../components/ui/NavigationButtons";
import ConfirmationModal from "../../components/common/ConfirmationModal";
import { colors, typography, spacing, borderRadius, transitions } from "../../components/ui/styles";
import AutoSaveIndicator from "../../components/ui/AutoSaveIndicator";
import { readDraftCache } from "../../common/helpers/document-editor-utils";
import type { useDraftSave } from "../../hooks/use-draft-save";
import type { DocumentData } from "../../common/types/document";

const MIME_TYPES: Record<string, string> = {
  ".pdf": "application/pdf",
  ".doc": "application/msword",
  ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ".xls": "application/vnd.ms-excel",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ".ppt": "application/vnd.ms-powerpoint",
  ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  ".txt": "text/plain",
  ".csv": "text/csv",
  ".html": "text/html",
  ".json": "application/json",
  ".xml": "application/xml",
  ".md": "text/markdown",
  ".rtf": "application/rtf",
  ".epub": "application/epub+zip",
  ".odt": "application/vnd.oasis.opendocument.text",
  ".tsv": "text/tab-separated-values",
  ".eml": "message/rfc822",
  ".msg": "application/vnd.ms-outlook",
};

const SUPPORTED_ACCEPT = ".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.html,.json,.xml,.md,.rtf,.epub,.odt,.tsv,.eml,.msg";

const KB_INDEXING_MESSAGE = "Your documents are being indexed and will be available shortly.";

// Coarse phases only: the poll below updates a percentage every 2s and those
// must never reach a live region.
const DRAFT_PHASE_MESSAGES: Record<string, string> = {
  preparing: "Preparing your draft.",
  planning: "Retrieving NOFO requirements and planning sections.",
  generating: "Writing your draft sections. This may take a few minutes.",
};

// Must match the server cap in generate-upload-url/index.mjs.
const MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024; // 100 MB
const MAX_FILE_SIZE_LABEL = "100 MB";

const ALLOWED_EXTENSIONS = new Set(
  SUPPORTED_ACCEPT.split(",").map((ext) => ext.replace(/^\./, "").toLowerCase()),
);

type FileValidationResult = { accepted: File[]; rejected: string[] };

function validateFiles(incoming: File[]): FileValidationResult {
  const accepted: File[] = [];
  const rejected: string[] = [];
  for (const file of incoming) {
    const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
    if (!ALLOWED_EXTENSIONS.has(ext)) {
      rejected.push(`${file.name}: unsupported file type (.${ext || "unknown"})`);
      continue;
    }
    if (file.size > MAX_FILE_SIZE_BYTES) {
      rejected.push(`${file.name}: exceeds ${MAX_FILE_SIZE_LABEL} limit`);
      continue;
    }
    accepted.push(file);
  }
  return { accepted, rejected };
}

/** Returns true when the step handled the exit itself and navigation must wait. */
export type StepLeaveGuard = (step: string, proceed: () => void) => boolean;

interface UploadDocumentsProps {
  selectedNofo: string | null;
  onNavigate: (step: string) => void;
  onNavigateToEditor?: (jobId: string) => void;
  sessionId: string;
  documentData?: DocumentData | null;
  draftSave: ReturnType<typeof useDraftSave>;
  onRegisterLeaveGuard?: (guard: StepLeaveGuard | null) => void;
}

const UploadDocuments: React.FC<UploadDocumentsProps> = ({
  selectedNofo,
  onNavigate,
  onNavigateToEditor,
  sessionId,
  documentData,
  draftSave,
  onRegisterLeaveGuard,
}) => {
  const apiClient = useApiClient();
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [additionalInfo, setAdditionalInfo] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [userId, setUserId] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  // Coarse upload state for assistive tech: the progress bar streams percentages,
  // which must not be announced, but start and completion must be.
  const [uploadAnnouncement, setUploadAnnouncement] = useState("");
  const [generatingDraft, setGeneratingDraft] = useState(false);
  const [draftProgress, setDraftProgress] = useState<string>("");
  const [generationPhase, setGenerationPhase] = useState<string>("preparing");
  const [hasExistingDraft, setHasExistingDraft] = useState(false);
  const [kbIndexing, setKbIndexing] = useState(false);
  const [pendingLeave, setPendingLeave] = useState<{ run: () => void } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const syncPollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const extractNofoName = (docId: string | null): string => {
    if (!docId) return "";
    return docId.split("/").pop() || docId;
  };

  useEffect(() => {
    const fetchUserId = async () => {
      try {
        const user = await getCurrentUser();
        setUserId(user.username);

        if (sessionId && user.username) {
          try {
            const draft = await apiClient.drafts.getDraft({
              sessionId,
              userId: user.username,
            });
            if (draft?.sections && Object.keys(draft.sections).length > 0) {
              setHasExistingDraft(true);
            }
            const cached = readDraftCache<string>(sessionId, "additionalInfo");
            const restored = cached ?? draft?.additionalInfo;
            if (restored) setAdditionalInfo(restored);
          } catch {
            console.log("No existing draft found");
          }
        }
      } catch (error) {
        console.error("Error getting user:", error);
        setUploadError("Failed to authenticate user. Please refresh the page.");
      }
    };
    fetchUserId();
  }, [apiClient, sessionId]);

  useEffect(() => {
    if (documentData?.sections && Object.keys(documentData.sections).length > 0) {
      setHasExistingDraft(true);
    }
  }, [documentData]);

  useEffect(() => {
    return () => {
      if (syncPollRef.current) clearInterval(syncPollRef.current);
    };
  }, []);

  const hasStagedFiles = files.length > 0 && !uploading && !isLoading && !generatingDraft;

  useEffect(() => {
    if (!onRegisterLeaveGuard) return;
    if (!hasStagedFiles) {
      onRegisterLeaveGuard(null);
      return;
    }
    onRegisterLeaveGuard((_step, proceed) => {
      setPendingLeave({ run: proceed });
      return true;
    });
    return () => onRegisterLeaveGuard(null);
  }, [hasStagedFiles, onRegisterLeaveGuard]);

  useEffect(() => {
    if (!hasStagedFiles) return;
    const warn = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [hasStagedFiles]);

  const addFiles = (incoming: File[]) => {
    const { accepted, rejected } = validateFiles(incoming);
    if (accepted.length > 0) {
      setFiles((prev) => [...prev, ...accepted]);
    }
    if (rejected.length > 0) {
      setUploadError(rejected.join("\n"));
    } else {
      setUploadError(null);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      addFiles(Array.from(event.target.files));
      // reset value so selecting the same file again re-triggers onChange
      event.target.value = "";
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      addFiles(Array.from(e.dataTransfer.files));
    }
  };

  const openFileSelector = () => fileInputRef.current?.click();

  const uploadFiles = useCallback(async (): Promise<boolean> => {
    if (!selectedNofo || !userId || files.length === 0) return false;

    setUploading(true);
    setUploadProgress(0);
    setUploadError(null);
    setUploadAnnouncement("Uploading files");

    const uploader = new FileUploader();
    const nofoName = extractNofoName(selectedNofo);
    const totalSize = files.reduce((acc, file) => acc + file.size, 0);
    let uploadedSize = 0;

    try {
      for (const file of files) {
        const fileExt = "." + file.name.split(".").pop()?.toLowerCase();
        const fileType = MIME_TYPES[fileExt] || "application/octet-stream";

        try {
          const uploadUrl = await apiClient.userDocuments.getUploadURL(
            file.name, fileType, userId, nofoName, file.size
          );
          await uploader.upload(file, uploadUrl, fileType, (uploaded: number) => {
            setUploadProgress(Math.round(((uploadedSize + uploaded) / totalSize) * 100));
          });
          uploadedSize += file.size;
        } catch (error) {
          console.error(`Error uploading file ${file.name}:`, error);
          setUploadError(`Failed to upload ${file.name}. Please try again.`);
          setUploadAnnouncement("");
          setUploading(false);
          return false;
        }
      }

      setUploadProgress(100);
      setKbIndexing(true);

      if (syncPollRef.current) clearInterval(syncPollRef.current);
      syncPollRef.current = setInterval(async () => {
        try {
          const status = await apiClient.kbSync.isSyncing();
          if (typeof status === "string" && status.includes("DONE")) {
            setKbIndexing(false);
            if (syncPollRef.current) clearInterval(syncPollRef.current);
            syncPollRef.current = null;
          }
        } catch {
          // Keep polling on transient errors
        }
      }, 5000);

      setUploadAnnouncement("Upload complete");
      setTimeout(() => {
        setFiles([]);
        setUploading(false);
        setUploadProgress(0);
      }, 1000);
      return true;
    } catch (error) {
      console.error("Error during upload:", error);
      setUploadError("An error occurred during upload. Please try again.");
      setUploadAnnouncement("");
      setUploading(false);
      return false;
    }
  }, [selectedNofo, userId, files, apiClient]);

  const uploadAndLeave = async () => {
    const leave = pendingLeave;
    const uploaded = await uploadFiles();
    setPendingLeave(null);
    if (uploaded) leave?.run();
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + " bytes";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  };

  const getFileIcon = (fileType: string): string => {
    if (fileType.includes("pdf")) return "\u{1F4C4}";
    if (fileType.includes("image")) return "\u{1F5BC}\uFE0F";
    if (fileType.includes("word") || fileType.includes("document")) return "\u{1F4DD}";
    if (fileType.includes("excel") || fileType.includes("spreadsheet")) return "\u{1F4CA}";
    return "\u{1F4CE}";
  };

  const handleSubmit = async () => {
    if (!selectedNofo) return;

    try {
      setIsLoading(true);

      if (files.length > 0 && userId) {
        const uploaded = await uploadFiles();
        if (!uploaded) {
          setIsLoading(false);
          return;
        }
        await new Promise((resolve) => setTimeout(resolve, 500));
      }

      const username = userId || (await getCurrentUser()).username;
      const draftToUse = await apiClient.drafts.getDraft({ sessionId, userId: username });

      if (!draftToUse) {
        throw new Error("Draft not found. Please start a new document first.");
      }

      const uploadedFileInfo = files.map((f) => ({
        name: f.name, size: f.size, type: f.type, lastModified: f.lastModified,
      }));
      await draftSave.saveFields(
        {
          status: "generating_draft",
          additionalInfo,
          uploadedFiles: uploadedFileInfo,
        },
        { source: "manual", immediate: true }
      );

      setGeneratingDraft(true);
      setDraftProgress("Analyzing your NOFO and preparing sections...");
      setGenerationPhase("preparing");
      setIsLoading(false);

      // Start the generation job — returns jobId immediately
      const jobId = await apiClient.drafts.startDraftGeneration({
        query: "Generate all sections for the grant application",
        documentIdentifier: selectedNofo,
        projectBasics: draftToUse.projectBasics || {},
        questionnaire: draftToUse.questionnaire || {},
        sessionId,
      });
      console.log('Draft generation job started:', jobId);
      setDraftProgress("Retrieving NOFO requirements and planning sections...");
      setGenerationPhase("planning");

      let pollCount = 0;
      const maxPolls = 90;
      while (pollCount < maxPolls) {
        await new Promise(resolve => setTimeout(resolve, 2000));
        pollCount++;

        try {
          const jobStatus = await apiClient.drafts.pollDraftJob(jobId);

          if (jobStatus.sectionNames && jobStatus.sectionNames.length > 0) break;

          if (jobStatus.status === 'completed' || jobStatus.status === 'partial' || jobStatus.status === 'error') break;
        } catch (err) {
          console.warn('Error polling job status:', err);
        }
      }

      // Navigate to SectionEditor — it takes over live polling
      setGeneratingDraft(false);
      if (onNavigateToEditor) {
        onNavigateToEditor(jobId);
      }
    } catch (error) {
      console.error("Error creating draft:", error);
      setUploadError(error instanceof Error ? error.message : "Failed to create draft. Please try again.");
      setIsLoading(false);
      setGeneratingDraft(false);
      setDraftProgress("");
    }
  };

  const dropzoneStyle: React.CSSProperties = {
    border: `2px dashed ${isDragging ? colors.primary : colors.border}`,
    borderRadius: borderRadius.lg,
    padding: `${spacing["3xl"]} ${spacing.xl}`,
    textAlign: "center",
    backgroundColor: isDragging ? colors.primaryLight : colors.background,
    cursor: "pointer",
    transition: transitions.normal,
    minHeight: "44px",
  };

  // Rendered as the first child of both views, so React reuses the same node when
  // the view swaps: a region created together with its first message is missed.
  const draftPhaseRegion = (
    <div role="status" aria-live="polite" className="visually-hidden">
      {generatingDraft ? DRAFT_PHASE_MESSAGES[generationPhase] ?? "" : ""}
    </div>
  );

  // ── Full-page generation view ──────────────────────────────────────
  if (generatingDraft) {
    return (
      <div style={{ maxWidth: "680px", margin: "0 auto", padding: "48px 16px", fontFamily: typography.fontFamily }}>
        {draftPhaseRegion}

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "40px" }}>
          <div
            aria-hidden
            style={{
              width: "64px",
              height: "64px",
              margin: "0 auto 20px",
              border: `3px solid ${colors.primary}`,
              borderTopColor: "transparent",
              borderRadius: "50%",
              animation: "spin 1s linear infinite",
            }}
          />
          <h2 style={{ fontSize: typography.fontSize["2xl"], fontWeight: typography.fontWeight.bold, color: colors.heading, margin: "0 0 8px" }}>
            Preparing sections...
          </h2>
          <p style={{ fontSize: typography.fontSize.base, color: colors.textSecondary, margin: 0 }}>
            {draftProgress}
          </p>
        </div>

        {/* Indeterminate only: this view is handed off to SectionsEditor as soon
            as the section list lands, so there is never a total to measure. */}
        <div style={{ marginBottom: "32px" }}>
          <div
            role="progressbar"
            aria-label="Draft generation progress"
            aria-valuetext="Preparing sections"
            style={{
              width: "100%",
              height: "12px",
              backgroundColor: colors.border,
              borderRadius: borderRadius.full,
              overflow: "hidden",
            }}
          >
            <div
              className="gw-progress-indeterminate"
              style={{
                width: "35%",
                height: "100%",
                background: `linear-gradient(90deg, ${colors.primary}, ${colors.accent})`,
                borderRadius: borderRadius.full,
                animation: "progress-slide 1.4s ease-in-out infinite",
              }}
            />
          </div>
        </div>

        {/* Persistence messaging */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
            padding: "14px 18px",
            background: "#f0fdf4",
            border: "1px solid #bbf7d0",
            borderRadius: borderRadius.lg,
            fontSize: typography.fontSize.sm,
            color: "#065f46",
          }}
        >
          <span style={{ fontSize: "18px", flexShrink: 0 }}>&#10003;</span>
          <span>
            Your progress is automatically saved. You can close this page and come back anytime — your draft will be here.
          </span>
        </div>

        <style>{`
          @keyframes spin { to { transform: rotate(360deg); } }
          @keyframes progress-slide {
            from { transform: translateX(-100%); }
            to { transform: translateX(286%); }
          }
          /* app.scss collapses all animations to one 0.01ms pass under reduced
             motion, which would park the sliding bar off-screen. */
          @media (prefers-reduced-motion: reduce) {
            .gw-progress-indeterminate {
              animation: none !important;
              transform: none !important;
              width: 100% !important;
              opacity: 0.4;
            }
          }
        `}</style>
      </div>
    );
  }

  // ── Normal upload form ─────────────────────────────────────────────
  return (
    <div style={{ maxWidth: "800px", margin: "0 auto", padding: "16px 0" }}>
      {draftPhaseRegion}

      <Card
        header="Upload & Additional Info"
        headerActions={<AutoSaveIndicator status={draftSave.saveStatus} onRetry={draftSave.retry} />}
      >
        <p style={{ color: colors.textSecondary, marginBottom: spacing["2xl"], fontFamily: typography.fontFamily }}>
          Upload supporting documents and share any additional context to help
          generate your grant application.
        </p>

        {/* Upload Supporting Documents */}
        <div style={{ marginBottom: spacing["3xl"] }}>
          <h3 style={{
            fontSize: typography.fontSize.lg,
            fontWeight: typography.fontWeight.semibold,
            color: colors.text,
            marginBottom: spacing.sm,
            fontFamily: typography.fontFamily,
          }}>
            Supporting Documents
          </h3>
          <p style={{
            fontSize: typography.fontSize.sm,
            color: colors.textSecondary,
            marginBottom: spacing.lg,
            fontFamily: typography.fontFamily,
          }}>
            Upload any documents that will strengthen your application
            (e.g., organizational details, past performance reports, budget templates).
          </p>

          <div
            style={dropzoneStyle}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={openFileSelector}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                openFileSelector();
              }
            }}
            role="button"
            tabIndex={0}
          >
            <p style={{
              fontSize: typography.fontSize.base,
              fontWeight: typography.fontWeight.medium,
              color: colors.text,
              margin: `0 0 ${spacing.sm}`,
              fontFamily: typography.fontFamily,
            }}>
              Drag and drop files here, or{" "}
              <span style={{ color: colors.primary, textDecoration: "underline" }}>browse files</span>
            </p>
            <p style={{
              fontSize: typography.fontSize.sm,
              color: colors.textSecondary,
              margin: 0,
              fontFamily: typography.fontFamily,
            }}>
              Supported formats: PDF, DOC, DOCX, XLSX, PPTX, TXT, CSV, and more (max {MAX_FILE_SIZE_LABEL} per file)
            </p>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileSelect}
            style={{ display: "none" }}
            accept={SUPPORTED_ACCEPT}
            aria-label="Select files to upload"
          />

          {files.length > 0 && (
            <div style={{ marginTop: spacing.lg }}>
              <p style={{
                fontSize: typography.fontSize.sm,
                fontWeight: typography.fontWeight.semibold,
                color: colors.text,
                marginBottom: spacing.md,
                fontFamily: typography.fontFamily,
              }}>
                Selected Files ({files.length})
              </p>
              {files.map((file, index) => (
                <div
                  key={index}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    padding: `${spacing.md} ${spacing.lg}`,
                    borderRadius: borderRadius.md,
                    backgroundColor: colors.background,
                    border: `1px solid ${colors.border}`,
                    marginBottom: spacing.sm,
                    gap: spacing.md,
                  }}
                >
                  <span style={{ fontSize: "20px", flexShrink: 0 }} aria-hidden="true">
                    {getFileIcon(file.type)}
                  </span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <span style={{
                      display: "block",
                      fontSize: typography.fontSize.sm,
                      fontWeight: typography.fontWeight.medium,
                      color: colors.text,
                      wordBreak: "break-all",
                      fontFamily: typography.fontFamily,
                    }}>
                      {file.name}
                    </span>
                    <span style={{
                      display: "block",
                      fontSize: typography.fontSize.xs,
                      color: colors.textSecondary,
                      fontFamily: typography.fontFamily,
                    }}>
                      {formatFileSize(file.size)}
                    </span>
                  </div>
                  <button
                    onClick={() => setFiles((prev) => prev.filter((_, i) => i !== index))}
                    aria-label={`Remove ${file.name}`}
                    style={{
                      background: "none",
                      border: "none",
                      color: colors.danger,
                      cursor: "pointer",
                      fontSize: "20px",
                      lineHeight: 1,
                      minWidth: "44px",
                      minHeight: "44px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      borderRadius: borderRadius.sm,
                      flexShrink: 0,
                    }}
                  >
                    &times;
                  </button>
                </div>
              ))}
            </div>
          )}

          <div role="status" aria-live="polite" className="visually-hidden">
            {uploadAnnouncement}
          </div>

          {uploading && (
            <div style={{ marginTop: spacing.lg }}>
              <div
                role="progressbar"
                aria-valuenow={uploadProgress}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label="File upload progress"
                aria-valuetext={`${uploadProgress}% complete`}
                style={{
                  height: "6px",
                  backgroundColor: colors.border,
                  borderRadius: borderRadius.sm,
                  overflow: "hidden",
                }}
              >
                <div style={{
                  height: "100%",
                  width: `${uploadProgress}%`,
                  backgroundColor: colors.primary,
                  transition: transitions.slow,
                  borderRadius: borderRadius.sm,
                }} />
              </div>
              <p style={{
                fontSize: typography.fontSize.sm,
                color: colors.textSecondary,
                marginTop: spacing.xs,
                fontFamily: typography.fontFamily,
              }}>
                Uploading... {uploadProgress}%
              </p>
            </div>
          )}

          <div role="status" aria-live="polite" className="visually-hidden">
            {kbIndexing && !uploading ? KB_INDEXING_MESSAGE : ""}
          </div>

          {kbIndexing && !uploading && (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: spacing.md,
                marginTop: spacing.lg,
                padding: `${spacing.md} ${spacing.lg}`,
                backgroundColor: colors.primaryLight,
                borderRadius: borderRadius.md,
                border: `1px solid ${colors.border}`,
                fontSize: typography.fontSize.sm,
                color: colors.primary,
                fontFamily: typography.fontFamily,
              } satisfies CSSProperties}
            >
              <div
                aria-hidden="true"
                style={{
                  width: "14px",
                  height: "14px",
                  border: `2px solid ${colors.primary}`,
                  borderTopColor: "transparent",
                  borderRadius: "50%",
                  animation: "spin 1s linear infinite",
                  flexShrink: 0,
                }}
              />
              {KB_INDEXING_MESSAGE}
            </div>
          )}
        </div>

        {/* Additional Information */}
        <div>
          <h3 style={{
            fontSize: typography.fontSize.lg,
            fontWeight: typography.fontWeight.semibold,
            color: colors.text,
            marginBottom: spacing.sm,
            fontFamily: typography.fontFamily,
          }}>
            Additional Information
          </h3>
          <p style={{
            fontSize: typography.fontSize.sm,
            color: colors.textSecondary,
            marginBottom: spacing.lg,
            fontFamily: typography.fontFamily,
          }}>
            Is there anything else you'd like to share about your application?
          </p>
          <label htmlFor="additional-info" className="sr-only">
            Additional information about your application
          </label>
          <textarea
            id="additional-info"
            value={additionalInfo}
            onChange={(e) => {
              setAdditionalInfo(e.target.value);
              draftSave.saveFields({ additionalInfo: e.target.value });
            }}
            placeholder="Enter any additional context or notes about your application..."
            aria-describedby="additional-info-help"
            style={{
              width: "100%",
              padding: spacing.md,
              border: `1px solid ${colors.inputBorder}`,
              borderRadius: borderRadius.md,
              fontSize: typography.fontSize.base,
              fontFamily: typography.fontFamily,
              minHeight: "120px",
              resize: "vertical",
            }}
          />
          <span
            id="additional-info-help"
            style={{
              display: "block",
              fontSize: typography.fontSize.sm,
              color: colors.textSecondary,
              marginTop: spacing.xs,
              lineHeight: "1.4",
              fontFamily: typography.fontFamily,
            }}
          >
            This information will help tailor the generated draft to your needs.
          </span>
        </div>

        {uploadError && (
          <div
            role="alert"
            style={{
              marginTop: spacing.lg,
              padding: `${spacing.md} ${spacing.lg}`,
              borderRadius: borderRadius.md,
              backgroundColor: colors.errorLight,
              border: `1px solid ${colors.danger}`,
              color: colors.danger,
              fontSize: typography.fontSize.sm,
              fontFamily: typography.fontFamily,
              whiteSpace: "pre-line",
            }}
          >
            {uploadError}
          </div>
        )}
      </Card>

      <div style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        gap: spacing.lg,
        marginTop: spacing["2xl"],
      }}>
        <NavigationButtons
          onBack={() => onNavigate("questionnaire")}
          showContinue={false}
          justify="flex-start"
        />

        <div style={{ display: "flex", gap: spacing.md, alignItems: "center" }}>
          {hasExistingDraft && (
            <button
              type="button"
              onClick={() => onNavigate("sectionEditor")}
              aria-label="Skip to section editor"
              style={{
                display: "flex",
                alignItems: "center",
                gap: spacing.sm,
                padding: `${spacing.md} ${spacing.xl}`,
                background: colors.white,
                border: `1px solid ${colors.border}`,
                borderRadius: borderRadius.md,
                color: colors.text,
                fontSize: typography.fontSize.base,
                fontWeight: typography.fontWeight.medium,
                fontFamily: typography.fontFamily,
                cursor: "pointer",
                transition: transitions.normal,
                minHeight: "44px",
              }}
            >
              Skip
            </button>
          )}
          <NavigationButtons
            showBack={false}
            onContinue={handleSubmit}
            continueLabel={
              isLoading
                ? "Processing..."
                : hasExistingDraft
                  ? "Generate Again"
                  : "Create Draft"
            }
            continueDisabled={isLoading}
            continueLoading={isLoading}
            justify="flex-end"
          />
        </div>
      </div>

      <ConfirmationModal
        isOpen={pendingLeave !== null}
        onClose={() => setPendingLeave(null)}
        onConfirm={uploadAndLeave}
        onCancel={() => {
          const leave = pendingLeave;
          setPendingLeave(null);
          leave?.run();
        }}
        title="Upload before leaving?"
        message={
          uploading
            ? `Uploading... ${uploadProgress}%`
            : files.length === 1
              ? `"${files[0].name}" has been selected but not uploaded yet.`
              : `${files.length} selected files have not been uploaded yet.`
        }
        warning="Leaving without uploading discards the selection, and you will need to pick the files again."
        confirmLabel="Upload now and continue"
        cancelLabel="Leave and discard"
        confirming={uploading}
      />

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default UploadDocuments;
