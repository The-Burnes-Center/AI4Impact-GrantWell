import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router";
import { v4 as uuidv4 } from "uuid";
import { useApiClient } from "../../hooks/use-api-client";
import { useDraftsClient } from "../../hooks/use-drafts-client";
import { useDraftSave } from "../../hooks/use-draft-save";
import {
  stepToStatus,
  statusToStep,
  EDITOR_STEPS,
  stepToIndex,
  readDraftCache,
  clearDraftCache,
  sweepLegacyDraftCache,
} from "../../common/helpers/document-editor-utils";
import UnifiedNavigation from "../../components/navigation/UnifiedNavigation";
import ProjectBasics from "./ProjectBasics";
import QuickQuestionnaire from "./QuickQuestionnaire";
import SectionEditor from "./SectionsEditor";
import ReviewApplication from "./ReviewApplication";
import UploadDocuments, { type StepLeaveGuard } from "./UploadDocuments";
import WelcomeModal from "./components/WelcomeModal";
import ProgressStepper from "../../components/document-editor/ProgressStepper";
import { getCurrentUser } from "aws-amplify/auth";
import type { DocumentDraft } from "../../common/api-client/drafts-client";
import type { DocumentData } from "../../common/types/document";
import { Utils } from "../../common/utils";
import "../../styles/document-editor.css";

const ERROR_MESSAGES = {
  LOAD_FAILED: "Failed to load document data",
  SAVE_FAILED: "Failed to save document data",
  START_FAILED: "Failed to start new document",
} as const;

const FIRST_SECTION_STEP_INDEX = stepToIndex("sectionEditor");

/** Custom hook: loads the document via DraftsClient */
const useDocumentStorage = (nofoId: string | null) => {
  const [documentData, setDocumentData] = useState<DocumentData | null>(null);
  const [loadedDraft, setLoadedDraft] = useState<DocumentDraft | null | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState("Loading document editor...");
  const [error, setError] = useState<string | null>(null);
  const { sessionId } = useParams();
  const draftsClient = useDraftsClient();

  const loadDocument = useCallback(async () => {
    if (!nofoId || !sessionId) return;
    setIsLoading(true);
    setError(null);
    setLoadingMessage("Loading document editor...");

    try {
      const username = (await getCurrentUser()).username;
      if (username) {
        const draft = await draftsClient.waitForDraft({
          sessionId,
          userId: username,
          onProgress: (message: string, attempt: number) => {
            setLoadingMessage(message);
            if (attempt === 15) setLoadingMessage("Draft generation is taking longer than expected. Please wait...");
            if (attempt === 30) setLoadingMessage("Draft generation is still in progress. This may take up to 2 minutes...");
          },
        });

        if (draft) {
          // Cache wins: it holds edits whose save was still pending at exit.
          const cachedSections = readDraftCache<Record<string, string>>(sessionId, "sections");
          setDocumentData({
            id: draft.sessionId,
            nofoId: draft.documentIdentifier,
            sections: { ...(draft.sections || {}), ...(cachedSections || {}) },
            projectBasics: draft.projectBasics,
            questionnaire: draft.questionnaire,
            lastModified: draft.lastModified || new Date().toISOString(),
          });
          setLoadedDraft(draft);
        } else {
          setDocumentData({ id: sessionId, nofoId, sections: {}, lastModified: new Date().toISOString() });
          setLoadedDraft(null);
        }
      }
    } catch (err) {
      console.error("Failed to load document:", err);
      setError(ERROR_MESSAGES.LOAD_FAILED);
    } finally {
      setIsLoading(false);
    }
  }, [nofoId, sessionId, draftsClient]);

  useEffect(() => { loadDocument(); }, [loadDocument]);

  return { documentData, setDocumentData, loadedDraft, isLoading, loadingMessage, error, setError };
};

const DocumentEditor: React.FC = () => {
  const [currentStep, setCurrentStep] = useState("projectBasics");
  const [selectedNofo, setSelectedNofo] = useState<string | null>(null);
  const [nofoName, setNofoName] = useState("");
  const [isNofoLoading, setIsNofoLoading] = useState(false);
  const [welcomeModalOpen, setWelcomeModalOpen] = useState(false);
  const [activeJobId, setActiveJobId] = useState<string | undefined>(undefined);
  const [isGeneratingDraft, setIsGeneratingDraft] = useState(false);
  const navigate = useNavigate();
  const stepLeaveGuardRef = useRef<StepLeaveGuard | null>(null);
  const stepRestoredForRef = useRef<string | null>(null);
  const { sessionId } = useParams();
  const [searchParams] = useSearchParams();

  const apiClient = useApiClient();
  const draftsClient = useDraftsClient();

  const { documentData, setDocumentData, loadedDraft, isLoading, loadingMessage, error, setError } =
    useDocumentStorage(selectedNofo);

  const draftSave = useDraftSave({
    sessionId,
    documentIdentifier: selectedNofo,
    fallbackTitle: selectedNofo ? `Application for ${selectedNofo}` : undefined,
  });
  const { setBaseline, saveFields } = draftSave;

  useEffect(() => {
    if (loadedDraft !== undefined) setBaseline(loadedDraft);
  }, [loadedDraft, setBaseline]);

  useEffect(() => { sweepLegacyDraftCache(); }, []);

  // Extract NOFO and step from URL
  useEffect(() => {
    const nofo = searchParams.get("nofo");
    const stepFromUrl = searchParams.get("step");
    if (nofo) setSelectedNofo(decodeURIComponent(nofo));
    if (stepFromUrl && EDITOR_STEPS.some((s) => s.id === stepFromUrl)) {
      setCurrentStep(stepFromUrl);
    }
  }, [searchParams]);

  useEffect(() => {
    if (!sessionId || !loadedDraft || loadedDraft.sessionId !== sessionId) return;
    if (stepRestoredForRef.current === sessionId) return;
    stepRestoredForRef.current = sessionId;

    const urlStep = searchParams.get("step");
    const urlNamesOpenableStep =
      !!urlStep &&
      EDITOR_STEPS.some((s) => s.id === urlStep) &&
      (stepToIndex(urlStep) < FIRST_SECTION_STEP_INDEX ||
        Object.keys(loadedDraft.sections || {}).length > 0);
    if (urlNamesOpenableStep) return;
    if (!loadedDraft.status) return;

    const statusStep = statusToStep(loadedDraft.status);
    setCurrentStep(statusStep);
    if (urlStep) {
      const corrected = new URLSearchParams(searchParams);
      corrected.set("step", statusStep);
      navigate({ search: `?${corrected.toString()}` }, { replace: true });
    }
  }, [sessionId, loadedDraft, searchParams, navigate]);

  // Backfill for rows written before reached_steps existed.
  const draftFloorIndex = useMemo(() => {
    if (!loadedDraft) return 0;
    const fromStatus = loadedDraft.status ? stepToIndex(statusToStep(loadedDraft.status)) : 0;
    const fromSections =
      Object.keys(loadedDraft.sections || {}).length > 0 ? FIRST_SECTION_STEP_INDEX : 0;
    return Math.max(0, fromStatus, fromSections, ...(loadedDraft.reachedSteps || []).map(stepToIndex));
  }, [loadedDraft]);

  const [furthest, setFurthest] = useState<{ id?: string; index: number }>({ index: 0 });
  useEffect(() => {
    const candidate = Math.max(draftFloorIndex, stepToIndex(currentStep));
    setFurthest((prev) =>
      prev.id === sessionId
        ? candidate > prev.index
          ? { id: sessionId, index: candidate }
          : prev
        : { id: sessionId, index: candidate }
    );
  }, [sessionId, draftFloorIndex, currentStep]);
  const furthestStepIndex = furthest.id === sessionId ? furthest.index : 0;

  const recordStepReached = useCallback((step: string) => {
    if (!sessionId) return;
    void draftsClient.markStepReached({ sessionId, step }).catch((): void => undefined);
  }, [sessionId, draftsClient]);

  // Show welcome modal only for new sessions
  useEffect(() => {
    if (!isLoading && !sessionId && !searchParams.get("step")) {
      setWelcomeModalOpen(true);
    } else {
      setWelcomeModalOpen(false);
    }
  }, [isLoading, sessionId, searchParams]);

  // Fetch NOFO name
  useEffect(() => {
    if (!selectedNofo) return;
    setIsNofoLoading(true);
    apiClient.landingPage
      .getNOFOSummary(selectedNofo)
      .then((result) => setNofoName(result?.data?.GrantName || "Grant Application"))
      .catch(() => setNofoName("Grant Application"))
      .finally(() => setIsNofoLoading(false));
  }, [selectedNofo, apiClient]);

  const startNewDocument = useCallback(async () => {
    if (!selectedNofo) return;
    try {
      const newSessionId = uuidv4();
      const username = (await getCurrentUser()).username;
      if (username) {
        await draftsClient.createDraft({
          sessionId: newSessionId, userId: username,
          title: `Application for ${selectedNofo}`, documentIdentifier: selectedNofo,
          sections: {}, projectBasics: {}, questionnaire: {},
          status: "project_basics", reachedSteps: ["projectBasics"],
          lastModified: Utils.getCurrentTimestamp(),
        });
      }
      clearDraftCache(newSessionId);
      setCurrentStep("projectBasics");
      navigate(`/document-editor/${newSessionId}?step=projectBasics&nofo=${encodeURIComponent(selectedNofo)}`);
    } catch (err) {
      console.error("Failed to start new document:", err);
      setError(ERROR_MESSAGES.START_FAILED);
    }
  }, [selectedNofo, draftsClient, navigate, setError]);

  const navigateToSectionEditor = useCallback((jobId: string) => {
    setActiveJobId(jobId);
    setIsGeneratingDraft(true);
    setCurrentStep("sectionEditor");
    recordStepReached("sectionEditor");
    const nofoParam = selectedNofo ? `&nofo=${encodeURIComponent(selectedNofo)}` : "";
    navigate(`/document-editor/${sessionId}?step=sectionEditor${nofoParam}`);
  }, [selectedNofo, sessionId, navigate, recordStepReached]);

  const performStepNavigation = useCallback(async (step: string) => {
    const go = () => {
      const nofoParam = selectedNofo ? `&nofo=${encodeURIComponent(selectedNofo)}` : "";
      navigate(`/document-editor/${sessionId}?step=${step}${nofoParam}`);
    };

    if (!documentData) {
      go();
      return;
    }
    try {
      // Status only: useDraftSave's own baseline holds the authoritative
      // sections, which documentData does not see once SectionsEditor has run.
      await saveFields(
        { status: stepToStatus(step) },
        { source: "status_change", immediate: true }
      );
      setCurrentStep(step);
      recordStepReached(step);
      go();
    } catch (err) {
      console.error("Failed to navigate to step:", err);
      setError(ERROR_MESSAGES.SAVE_FAILED);
    }
  }, [documentData, selectedNofo, sessionId, saveFields, navigate, setError, recordStepReached]);

  const navigateToStep = useCallback((step: string) => {
    const blocked = stepLeaveGuardRef.current?.(step, () => {
      void performStepNavigation(step);
    });
    if (blocked) return;
    void performStepNavigation(step);
  }, [performStepNavigation]);

  const registerStepLeaveGuard = useCallback((guard: StepLeaveGuard | null) => {
    stepLeaveGuardRef.current = guard;
  }, []);

  const handleUpdateData = useCallback((data: Partial<DocumentData>) => {
    setDocumentData((prev) => (prev ? { ...prev, ...data } : prev));
    saveFields({
      ...(data.sections ? { sections: data.sections } : {}),
      ...(data.projectBasics ? { projectBasics: data.projectBasics } : {}),
      ...(data.questionnaire ? { questionnaire: data.questionnaire } : {}),
      status: stepToStatus(currentStep),
    });
  }, [currentStep, saveFields, setDocumentData]);

  const renderCurrentStep = () => {
    switch (currentStep) {
      case "projectBasics":
        return <ProjectBasics onContinue={() => navigateToStep("questionnaire")} documentData={documentData} onUpdateData={handleUpdateData} saveStatus={draftSave.saveStatus} lastSavedAt={draftSave.lastSavedAt} onRetrySave={draftSave.retry} />;
      case "questionnaire":
        return <QuickQuestionnaire onContinue={() => navigateToStep("uploadDocuments")} selectedNofo={selectedNofo} onNavigate={navigateToStep} documentData={documentData} onUpdateData={handleUpdateData} saveStatus={draftSave.saveStatus} lastSavedAt={draftSave.lastSavedAt} onRetrySave={draftSave.retry} />;
      case "uploadDocuments":
        return <UploadDocuments selectedNofo={selectedNofo} onNavigate={navigateToStep} onNavigateToEditor={navigateToSectionEditor} sessionId={sessionId || ""} documentData={documentData} draftSave={draftSave} onRegisterLeaveGuard={registerStepLeaveGuard} />;
      case "sectionEditor":
        return <SectionEditor onContinue={() => navigateToStep("reviewApplication")} selectedNofo={selectedNofo} sessionId={sessionId || ""} activeJobId={activeJobId} isGenerating={isGeneratingDraft} draftSave={draftSave} />;
      case "reviewApplication":
        return <ReviewApplication selectedNofo={selectedNofo} sessionId={sessionId || ""} onNavigate={navigateToStep} />;
      default:
        return <div>Welcome to GrantWell</div>;
    }
  };

  const activeStep = stepToIndex(currentStep);

  if (error) {
    return (
      <div className="checklist-error" style={{ padding: 40 }}>
        <h2 className="checklist-error__title">Error</h2>
        <p className="checklist-error__text">{error}</p>
        <button className="checklist-error__btn" onClick={() => window.location.reload()}>Retry</button>
      </div>
    );
  }

  return (
    <div className="document-editor-root" style={{ display: "flex", alignItems: "stretch", flex: "1 0 auto", width: "100%", margin: 0, padding: 0 }}>
      <UnifiedNavigation documentIdentifier={selectedNofo} currentStep={currentStep} furthestStepIndex={furthestStepIndex} onNavigate={navigateToStep} />

      <div className="document-content" style={{ flex: 1, display: "flex", flexDirection: "column", margin: 0, padding: 0 }}>
        {!welcomeModalOpen && (
          <>
            <div className="document-editor-header" style={{ background: "#fff", borderBottom: "1px solid #e5e7eb", position: "sticky", top: 0, zIndex: 101, boxShadow: "0 1px 3px rgba(0,0,0,0.05)" }}>
              <div style={{ padding: 16 }}>
                <h1 className="document-editor-nofo-title" style={{ margin: 0, fontSize: "22px", fontWeight: 600, lineHeight: 1.4, wordBreak: "break-word" }}>
                  {isNofoLoading ? "Loading..." : nofoName || "Grant Application"}
                </h1>
              </div>
            </div>

            <ProgressStepper
              steps={[...EDITOR_STEPS]}
              activeStep={activeStep}
              isStepClickable={(idx) => {
                const hasSections = documentData?.sections && Object.keys(documentData.sections).length > 0;
                if (idx <= furthestStepIndex) return true;
                if (idx === activeStep + 1) return idx < 3 || !!hasSections;
                return false;
              }}
              onStepClick={(idx) => navigateToStep(EDITOR_STEPS[idx].id)}
              completedSteps={Array.from({ length: activeStep }, (_, i) => i)}
              showProgress
            />

            <div className="document-editor-workspace" style={{ flex: 1, padding: 20 }}>
              {/* Outlives the loading view, so both the wait and its end are announced. */}
              <div role="status" aria-live="polite" className="visually-hidden">
                {isLoading ? loadingMessage : documentData ? "Document editor ready." : ""}
              </div>

              {isLoading ? (
                <div id="document-loading-region" aria-busy="true" tabIndex={-1} style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "60vh" }}>
                  <div style={{ textAlign: "center", maxWidth: 400 }}>
                    <div className="loading-spinner" style={{ margin: "0 auto 16px" }} />
                    <p style={{ color: "#5a6169", fontSize: 16, marginBottom: 8 }}>{loadingMessage}</p>
                    {loadingMessage.includes("generation") && (
                      <p style={{ color: "#6b7280", fontSize: 14, marginTop: 8 }}>This may take 30-60 seconds. Please don&apos;t close this page.</p>
                    )}
                  </div>
                </div>
              ) : (
                renderCurrentStep()
              )}
            </div>
          </>
        )}
      </div>

      <WelcomeModal
        isOpen={welcomeModalOpen}
        onClose={() => setWelcomeModalOpen(false)}
        onGetStarted={() => {
          setWelcomeModalOpen(false);
          if (selectedNofo) startNewDocument();
          else navigate("/");
        }}
        onViewDrafts={() => {
          setWelcomeModalOpen(false);
          navigate(selectedNofo ? `/document-editor/drafts?nofo=${encodeURIComponent(selectedNofo)}` : "/document-editor/drafts");
        }}
      />
    </div>
  );
};

export default DocumentEditor;
